# Changes from the audit

Security
- Removed the hardcoded Polymarket US key from src/lib/us-key.ts; AccountGate no longer injects it. Revoke the old key.
- Orders now need confirm=true and a unique clientOrderId; repeats are ignored; total spend per request is capped by MAX_ORDER_USD (default 25); bad stakes error instead of defaulting to $0.10.
- Orders use only a live bid/ask (never a stale on-screen price); stake can no longer round up to one share; all legs are quoted before any order is sent.
- Sell matches the exact market slug only and stops if positions cannot be read.
- AI and room endpoints rate-limited.

Fake or misleading data removed
- fixtures.ts holds types and formatters only. Deleted sample positions, games, opportunities, alert rules/feed, P/L history, and unused auto4.ts.
- Fake alert rules replaced by a real price-move alert; tape shows only real moves.
- "Best bets / 56-74c band" claims removed (the filter never existed). Hedge "locks profit" text removed. Deals tab (always empty) removed.
- Manual ledger labeled unverified, timestamped, odds validated, excluded from Polymarket totals.

Data correctness
- Postponed/canceled games get their own state; kickoff shown in viewer's local time.
- Dead score feed now errors with DATA UNAVAILABLE instead of "no games".
- Game odds default 0 + hasOdds=false (no more fake 0.5/0.5).
- Leagues: college football no longer labeled NFL; word-boundary matching.
- Bid, ask, spread, read-time and source shown per market. Cash balance flagged when unavailable.

Tests: src/lib/order-guard.test.ts (18 tests), wired into `npm test`.
