# Sharpline

Shared copy of the Sharpline app so Claude can run it.

Live sports scores, Polymarket US prices, buys and sells, player search.

## Run

Needs Node 20 or newer.

```
npm install
npm run dev
```

Open http://127.0.0.1:8080

## Notes

- Sign-in keys stay in the browser (localStorage). No key is bundled: each person pastes their own Polymarket US key on the Portfolio page.
- Orders need an explicit confirmation, are limited to `MAX_ORDER_USD` (default $25) per request, and repeat submits are ignored. Multi-leg buys are separate single orders and can fill partly.
- Prices shown are last-trade quotes plus best bid/ask. They are not guaranteed fills.
- There is no fair-probability or expected-value feature yet: it needs an independent odds source (see `src/lib/quant.ts` for the math).
- Combos open in the Polymarket app. Single buy and sell stay in this app.
- Do not commit node_modules. This zip does not include them.
