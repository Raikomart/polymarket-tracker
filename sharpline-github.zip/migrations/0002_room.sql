create table if not exists room_message (
  id bigserial primary key,
  name text not null,
  body text not null,
  created_at timestamptz not null default now()
);
