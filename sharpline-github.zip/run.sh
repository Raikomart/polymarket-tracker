#!/bin/sh
# One command to install and start Sharpline. The app opens on port 8080.
set -e
npm install --no-audit --no-fund
npm run dev
