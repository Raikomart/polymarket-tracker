import type { ReactNode } from 'react'

/** Pass-through. Sign-in is explicit: the person pastes their own key on the Portfolio page. */
export function AccountGate({ children }: { children: ReactNode }) {
  return children
}
