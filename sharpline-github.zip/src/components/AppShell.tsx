import { Link } from '@tanstack/react-router'
import { Calendar, CircleUser, Bell, Moon, Sun, Swords, Ticket } from 'lucide-react'
import { useEffect, useState, type ReactNode } from 'react'
import { Logo } from './Brand'
import { ChatDock } from './ChatDock'
import { armSound } from '../lib/alert-sound'

const nav = [
  { to: '/', label: 'Today', icon: Sun },
  { to: '/scores', label: 'Games', icon: Calendar },
  { to: '/fight', label: 'Fight', icon: Swords },
  { to: '/dashboard', label: 'My Bets', icon: Ticket },
  { to: '/players', label: 'Profile', icon: CircleUser },
] as const

export function AppShell({
  title,
  subtitle,
  actions,
  wallet,
  children,
}: {
  title: string
  subtitle?: string
  actions?: ReactNode
  wallet?: string | null
  children: ReactNode
}) {
  const [light, setLight] = useState(false)
  const [menu, setMenu] = useState(false)
  const [confirmOut, setConfirmOut] = useState(false)
  const [signedIn, setSignedIn] = useState(false)
  const [photo, setPhoto] = useState('/me.jpg')

  useEffect(() => {
    const read = () => setPhoto(localStorage.getItem('sharpline-photo') || '/me.jpg')
    read()
    window.addEventListener('sharpline-photo', read)
    return () => window.removeEventListener('sharpline-photo', read)
  }, [])

  useEffect(() => {
    const read = () => setSignedIn(!!localStorage.getItem('sharpline-us-key') && !!localStorage.getItem('sharpline-us-secret'))
    read()
    window.addEventListener('sharpline-auth', read)
    return () => window.removeEventListener('sharpline-auth', read)
  }, [])

  useEffect(() => {
    const saved = localStorage.getItem('sharpline-theme') === 'light'
    setLight(saved)
    document.documentElement.dataset.theme = saved ? 'light' : 'dark'
    const arm = () => armSound()
    window.addEventListener('pointerdown', arm, { once: true })
    return () => window.removeEventListener('pointerdown', arm)
  }, [])

  function toggleTheme() {
    const next = !light
    setLight(next)
    document.documentElement.dataset.theme = next ? 'light' : 'dark'
    localStorage.setItem('sharpline-theme', next ? 'light' : 'dark')
  }

  function onPhoto(file: File) {
    const reader = new FileReader()
    reader.onload = () => {
      const img = new Image()
      img.onload = () => {
        const size = 256
        const canvas = document.createElement('canvas')
        canvas.width = size
        canvas.height = size
        const ctx = canvas.getContext('2d')
        if (!ctx) return
        const side = Math.min(img.width, img.height)
        ctx.drawImage(img, (img.width - side) / 2, (img.height - side) / 2, side, side, 0, 0, size, size)
        localStorage.setItem('sharpline-photo', canvas.toDataURL('image/jpeg', 0.85))
        window.dispatchEvent(new Event('sharpline-photo'))
        setMenu(false)
      }
      img.src = String(reader.result)
    }
    reader.readAsDataURL(file)
  }

  return (
    <div className="min-h-dvh bg-ink pb-40 md:pb-28">
      <header className="sticky top-0 z-30 border-b border-line bg-ink/85 backdrop-blur">
        <div className="mx-auto flex h-14 max-w-7xl items-center gap-6 px-4 sm:px-6">
          <Logo />
          <nav className="hidden items-center gap-1 md:flex" aria-label="Main">
            {nav.map(({ to, label, icon: Icon }) => (
              <Link
                key={to}
                to={to}
                className="flex items-center gap-2 rounded-lg px-3 py-1.5 text-sm text-mute transition hover:bg-panel-2 hover:text-white"
                activeProps={{ className: 'bg-panel-2 !text-white' }}
              >
                <Icon className="h-4 w-4" aria-hidden />
                {label}
              </Link>
            ))}
          </nav>
          <div className="ml-auto flex items-center gap-3">
            <span
              className={`hidden items-center gap-2 rounded-full border px-3 py-1 text-xs sm:flex ${wallet ? "border-up/30 bg-up/10 text-fog" : "border-line text-mute"}`}
            >
              <span className={`h-1.5 w-1.5 rounded-full ${wallet ? "live-dot bg-up" : "bg-mute"}`} />
              {wallet
                ? wallet.startsWith("0x")
                  ? `${wallet.slice(0, 6)}…${wallet.slice(-4)}`
                  : wallet
                : "Not signed in"}
            </span>
            <Link to="/alerts" className="grid h-8 w-8 place-items-center rounded-full border border-line text-fog" aria-label="Alerts">
              <Bell className="h-4 w-4" />
            </Link>
            <button
              type="button"
              onClick={toggleTheme}
              className="grid h-8 w-8 place-items-center rounded-full border border-line text-fog"
              aria-label={light ? 'Use dark mode' : 'Use light mode'}
            >
              {light ? <Moon className="h-4 w-4" /> : <Sun className="h-4 w-4" />}
            </button>
            <div className="relative flex items-center gap-1.5">
              <img src={photo} alt="" className="h-11 w-11 rounded-full object-cover ring-2 ring-signal" />
              <button
                type="button"
                onClick={() => {
                  setMenu((open) => !open)
                  setConfirmOut(false)
                }}
                className="rounded-full border border-line px-2 py-1 text-[10px] font-semibold text-fog"
                aria-label="Account menu"
              >
                Menu
              </button>
              {menu && (
                <button type="button" className="fixed inset-0 z-40 cursor-default bg-transparent" aria-label="Exit" onClick={() => { setMenu(false); setConfirmOut(false) }} />
              )}
              {menu && (
                <div className="absolute right-0 top-12 z-50 w-52 rounded-xl border border-line bg-panel p-3 shadow-2xl">
                  <div className="flex items-center justify-between gap-2">
                    <p className="text-sm font-semibold text-white">{signedIn ? 'Signed in' : 'Not signed in'}</p>
                    <button type="button" onClick={() => { setMenu(false); setConfirmOut(false) }} className="rounded-lg border border-line px-2 py-1 text-xs font-semibold text-white">
                      Exit
                    </button>
                  </div>
                  <p className="mt-1 text-xs text-mute">{signedIn ? 'Polymarket US on this phone' : 'Portfolio holds the key'}</p>
                  <label className="mt-3 block cursor-pointer rounded-lg bg-signal py-2 text-center text-sm font-semibold text-ink">
                    Change photo
                    <input
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={(event) => {
                        const file = event.target.files?.[0]
                        if (file) onPhoto(file)
                        event.target.value = ''
                      }}
                    />
                  </label>
                  {signedIn ? (
                    confirmOut ? (
                      <div className="mt-3">
                        <p className="text-xs text-fog">Sign out? Buys stop until you sign in again.</p>
                        <div className="mt-2 flex gap-2">
                          <button type="button" onClick={() => setConfirmOut(false)} className="flex-1 rounded-lg border border-line py-1.5 text-xs text-white">
                            Stay
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              localStorage.setItem('sharpline-auto-sell', '0')
                              window.dispatchEvent(new Event('sharpline-auth'))
                              setConfirmOut(false)
                              setMenu(false)
                            }}
                            className="flex-1 rounded-lg bg-down py-1.5 text-xs font-semibold text-white"
                          >
                            Sign out
                          </button>
                        </div>
                      </div>
                    ) : (
                      <button type="button" onClick={() => setConfirmOut(true)} className="mt-3 w-full rounded-lg border border-line py-2 text-sm text-white">
                        Sign out
                      </button>
                    )
                  ) : (
                    <Link to="/dashboard" onClick={() => setMenu(false)} className="mt-3 block rounded-lg bg-signal py-2 text-center text-sm font-semibold text-ink">
                      Sign in
                    </Link>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-7xl px-0 pt-3 sm:px-6 sm:pt-8">
        <div className="mb-3 flex flex-wrap items-end justify-between gap-3 px-4 sm:mb-6 sm:px-0">
          <div>
            <h1 className="font-display text-3xl font-extrabold tracking-tight text-white sm:text-4xl">
              {title}
            </h1>
            {subtitle && <p className="mt-1 max-w-xl text-lg text-mute">{subtitle}</p>}
          </div>
          {actions}
        </div>
        {children}
      </main>

      {/* Phone-style bottom tab bar */}
      <nav
        aria-label="Main mobile"
        className="fixed inset-x-0 bottom-0 z-30 grid grid-cols-5 border-t border-line bg-ink/95 pb-[env(safe-area-inset-bottom)] backdrop-blur md:hidden"
      >
        {nav.map(({ to, label, icon: Icon }) => (
          <Link
            key={to}
            to={to}
            className="relative flex flex-col items-center gap-1 py-3 text-[11px] text-mute"
            activeProps={{ className: '!text-signal' }}
          >
            <Icon className="h-5 w-5" aria-hidden />
            {label}
          </Link>
        ))}
      </nav>
      <ChatDock />
    </div>
  )
}
