import { Link } from '@tanstack/react-router'

export function Logo({ className = '' }: { className?: string }) {
  return (
    <Link
      to="/"
      className={`flex items-center gap-2 font-display text-lg font-extrabold tracking-tight text-white ${className}`}
    >
      <svg viewBox="0 0 32 32" className="h-7 w-7" aria-hidden="true">
        <rect width="32" height="32" rx="8" fill="#f5c84b" />
        <path
          d="M6 22 L13 14 L18 18 L26 8"
          stroke="#07090d"
          strokeWidth="3.2"
          strokeLinecap="round"
          strokeLinejoin="round"
          fill="none"
        />
        <circle cx="26" cy="8" r="2.6" fill="#07090d" />
      </svg>
      Sharpline
    </Link>
  )
}
