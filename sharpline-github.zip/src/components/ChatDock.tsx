import { useServerFn } from '@tanstack/react-start'
import { X } from 'lucide-react'
import { useEffect, useState } from 'react'
import { positionPnl, cents, type Game } from '../lib/fixtures'
import { askAi } from '../lib/ask.functions'
import { loadCashLegs, loadScores, loadUsPortfolio } from '../lib/live.functions'
import { loadRoom, postRoom, type RoomNote } from '../lib/room.functions'

interface Note {
  id: number
  from: 'you' | 'ai'
  who: string
  text: string
}

const voices = [
  { id: 'scores', label: 'Scores' },
  { id: 'bets', label: 'Bets' },
  { id: 'plain', label: 'Plain' },
] as const

export function ChatDock() {
  const ask = useServerFn(askAi)
  const fetchBook = useServerFn(loadUsPortfolio)
  const fetchScores = useServerFn(loadScores)
  const fetchCash = useServerFn(loadCashLegs)
  const readRoom = useServerFn(loadRoom)
  const sendRoom = useServerFn(postRoom)
  const [people, setPeople] = useState(false)
  const [room, setRoom] = useState<RoomNote[]>([])
  const [roomName, setRoomName] = useState('')
  const [roomNote, setRoomNote] = useState('')
  const [kind, setKind] = useState<'Opinion' | 'Strategy' | 'Play' | 'Meme'>('Opinion')
  const [open, setOpen] = useState(false)
  const [text, setText] = useState('')
  const [busy, setBusy] = useState(false)
  const [voice, setVoice] = useState<(typeof voices)[number]['id']>('plain')
  const [notes, setNotes] = useState<Note[]>(() => {
    const hour = new Date().getHours()
    const hello = hour < 12 ? 'Good morning' : hour < 17 ? 'Good afternoon' : 'Good evening'
    return [{ id: 1, from: 'ai', who: 'Plain', text: hello }]
  })

  async function tap(id: (typeof voices)[number]['id']) {
    if (busy) return
    setVoice(id)
    setOpen(true)
    setBusy(true)
    const who = voices.find((item) => item.id === id)?.label ?? 'Plain'
    try {
      let text = 'Nothing new.'
      if (id === 'scores') {
        const games = await fetchScores({ data: { league: 'all' } })
        const live = games.filter((game) => game.state === 'live')
        const rows = (live.length ? live : games.filter((game) => game.state === 'upcoming')).slice(0, 4)
        text = rows.length
          ? rows.map((game: Game) => `${game.away} ${game.awayScore ?? '–'}–${game.homeScore ?? '–'} ${game.home}`).join('\n')
          : 'No games on the board.'
      } else if (id === 'bets') {
        const legs = await fetchCash()
        const seen = new Set<string>()
        const top = legs.filter((leg) => (seen.has(leg.game) ? false : (seen.add(leg.game), true))).slice(0, 4)
        text = top.length ? top.map((leg) => `${leg.outcome} ${cents(leg.price)}`).join('\n') : 'No prices yet.'
      } else {
        const hour = new Date().getHours()
        text = hour < 12 ? 'Good morning.' : hour < 17 ? 'Good afternoon.' : 'Good evening.'
      }
      setNotes((current) => [...current, { id: Date.now(), from: 'ai', who, text }])
    } catch {
      setNotes((current) => [...current, { id: Date.now(), from: 'ai', who, text: 'Couldn’t load that.' }])
    } finally {
      setBusy(false)
    }
  }

  async function account() {
    if (busy) return
    setOpen(true)
    setBusy(true)
    const keyId = localStorage.getItem('sharpline-us-key') ?? ''
    const secret = localStorage.getItem('sharpline-us-secret') ?? ''
    if (!keyId || !secret) {
      setNotes((current) => [...current, { id: Date.now(), from: 'ai', who: 'Bets', text: 'Sign in on Portfolio first.' }])
      setBusy(false)
      return
    }
    try {
      const book = await fetchBook({ data: { keyId, secret } })
      const openBets = book.positions.filter((position) => position.status === 'open')
      const lines = [`Balance $${book.value.toFixed(2)}. ${openBets.length} open.`]
      for (const position of openBets.slice(0, 6)) {
        const pnl = positionPnl(position)
        lines.push(`${position.outcome} ${Math.round(position.currentPrice * 100)}¢ ${pnl >= 0 ? '+' : ''}$${pnl.toFixed(2)}`)
      }
      if (openBets.length > 6) lines.push(`${openBets.length - 6} more.`)
      setNotes((current) => [...current, { id: Date.now(), from: 'ai', who: 'Bets', text: lines.join('\n') }])
    } catch {
      setNotes((current) => [...current, { id: Date.now(), from: 'ai', who: 'Bets', text: 'Couldn’t read the account.' }])
    } finally {
      setBusy(false)
    }
  }

  useEffect(() => {
    setRoomName(localStorage.getItem('sharpline-room-name') ?? '')
  }, [])

  useEffect(() => {
    if (!people) return
    let cancel = false
    const run = () => {
      readRoom()
        .then((rows) => {
          if (!cancel) setRoom(rows)
        })
        .catch(() => {})
    }
    run()
    const timer = setInterval(run, 5000)
    return () => {
      cancel = true
      clearInterval(timer)
    }
  }, [people, readRoom])

  async function say() {
    const question = text.trim()
    if (!question || busy) return
    const history = [
      ...notes.filter((note) => note.id !== 1).map((note) => ({
        role: note.from === 'you' ? ('user' as const) : ('assistant' as const),
        content: note.text,
      })),
      { role: 'user' as const, content: question },
    ]
    const who = voices.find((item) => item.id === voice)?.label ?? 'Plain'
    setNotes((current) => [...current, { id: Date.now(), from: 'you', who: 'You', text: question }])
    setText('')
    setOpen(true)
    setBusy(true)
    try {
      const answer = await ask({ data: { messages: history, voice } })
      setNotes((current) => [...current, { id: Date.now() + 1, from: 'ai', who, text: answer.text }])
    } catch {
      setNotes((current) => [...current, { id: Date.now() + 1, from: 'ai', who, text: 'Couldn’t get an answer. Try again.' }])
    } finally {
      setBusy(false)
    }
  }

  async function send() {
    if (!people) {
      await say()
      return
    }
    const body = text.trim()
    if (!body || busy) return
    setBusy(true)
    setRoomNote('')
    setOpen(true)
    try {
      const name = roomName.trim() || 'Fan'
      const tagged = /^(Opinion|Strategy|Play|Meme) · /.test(body) ? body : `${kind} · ${body}`
      localStorage.setItem('sharpline-room-name', name)
      await sendRoom({ data: { name, body: tagged } })
      setText('')
      setRoom(await readRoom())
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Couldn’t send.'
      setRoomNote(message.replace(/^.*?:\s*/, '').slice(0, 80))
    } finally {
      setBusy(false)
    }
  }

  async function sharePlay() {
    if (busy) return
    setPeople(true)
    setOpen(true)
    setKind('Play')
    setBusy(true)
    setRoomNote('')
    try {
      const legs = await fetchCash()
      const seen = new Set<string>()
      const top = legs.filter((leg) => (seen.has(leg.game) ? false : (seen.add(leg.game), true))).slice(0, 4)
      if (!top.length) throw new Error('No play to share yet.')
      const name = roomName.trim() || 'Fan'
      const body = `Play · ${top.map((leg) => `${leg.outcome} ${cents(leg.price)}`).join(', ')}`
      localStorage.setItem('sharpline-room-name', name)
      await sendRoom({ data: { name, body } })
      setRoom(await readRoom())
    } catch (err: unknown) {
      setRoomNote(err instanceof Error ? err.message : 'Couldn’t share the play.')
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="fixed inset-x-0 bottom-[4.25rem] z-20 md:bottom-3 md:px-3">
      {open && (
        <section className="mb-2 flex max-h-[46vh] flex-col overflow-hidden rounded-2xl border border-line bg-panel shadow-2xl">
          <header className="flex items-center justify-between border-b border-line px-4 py-2.5">
            <div className="text-sm font-semibold text-white">{people ? 'People' : 'AI'}</div>
            <button type="button" onClick={() => setOpen(false)} className="rounded-lg p-1 text-mute" aria-label="Hide messages">
              <X className="h-4 w-4" />
            </button>
          </header>
          <ul className="space-y-2 overflow-y-auto px-3 py-3">
            {people
              ? room.map((note) => (
                  <li key={note.id} className="max-w-[90%]">
                    <div className="mb-1 text-[10px] font-semibold uppercase tracking-wide text-mute">{note.name}</div>
                    <div className="rounded-2xl rounded-bl-md bg-panel-2 px-3 py-2 text-sm text-white">
                      {note.body}
                      {note.body.match(/https?:\/\/\S+\.(?:gif|png|jpe?g|webp)/i)?.[0] && (
                        <img src={note.body.match(/https?:\/\/\S+\.(?:gif|png|jpe?g|webp)/i)?.[0]} alt="" className="mt-2 max-h-28 rounded-lg" />
                      )}
                    </div>
                  </li>
                ))
              : notes.map((note) => (
                  <li key={note.id} className={`max-w-[90%] ${note.from === 'you' ? 'ml-auto' : ''}`}>
                    <div className="mb-1 text-[10px] font-semibold uppercase tracking-wide text-mute">{note.who}</div>
                    <div className={`whitespace-pre-wrap rounded-2xl px-3 py-2 text-sm ${note.from === 'you' ? 'rounded-br-md bg-signal text-ink' : 'rounded-bl-md bg-panel-2 text-white'}`}>
                      {note.text}
                    </div>
                  </li>
                ))}
            {!people && busy && <li className="w-fit rounded-2xl bg-panel-2 px-3 py-2 text-sm text-mute">Thinking…</li>}
            {people && room.length === 0 && <li className="text-sm text-mute">No one has talked yet.</li>}
          </ul>
          {people && (
            <div className="flex items-center gap-1.5 px-3 pb-2">
              {(['Opinion', 'Strategy', 'Play', 'Meme'] as const).map((item) => (
                <button
                  key={item}
                  type="button"
                  onClick={() => setKind(item)}
                  className={`rounded-full px-2.5 py-1 text-[11px] font-semibold ${kind === item ? 'bg-signal text-ink' : 'border border-line text-mute'}`}
                >
                  {item}
                </button>
              ))}
              <button type="button" disabled={busy} onClick={() => void sharePlay()} className="ml-auto text-[11px] font-semibold text-signal disabled:opacity-60">
                Share play
              </button>
            </div>
          )}
          {people && <p className="px-3 pb-2 text-[11px] text-mute">200 letters. Last 30. Anyone here can post.{roomNote ? ` ${roomNote}` : ''}</p>}
        </section>
      )}
      <form
        className="mx-auto flex max-w-3xl flex-col gap-1.5 border-y border-line bg-panel px-3 py-1.5 shadow-lg md:rounded-2xl md:border md:p-2"
        onSubmit={(event) => {
          event.preventDefault()
          void send()
        }}
      >
        <div className="flex gap-1.5">
          <button
            type="button"
            onClick={() => {
              setPeople(false)
              setOpen(true)
            }}
            className={`rounded-full px-2.5 py-1 text-[11px] font-semibold ${people ? 'border border-line text-mute' : 'bg-signal text-ink'}`}
          >
            AI
          </button>
          <button
            type="button"
            onClick={() => {
              setPeople(true)
              setOpen(true)
            }}
            className={`rounded-full px-2.5 py-1 text-[11px] font-semibold ${people ? 'bg-signal text-ink' : 'border border-line text-mute'}`}
          >
            People
          </button>
          {!people && voices.map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => void tap(item.id)}
              className={`rounded-full px-2.5 py-1 text-[11px] font-semibold ${voice === item.id ? 'bg-signal text-ink' : 'border border-line text-mute'}`}
            >
              {item.label}
            </button>
          ))}
        </div>
        <div className="flex items-center gap-2">
        {people && (
          <input
            value={roomName}
            onChange={(event) => setRoomName(event.target.value.slice(0, 12))}
            placeholder="Name"
            className="w-16 bg-transparent px-1 py-1.5 text-sm text-white outline-none"
            aria-label="Your name"
          />
        )}
        <input
          value={text}
          onChange={(event) => setText(event.target.value)}
          onFocus={() => setOpen(true)}
          placeholder={people ? (kind === 'Opinion' ? 'Your opinion' : kind === 'Meme' ? 'Meme or image link' : kind === 'Strategy' ? 'Your strategy' : 'Your play') : 'Ask anything'}
          className="min-w-0 flex-1 bg-transparent px-2 py-1.5 text-sm text-fog outline-none"
        />
        <button type="button" disabled={busy} onClick={() => void account()} className="rounded-xl border border-line px-3 py-2 text-sm font-semibold text-white disabled:opacity-60">
          Account
        </button>
        <button type="submit" disabled={busy} className="rounded-xl bg-signal px-3 py-2 text-sm font-semibold text-ink disabled:opacity-60">
          Send
        </button>
        </div>
      </form>
    </div>
  )
}
