import { useId, useState } from 'react'
import { usd } from '../lib/fixtures'

/** Lightweight SVG area chart for cumulative P/L. SSR-safe, no canvas. */
export function PnlChart({ data }: { data: { day: string; pnl: number }[] }) {
  const gid = useId()
  const [hover, setHover] = useState<number | null>(null)
  const W = 640
  const H = 220
  const pad = { t: 16, r: 12, b: 26, l: 12 }
  const values = data.map((d) => d.pnl)
  const min = Math.min(0, ...values)
  const max = Math.max(0, ...values)
  const x = (i: number) =>
    pad.l + (i / Math.max(1, data.length - 1)) * (W - pad.l - pad.r)
  const y = (v: number) =>
    pad.t + (1 - (v - min) / (max - min || 1)) * (H - pad.t - pad.b)

  const line = data.map((d, i) => `${i ? 'L' : 'M'}${x(i)},${y(d.pnl)}`).join(' ')
  const area = `${line} L${x(data.length - 1)},${y(0)} L${x(0)},${y(0)} Z`
  const active = hover ?? data.length - 1
  const point = data[active]

  return (
    <div className="relative">
      <div className="pointer-events-none absolute left-5 top-0 text-xs text-mute">
        <span className="num text-white">{point ? usd(point.pnl, true) : ''}</span>{' '}
        · {point?.day}
      </div>
      <svg
        viewBox={`0 0 ${W} ${H}`}
        className="h-56 w-full"
        role="img"
        aria-label={`Cumulative profit and loss over ${data.length} days, ending at ${usd(values.at(-1) ?? 0, true)}`}
        onMouseLeave={() => setHover(null)}
        onMouseMove={(e) => {
          const r = e.currentTarget.getBoundingClientRect()
          const rel = ((e.clientX - r.left) / r.width) * W
          const i = Math.round(
            ((rel - pad.l) / (W - pad.l - pad.r)) * (data.length - 1),
          )
          setHover(Math.max(0, Math.min(data.length - 1, i)))
        }}
      >
        <defs>
          <linearGradient id={gid} x1="0" x2="0" y1="0" y2="1">
            <stop offset="0%" stopColor="#3ee68a" stopOpacity="0.35" />
            <stop offset="100%" stopColor="#3ee68a" stopOpacity="0" />
          </linearGradient>
        </defs>
        <line
          x1={pad.l}
          x2={W - pad.r}
          y1={y(0)}
          y2={y(0)}
          stroke="#222a35"
          strokeDasharray="3 4"
        />
        <path d={area} fill={`url(#${gid})`} />
        <path
          d={line}
          fill="none"
          stroke="#3ee68a"
          strokeWidth="2"
          strokeLinejoin="round"
          strokeLinecap="round"
        />
        {point && (
          <>
            <line
              x1={x(active)}
              x2={x(active)}
              y1={pad.t}
              y2={H - pad.b}
              stroke="#8a94a6"
              strokeOpacity="0.35"
            />
            <circle
              cx={x(active)}
              cy={y(point.pnl)}
              r="4.5"
              fill="#07090d"
              stroke="#3ee68a"
              strokeWidth="2"
            />
          </>
        )}
        {[0, Math.floor(data.length / 2), data.length - 1].map((i) => (
          <text
            key={i}
            x={x(i)}
            y={H - 6}
            fill="#8a94a6"
            fontSize="11"
            textAnchor={i === 0 ? 'start' : i === data.length - 1 ? 'end' : 'middle'}
            fontFamily="JetBrains Mono, monospace"
          >
            {data[i]?.day}
          </text>
        ))}
      </svg>
    </div>
  )
}
