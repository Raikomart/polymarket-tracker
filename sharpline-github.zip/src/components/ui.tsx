import { useEffect, useState, type ReactNode } from "react";
import { leagues, type LeagueId } from "../lib/fixtures";

const leagueColor: Partial<Record<LeagueId, string>> = {
  nba: "text-[#ff8a4c] border-[#ff8a4c]/30 bg-[#ff8a4c]/10",
  nfl: "text-[#7aa8ff] border-[#7aa8ff]/30 bg-[#7aa8ff]/10",
  ncaaf: "text-[#ff6b8b] border-[#ff6b8b]/30 bg-[#ff6b8b]/10",
  mlb: "text-[#ff6b8b] border-[#ff6b8b]/30 bg-[#ff6b8b]/10",
  epl: "text-[#c49bff] border-[#c49bff]/30 bg-[#c49bff]/10",
  laliga: "text-[#ffd166] border-[#ffd166]/30 bg-[#ffd166]/10",
  bundesliga: "text-[#5ee0c4] border-[#5ee0c4]/30 bg-[#5ee0c4]/10",
  seriea: "text-[#7aa8ff] border-[#7aa8ff]/30 bg-[#7aa8ff]/10",
  ligue1: "text-[#c49bff] border-[#c49bff]/30 bg-[#c49bff]/10",
  mls: "text-[#ff8a4c] border-[#ff8a4c]/30 bg-[#ff8a4c]/10",
  ucl: "text-[#ffd166] border-[#ffd166]/30 bg-[#ffd166]/10",
  other: "text-fog border-line bg-panel-2",
};

const shortName: Partial<Record<LeagueId, string>> = {
  seriea: "SER",
  ligue1: "L1",
  mls: "MLS",
  ucl: "UCL",
  ncaaf: "NCAA",
  other: "MKT",
};

export function LeagueTag({ id }: { id: LeagueId }) {
  const meta = leagues.find((league) => league.id === id);
  return (
    <span
      className={`num inline-flex shrink-0 items-center rounded-md border px-1.5 py-0.5 text-[10px] font-bold tracking-wider ${leagueColor[id] ?? leagueColor.other}`}
    >
      {meta?.short ?? shortName[id] ?? id.toUpperCase()}
    </span>
  );
}

const FLAGS: [string, string][] = [
  ["bosnia-herzegovina", "bih"], ["bosnia and herzegovina", "bih"], ["bosnia", "bih"],
  ["northern ireland", "nir"], ["republic of ireland", "irl"], ["united states", "usa"],
  ["south korea", "kor"], ["north korea", "prk"], ["korea republic", "kor"],
  ["czech republic", "cze"], ["czechia", "cze"], ["ivory coast", "civ"], ["côte d'ivoire", "civ"],
  ["south africa", "rsa"], ["saudi arabia", "ksa"], ["new zealand", "nzl"], ["costa rica", "crc"],
  ["el salvador", "slv"], ["trinidad and tobago", "tri"], ["dominican republic", "dom"],
  ["equatorial guinea", "eqg"], ["papua new guinea", "png"], ["cape verde", "cpv"],
  ["burkina faso", "bfa"], ["sierra leone", "sle"], ["south sudan", "ssd"],
  ["united arab emirates", "uae"], ["chinese taipei", "tpe"],
  ["argentina", "arg"], ["brazil", "bra"], ["portugal", "por"], ["netherlands", "ned"],
  ["germany", "ger"], ["france", "fra"], ["spain", "esp"], ["england", "eng"], ["italy", "ita"],
  ["mexico", "mex"], ["croatia", "cro"], ["belgium", "bel"], ["uruguay", "uru"], ["colombia", "col"],
  ["japan", "jpn"], ["morocco", "mar"], ["senegal", "sen"], ["nigeria", "nga"], ["ghana", "gha"],
  ["cameroon", "cmr"], ["egypt", "egy"], ["tunisia", "tun"], ["algeria", "alg"], ["australia", "aus"],
  ["canada", "can"], ["wales", "wal"], ["scotland", "sco"], ["ireland", "irl"], ["switzerland", "sui"],
  ["austria", "aut"], ["ukraine", "ukr"], ["serbia", "srb"], ["greece", "gre"], ["poland", "pol"],
  ["sweden", "swe"], ["denmark", "den"], ["norway", "nor"], ["hungary", "hun"], ["romania", "rou"],
  ["turkey", "tur"], ["türkiye", "tur"], ["chile", "chi"], ["peru", "per"], ["ecuador", "ecu"],
  ["paraguay", "par"], ["bolivia", "bol"], ["venezuela", "ven"], ["panama", "pan"], ["jamaica", "jam"],
  ["honduras", "hon"], ["guatemala", "gua"], ["haiti", "hai"], ["nicaragua", "nca"], ["suriname", "sur"],
  ["curaçao", "cuw"], ["curacao", "cuw"], ["qatar", "qat"], ["iran", "irn"], ["usa", "usa"],
  ["finland", "fin"], ["albania", "alb"], ["armenia", "arm"], ["cyprus", "cyp"], ["kosovo", "kos"],
  ["iceland", "isl"], ["slovenia", "svn"], ["slovakia", "svk"], ["georgia", "geo"], ["israel", "isr"],
  ["vietnam", "vie"], ["mali", "mli"], ["niger", "nig"],
].sort((a, b) => b[0].length - a[0].length) as [string, string][];

function flagFor(name: string): string {
  const key = name.toLowerCase();
  const hit = FLAGS.find(([label]) => key.includes(label));
  return hit ? `https://a.espncdn.com/i/teamlogos/countries/500/${hit[1]}.png` : "";
}

export function Crest({
  src,
  name,
  className = "h-8 w-8",
}: {
  src?: string;
  name: string;
  className?: string;
}) {
  const [failed, setFailed] = useState(false);
  const [flagFailed, setFlagFailed] = useState(false);
  useEffect(() => {
    setFailed(false);
    setFlagFailed(false);
  }, [src, name]);
  const initials = name
    .split(/\s+/)
    .slice(0, 2)
    .map((part) => part[0])
    .join("")
    .toUpperCase();
  const flag = flagFor(name);
  const show = Boolean(src) && !failed;
  const showFlag = !show && Boolean(flag) && !flagFailed;
  return (
    <span className={`grid shrink-0 place-items-center overflow-hidden rounded-full bg-panel-2 text-[10px] font-bold text-fog ring-1 ring-white/10 ${className}`}>
      {show ? (
        <img src={src} alt="" className="h-full w-full object-contain p-0.5" onError={() => setFailed(true)} />
      ) : showFlag ? (
        <img src={flag} alt="" className="h-full w-full object-cover" onError={() => setFlagFailed(true)} />
      ) : (
        <span>{initials || "?"}</span>
      )}
    </span>
  );
}

export function Face({
  src,
  fallback,
  name,
  className = "h-12 w-12",
}: {
  src?: string;
  fallback?: string;
  name: string;
  className?: string;
}) {
  const [current, setCurrent] = useState(src || fallback || "");
  const initials = name
    .split(/\s+/)
    .slice(0, 2)
    .map((part) => part[0])
    .join("")
    .toUpperCase();
  return (
    <span className={`relative grid shrink-0 place-items-center overflow-hidden rounded-full bg-panel-2 ring-1 ring-white/10 ${className}`}>
      {current ? (
        <img
          src={current}
          alt=""
          className="h-full w-full object-cover"
          onError={() => setCurrent(fallback && current !== fallback ? fallback : "")}
        />
      ) : (
        <span className="text-[10px] font-bold text-mute">{initials}</span>
      )}
    </span>
  );
}

export function Panel({
  title,
  action,
  children,
  className = '',
}: {
  title?: string
  action?: ReactNode
  children: ReactNode
  className?: string
}) {
  return (
    <section
      aria-label={title}
      className={`min-w-0 rounded-2xl border border-line bg-panel ${className}`}
    >
      {title && (
        <div className="flex items-center justify-between gap-3 border-b border-line px-5 py-3.5">
          <h2 className="text-sm font-semibold tracking-wide text-white">
            {title}
          </h2>
          {action}
        </div>
      )}
      {children}
    </section>
  )
}

export function Delta({ value, children }: { value: number; children: ReactNode }) {
  const cls = value > 0 ? 'text-up' : value < 0 ? 'text-down' : 'text-mute'
  return <span className={`num ${cls}`}>{children}</span>
}

/** Horizontal probability bar: market price vs. a reference (fair) probability. */
export function ProbBar({ price, fair }: { price: number; fair?: number }) {
  return (
    <div className="relative h-1.5 w-full overflow-hidden rounded-full bg-line">
      <div
        className="absolute inset-y-0 left-0 rounded-full bg-volt"
        style={{ width: `${price * 100}%` }}
      />
      {fair !== undefined && (
        <div
          className="absolute -top-0.5 h-2.5 w-0.5 bg-signal"
          style={{ left: `${fair * 100}%` }}
          aria-hidden
        />
      )}
    </div>
  )
}
