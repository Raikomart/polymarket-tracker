const KEY = 'sharpline-sound'

let ctx: AudioContext | null = null

export function soundOn(): boolean {
  if (typeof localStorage === 'undefined') return true
  return localStorage.getItem(KEY) !== 'off'
}

export function setSound(on: boolean) {
  localStorage.setItem(KEY, on ? 'on' : 'off')
}

let armed = false

export function armSound() {
  armed = true
}

function audio(): AudioContext {
  const Ctx = window.AudioContext
  if (!ctx) ctx = new Ctx()
  if (ctx.state === 'suspended') void ctx.resume()
  return ctx
}

export function playAlert() {
  if (typeof window === 'undefined' || !armed || !soundOn()) return
  const tone = audio()
  const now = tone.currentTime
  const notes = [392, 523.25, 659.25, 783.99]
  notes.forEach((freq, index) => {
    const osc = tone.createOscillator()
    const gain = tone.createGain()
    osc.type = index === 0 ? 'sawtooth' : 'triangle'
    osc.frequency.setValueAtTime(freq, now)
    const start = now + index * 0.07
    gain.gain.setValueAtTime(0.0001, start)
    gain.gain.exponentialRampToValueAtTime(index === notes.length - 1 ? 0.18 : 0.1, start + 0.02)
    gain.gain.exponentialRampToValueAtTime(0.0001, start + 0.32)
    osc.connect(gain)
    gain.connect(tone.destination)
    osc.start(start)
    osc.stop(start + 0.34)
  })
}

let lastProfit: number | null = null

export function profitBump(next: number): number {
  const prior = lastProfit
  lastProfit = next
  if (prior == null || !Number.isFinite(next)) return 0
  const delta = next - prior
  return delta > 0.009 ? delta : 0
}

export function playLoss() {
  if (typeof window === 'undefined' || !armed || !soundOn()) return
  const tone = audio()
  const now = tone.currentTime
  ;[440, 349.23, 261.63].forEach((freq, index) => {
    const osc = tone.createOscillator()
    const gain = tone.createGain()
    osc.type = 'sine'
    osc.frequency.value = freq
    const start = now + index * 0.12
    gain.gain.setValueAtTime(0.0001, start)
    gain.gain.exponentialRampToValueAtTime(0.12, start + 0.02)
    gain.gain.exponentialRampToValueAtTime(0.0001, start + 0.28)
    osc.connect(gain)
    gain.connect(tone.destination)
    osc.start(start)
    osc.stop(start + 0.3)
  })
}

export function playFollow() {
  if (typeof window === 'undefined' || !armed || !soundOn()) return
  const tone = audio()
  const now = tone.currentTime
  ;[523.25, 783.99].forEach((freq, index) => {
    const osc = tone.createOscillator()
    const gain = tone.createGain()
    osc.type = 'sine'
    osc.frequency.value = freq
    const start = now + index * 0.07
    gain.gain.setValueAtTime(0.0001, start)
    gain.gain.exponentialRampToValueAtTime(0.14, start + 0.02)
    gain.gain.exponentialRampToValueAtTime(0.0001, start + 0.22)
    osc.connect(gain)
    gain.connect(tone.destination)
    osc.start(start)
    osc.stop(start + 0.24)
  })
}

export function playRegister() {
  if (typeof window === 'undefined' || !armed) return
  const tone = audio()
  const now = tone.currentTime
  const click = tone.createBuffer(1, Math.floor(tone.sampleRate * 0.08), tone.sampleRate)
  const data = click.getChannelData(0)
  for (let i = 0; i < data.length; i++) data[i] = (Math.random() * 2 - 1) * (1 - i / data.length)
  const noise = tone.createBufferSource()
  const noiseGain = tone.createGain()
  noise.buffer = click
  noiseGain.gain.value = 0.22
  noise.connect(noiseGain)
  noiseGain.connect(tone.destination)
  noise.start(now)
  ;[988, 1318].forEach((freq, index) => {
    const bell = tone.createOscillator()
    const gain = tone.createGain()
    bell.type = 'sine'
    bell.frequency.value = freq
    const start = now + 0.04 + index * 0.01
    gain.gain.setValueAtTime(0.0001, start)
    gain.gain.exponentialRampToValueAtTime(0.2, start + 0.015)
    gain.gain.exponentialRampToValueAtTime(0.0001, start + 0.55)
    bell.connect(gain)
    gain.connect(tone.destination)
    bell.start(start)
    bell.stop(start + 0.58)
  })
}
