import { createServerFn } from "@tanstack/react-start";
import { WindowLimiter } from "./order-guard";

// This endpoint spends the owner's XAI_API_KEY and has no sign-in, so cap total use.
const askLimiter = new WindowLimiter(20, 60_000);

interface Turn {
  role: "user" | "assistant";
  content: string;
}

export const askAi = createServerFn({ method: "POST" })
  .validator((data: { messages?: Turn[]; voice?: string }) => {
    const messages = (data.messages ?? [])
      .slice(-8)
      .map((turn) => ({
        role: turn.role === "assistant" ? ("assistant" as const) : ("user" as const),
        content: String(turn.content ?? "").trim().slice(0, 1500),
      }))
      .filter((turn) => turn.content);
    if (!messages.length || messages[messages.length - 1]?.role !== "user") {
      throw new Error("Type a question first.");
    }
    const voice = data.voice === "scores" || data.voice === "bets" || data.voice === "plain" ? data.voice : "plain";
    return { messages, voice };
  })
  .handler(async ({ data }) => {
    const apiKey = process.env.XAI_API_KEY;
    if (!apiKey) return { text: "AI is not available right now." };
    if (!askLimiter.allow()) return { text: "Too many questions right now. Try again in a minute." };
    const voice =
      data.voice === "scores"
        ? "You are the scores voice in Sharpline. Talk about live games, clocks, and records. Short sentences."
        : data.voice === "bets"
          ? "You are the bets voice in Sharpline. Talk about prices, parlays, and stake size. The price is the crowd's price, not a promise of profit. Short sentences."
          : "You are the plain voice in Sharpline. Answer any question in calm, short sentences. If it is a bet, say the price is not a promise of profit.";
    const res = await fetch("https://api.x.ai/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      signal: AbortSignal.timeout(25000),
      body: JSON.stringify({
        model: "grok-4.5",
        max_tokens: 350,
        messages: [
          {
            role: "system",
            content: voice,
          },
          ...data.messages,
        ],
      }),
    });
    if (!res.ok) return { text: "Couldn’t get an answer. Try again." };
    const body = (await res.json()) as { choices?: { message?: { content?: string } }[] };
    return { text: body.choices?.[0]?.message?.content?.trim() || "No answer came back." };
  });
