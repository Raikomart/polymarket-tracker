import type { LeagueId } from "./fixtures";

export type BoardId = Exclude<LeagueId, "other">;

export const boards: { id: BoardId; name: string; espn: string }[] = [
  { id: "nba", name: "NBA", espn: "basketball/nba" },
  { id: "nfl", name: "NFL", espn: "football/nfl" },
  { id: "ncaaf", name: "NCAA Football", espn: "football/college-football" },
  { id: "mlb", name: "MLB", espn: "baseball/mlb" },
  { id: "epl", name: "Premier League", espn: "soccer/eng.1" },
  { id: "laliga", name: "La Liga", espn: "soccer/esp.1" },
  { id: "seriea", name: "Serie A", espn: "soccer/ita.1" },
  { id: "bundesliga", name: "Bundesliga", espn: "soccer/ger.1" },
  { id: "ligue1", name: "Ligue 1", espn: "soccer/fra.1" },
  { id: "mls", name: "MLS", espn: "soccer/usa.1" },
  { id: "ucl", name: "Champions League", espn: "soccer/uefa.champions" },
];

export type SoccerId =
  | "epl"
  | "laliga"
  | "seriea"
  | "bundesliga"
  | "ligue1"
  | "ucl"
  | "uel"
  | "mls"
  | "championship"
  | "bundesliga2"
  | "ligue2"
  | "eredivisie"
  | "portugal"
  | "ligamx"
  | "brazil"
  | "argentina"
  | "scotland"
  | "belgium"
  | "turkey"
  | "saudi";

export const soccerTables: {
  id: SoccerId;
  name: string;
  short: string;
  espn: string;
  tier: "top" | "more";
}[] = [
  { id: "epl", name: "Premier League", short: "EPL", espn: "soccer/eng.1", tier: "top" },
  { id: "laliga", name: "La Liga", short: "La Liga", espn: "soccer/esp.1", tier: "top" },
  { id: "seriea", name: "Serie A", short: "Serie A", espn: "soccer/ita.1", tier: "top" },
  { id: "bundesliga", name: "Bundesliga", short: "Bund.", espn: "soccer/ger.1", tier: "top" },
  { id: "ligue1", name: "Ligue 1", short: "Ligue 1", espn: "soccer/fra.1", tier: "top" },
  { id: "ucl", name: "Champions League", short: "UCL", espn: "soccer/uefa.champions", tier: "top" },
  { id: "uel", name: "Europa League", short: "UEL", espn: "soccer/uefa.europa", tier: "top" },
  { id: "mls", name: "MLS", short: "MLS", espn: "soccer/usa.1", tier: "top" },
  { id: "championship", name: "Championship", short: "Champ", espn: "soccer/eng.2", tier: "more" },
  { id: "bundesliga2", name: "2. Bundesliga", short: "2. Bund", espn: "soccer/ger.2", tier: "more" },
  { id: "ligue2", name: "Ligue 2", short: "Ligue 2", espn: "soccer/fra.2", tier: "more" },
  { id: "eredivisie", name: "Eredivisie", short: "Erediv", espn: "soccer/ned.1", tier: "more" },
  { id: "portugal", name: "Primeira Liga", short: "Portugal", espn: "soccer/por.1", tier: "more" },
  { id: "ligamx", name: "Liga MX", short: "Liga MX", espn: "soccer/mex.1", tier: "more" },
  { id: "brazil", name: "Brasileirão", short: "Brazil", espn: "soccer/bra.1", tier: "more" },
  { id: "argentina", name: "Liga Argentina", short: "Arg", espn: "soccer/arg.1", tier: "more" },
  { id: "scotland", name: "Scottish Premiership", short: "Scot", espn: "soccer/sco.1", tier: "more" },
  { id: "belgium", name: "Belgian Pro League", short: "Belg", espn: "soccer/bel.1", tier: "more" },
  { id: "turkey", name: "Süper Lig", short: "Turk", espn: "soccer/tur.1", tier: "more" },
  { id: "saudi", name: "Saudi Pro League", short: "Saudi", espn: "soccer/ksa.1", tier: "more" },
];
