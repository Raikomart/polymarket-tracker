/**
 * Shared types and number formatting only. This module holds NO sample data:
 * every game, price, position and alert shown in the app comes from a live
 * source or from what the person entered.
 */

export type LeagueId =
  | 'nba'
  | 'nfl'
  | 'mlb'
  | 'epl'
  | 'laliga'
  | 'bundesliga'
  | 'seriea'
  | 'ligue1'
  | 'mls'
  | 'ucl'
  | 'ncaaf'
  | 'other'

export interface League {
  id: LeagueId
  name: string
  short: string
  sport: 'Basketball' | 'Football' | 'Baseball' | 'Soccer'
}

export const leagues: League[] = [
  { id: 'nba', name: 'NBA', short: 'NBA', sport: 'Basketball' },
  { id: 'nfl', name: 'NFL', short: 'NFL', sport: 'Football' },
  { id: 'mlb', name: 'MLB', short: 'MLB', sport: 'Baseball' },
  { id: 'epl', name: 'Premier League', short: 'EPL', sport: 'Soccer' },
  { id: 'laliga', name: 'La Liga', short: 'LIGA', sport: 'Soccer' },
  { id: 'bundesliga', name: 'Bundesliga', short: 'BUN', sport: 'Soccer' },
]

export const leagueById = Object.fromEntries(
  leagues.map((l) => [l.id, l]),
) as Record<LeagueId, League>

/* ------------------------------------------------------------------ */
/* Positions                                                           */
/* ------------------------------------------------------------------ */

export interface Position {
  id: string
  league: LeagueId
  market: string
  outcome: string
  shares: number
  /** Average entry price per share, 0–1 (Polymarket prices = implied probability). */
  avgPrice: number
  /** Current market price per share, 0–1. */
  currentPrice: number
  /** Price 24h ago, for the sparkline delta. */
  price24h: number
  status: 'open' | 'won' | 'lost'
  closesAt: string
  /** Polymarket event page. Sample data has none; a live sync fills it from the API. */
  eventUrl?: string
  /** Book P/L from the API, when the price math would ignore fees. */
  bookPnl?: number
  icon?: string
}

/** Link to the position's Polymarket event, falling back to a Polymarket search for the market. */
export function polymarketUrl(p: Position): string {
  return (
    p.eventUrl ??
    `https://polymarket.com/us`
  )
}

export const positionCost = (p: Position) => p.shares * p.avgPrice
export const positionValue = (p: Position) => p.shares * p.currentPrice
export const positionPnl = (p: Position) =>
  p.bookPnl ?? positionValue(p) - positionCost(p)

export function summarize(list: Position[]) {
  const open = list.filter((p) => p.status === 'open')
  const settled = list.filter((p) => p.status !== 'open')
  const wins = settled.filter((p) => p.status === 'won').length
  const sum = (xs: number[]) => xs.reduce((a, b) => a + b, 0)
  return {
    openValue: sum(open.map(positionValue)),
    unrealized: sum(open.map(positionPnl)),
    realized: sum(settled.map(positionPnl)),
    total: sum(list.map(positionPnl)),
    wins,
    losses: settled.length - wins,
    winRate: settled.length ? wins / settled.length : null,
    openCount: open.length,
  }
}

export interface AlertEvent {
  id: string
  kind: 'edge' | 'move' | 'settled' | 'score'
  title: string
  body: string
  time: string
  unread: boolean
}


/* ------------------------------------------------------------------ */
/* Scores                                                              */
/* ------------------------------------------------------------------ */

export interface Game {
  id: string
  league: LeagueId
  home: string
  away: string
  homeScore: number | null
  awayScore: number | null
  state: 'live' | 'final' | 'upcoming' | 'postponed' | 'canceled'
  clock: string
  /** Polymarket price for the home side to win. */
  homeOdds: number
  /** Polymarket price for a draw (soccer only). */
  drawOdds?: number
  awayOdds: number
  youHold?: boolean
  /** True only when a real Polymarket price is attached. The scores feed has none, so this is normally false. */
  hasOdds?: boolean
  /** Scheduled start, ISO 8601 UTC, straight from the scores feed. */
  startsAt?: string
  line?: string
  homeLogo?: string
  awayLogo?: string
  /** Short live line: scorers, points, or yards. */
  plays?: string
}

/* ------------------------------------------------------------------ */
/* Formatting                                                          */
/* ------------------------------------------------------------------ */

export const usd = (n: number, signed = false) => {
  const s = new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(Math.abs(n))
  if (!signed) return n < 0 ? `−${s}` : s
  return n > 0 ? `+${s}` : n < 0 ? `−${s}` : s
}

export const cents = (p: number) => {
  const value = Math.round(p * 1000) / 10
  return Number.isInteger(value) ? `${value}¢` : `${value.toFixed(1)}¢`
}

export const signedCents = (d: number) => {
  const c = Math.round(d * 100)
  return c > 0 ? `+${c}¢` : c < 0 ? `−${Math.abs(c)}¢` : '0¢'
}

export const compactUsd = (n: number) =>
  new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    notation: 'compact',
    maximumFractionDigits: 1,
  }).format(n)
