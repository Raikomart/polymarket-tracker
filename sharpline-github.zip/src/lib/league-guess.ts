export type GuessedLeague =
  | 'nba' | 'nfl' | 'mlb' | 'epl' | 'laliga' | 'bundesliga' | 'seriea'
  | 'ligue1' | 'mls' | 'ucl' | 'ncaaf' | 'other'

/** Whole-word / phrase tests only, and the more specific leagues are checked first. */
export function guessLeague(title: string, slug: string): GuessedLeague {
  const text = `${title} ${slug}`.toLowerCase().replace(/[-_]/g, ' ')
  const has = (re: RegExp) => re.test(text)
  const soccer = has(/\b(soccer|epl|la ?liga|serie a|bundesliga|ligue|mls|champions league|ucl)\b/)
  if (has(/\b(ncaaf|college football|cfb)\b/)) return 'ncaaf'
  if (has(/\b(nfl)\b/) || (has(/\bfootball\b/) && !soccer)) return 'nfl'
  if (has(/\b(mlb|baseball)\b/)) return 'mlb'
  if (has(/\b(la ?liga)\b/)) return 'laliga'
  if (has(/\bserie a\b/)) return 'seriea'
  if (has(/\bbundesliga\b/)) return 'bundesliga'
  if (has(/\bligue\b/)) return 'ligue1'
  if (has(/\bmls\b/)) return 'mls'
  if (has(/\b(champions league|ucl)\b/)) return 'ucl'
  if (has(/\b(epl|premier league|soccer)\b/)) return 'epl'
  if (has(/\b(nba|basketball)\b/)) return 'nba'
  return 'other'
}
