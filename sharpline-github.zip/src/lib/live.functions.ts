import { createPrivateKey, sign } from "node:crypto";
import { createServerFn } from "@tanstack/react-start";
import { boards, soccerTables, type BoardId, type SoccerId } from "./boards";
import type { Game, LeagueId, Position } from "./fixtures";
import { guessLeague } from "./league-guess";
import { OrderDedupe, maxOrderUsd, parseStake, sameSlug, sharesFor } from "./order-guard";

const ESPN = "https://site.web.api.espn.com/apis";
const US_API = "https://api.polymarket.us";
const GAMMA = "https://gamma-api.polymarket.com";
const UA = "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1";
const PKCS8 = Buffer.from("302e020100300506032b657004220420", "hex");

type Raw = Record<string, any>;

async function getJson(url: string): Promise<unknown> {
  const res = await fetch(url, { headers: { "user-agent": UA, accept: "application/json" }, signal: AbortSignal.timeout(12000) });
  if (!res.ok) throw new Error(String(res.status));
  return res.json();
}

function num(value: unknown): number {
  if (typeof value === "number" && Number.isFinite(value)) return value;
  const n = Number(String(value ?? "").replace(/[$,]/g, ""));
  return Number.isFinite(n) ? n : 0;
}

function money(value: unknown): number {
  if (value && typeof value === "object") {
    const row = value as Raw;
    return num(row.value ?? row.amount ?? row.currentBalance ?? row.balance);
  }
  return num(value);
}

function label(...parts: unknown[]): string {
  for (const part of parts) {
    if (typeof part === "string" && part.trim()) return part.trim();
    if (typeof part === "number" && Number.isFinite(part)) return String(part);
  }
  return "";
}

function usHeaders(keyId: string, secret: string, method: string, path: string) {
  const raw = Buffer.from(secret, "base64");
  if (raw.length < 32) throw new Error("Sign in on My Bets first.");
  const key = createPrivateKey({ key: Buffer.concat([PKCS8, raw.subarray(0, 32)]), format: "der", type: "pkcs8" });
  const timestamp = Date.now().toString();
  const signature = sign(null, Buffer.from(`${timestamp}${method}${path}`), key).toString("base64");
  return {
    "X-PM-Access-Key": keyId,
    "X-PM-Timestamp": timestamp,
    "X-PM-Signature": signature,
  };
}

export interface WalletBook {
  positions: Position[];
  /** Cash balance when `cashKnown`, otherwise the marked value of open positions. */
  value: number;
  /** False when Polymarket did not return a balance, so `value` is NOT cash. */
  cashKnown: boolean;
  fetchedAt: number;
  series: { day: string; pnl: number }[];
}

export const loadUsPortfolio = createServerFn({ method: "POST" })
  .validator((data: { keyId: string; secret: string }) => {
    const keyId = data.keyId.match(/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i)?.[0] ?? data.keyId.trim();
    const secret = data.secret.replace(/\s+/g, "");
    if (!/^[0-9a-f-]{16,80}$/i.test(keyId)) throw new Error("Sign in on My Bets first.");
    if (secret.length < 20 || secret.length > 400) throw new Error("Sign in on My Bets first.");
    return { keyId, secret };
  })
  .handler(async ({ data }): Promise<WalletBook> => {
    const call = async (path: string, query = "") => {
      const headers = usHeaders(data.keyId, data.secret, "GET", path);
      const res = await fetch(`${US_API}${path}${query}`, { headers, signal: AbortSignal.timeout(12000) });
      if (res.status === 401 || res.status === 403) throw new Error("Polymarket rejected those keys.");
      if (!res.ok) throw new Error(`Polymarket US didn’t answer (${res.status}).`);
      return res.json() as Promise<Raw>;
    };
    const positions: Position[] = [];
    let cursor = "";
    for (let page = 0; page < 4; page += 1) {
      const query = `?limit=100${cursor ? `&cursor=${encodeURIComponent(cursor)}` : ""}`;
      const payload = await call("/v1/portfolio/positions", query);
      const book = payload.positions ?? payload.items ?? payload;
      const entries: [string, Raw][] = Array.isArray(book)
        ? book.map((row, index) => [String((row as Raw).slug ?? (row as Raw).id ?? index), row as Raw])
        : Object.entries((book ?? {}) as Record<string, Raw>);
      for (const [slug, raw] of entries) {
        const meta = (raw.marketMetadata ?? raw.market ?? {}) as Raw;
        const signed = num(raw.netPositionDecimal ?? raw.quantity ?? raw.shares ?? raw.size);
        const shares = Math.abs(signed);
        if (!shares) continue;
        const cost = money(raw.cost ?? raw.costBasis ?? raw.totalCost);
        const unrealized = money(raw.cashValue ?? raw.unrealizedPnl ?? raw.unrealized);
        const realized = money(raw.realized ?? raw.realizedPnl);
        const expired = raw.expired === true || raw.status === "closed" || raw.status === "settled";
        const title = label(meta.title, meta.question, meta.name, meta.eventTitle, meta.marketTitle, raw.question, raw.symbol, slug);
        const outcome = label(meta.outcome, meta.side, raw.outcome, raw.selection, "Yes");
        const icon = label(meta.icon, meta.image, raw.icon);
        const lookup = label(meta.slug, meta.marketSlug, raw.marketSlug, raw.slug, slug);
        positions.push({
          id: lookup || slug,
          league: guessLeague(title, slug),
          market: title,
          outcome,
          shares,
          avgPrice: shares ? cost / shares : 0,
          currentPrice: shares ? (cost + unrealized) / shares : 0,
          price24h: shares ? (cost + unrealized) / shares : 0,
          status: expired ? (realized >= 0 ? "won" : "lost") : "open",
          closesAt: expired ? "Settled" : "Open",
          eventUrl: `https://polymarket.com/us/event/${String(meta.eventSlug ?? raw.eventSlug ?? lookup)}`,
          bookPnl: expired ? realized : unrealized,
          icon: icon.startsWith("http") ? icon : undefined,
        });
      }
      if (payload.eof !== false || typeof payload.cursor !== "string" || !payload.cursor) break;
      cursor = payload.cursor;
    }
    let cash = 0;
    let cashKnown = false;
    try {
      const balances = await call("/v1/account/balances");
      const rows = Array.isArray(balances.balances) ? (balances.balances as Raw[]) : [];
      cash = rows.reduce((sum, row) => sum + money(row.currentBalance ?? row.balance ?? row.buyingPower), 0);
      cashKnown = rows.length > 0;
    } catch {
      cashKnown = false;
    }
    const openValue = positions.filter((position) => position.status === "open").reduce((sum, position) => sum + position.shares * position.currentPrice, 0);
    return { positions, value: cashKnown ? cash : openValue, cashKnown, fetchedAt: Date.now(), series: [] };
  });

const orderDedupe = new OrderDedupe();

function orderCap() {
  return maxOrderUsd(process.env.MAX_ORDER_USD);
}

function validateOrderCommon(data: { keyId: string; secret: string; confirm?: unknown; clientOrderId?: unknown }) {
  const keyId = String(data.keyId ?? "").trim();
  const secret = String(data.secret ?? "").replace(/\s+/g, "");
  if (!/^[0-9a-f-]{16,80}$/i.test(keyId) || secret.length < 20 || secret.length > 400) throw new Error("Sign in on My Bets first.");
  if (data.confirm !== true) throw new Error("Order was not confirmed.");
  const clientOrderId = String(data.clientOrderId ?? "");
  if (!/^[\w-]{8,80}$/.test(clientOrderId)) throw new Error("Missing order id. Refresh and try again.");
  return { keyId, secret, clientOrderId };
}

export const closePosition = createServerFn({ method: "POST" })
  .validator((data: { keyId: string; secret: string; slug: string; price?: number; confirm: boolean; clientOrderId: string }) => {
    const common = validateOrderCommon(data);
    const slug = String(data.slug ?? "").trim();
    if (!slug || slug.length > 180) throw new Error("No position to sell.");
    return { ...common, slug };
  })
  .handler(async ({ data }) => {
    if (!orderDedupe.claim(data.clientOrderId)) throw new Error("That order was already sent.");
    try {
      const shares = await heldShares(data.keyId, data.secret, data.slug);
      if (shares < 1) throw new Error("You don't hold a full share of that.");
      const book = await liveBook(data.slug);
      // Only a live bid counts. A price from the screen may be stale.
      if (!book || !(book.bid > 0)) throw new Error("No live bid to sell into right now.");
      const quantity = Math.floor(shares);
      const reply = await usOrder(data.keyId, data.secret, "/v1/orders", limitOrder(data.slug, "SELL", book.bid, quantity));
      return { ok: true, clientOrderId: data.clientOrderId, quantity, limitPrice: book.bid, orderRef: String(reply.id ?? reply.orderId ?? "") };
    } catch (err) {
      orderDedupe.release(data.clientOrderId);
      throw err instanceof Error ? err : new Error("Polymarket did not take it.");
    }
  });

export const placeTicket = createServerFn({ method: "POST" })
  .validator((data: { keyId: string; secret: string; stake: number | string; mode: string; confirm: boolean; clientOrderId: string; legs: { outcome: string; game: string; league: string; price: number; slug?: string }[] }) => {
    const common = validateOrderCommon(data);
    const stake = parseStake(data.stake, orderCap());
    const legs = (data.legs ?? []).filter((leg) => leg.slug).slice(0, 12);
    const need = data.mode === "eight" ? 8 : data.mode === "twelve" ? 12 : data.mode === "parlay" ? 4 : 1;
    if (legs.length < need) throw new Error(need === 1 ? "No market to buy." : `Need ${need} different markets.`);
    const slugs = new Set(legs.map((leg) => leg.slug));
    if (slugs.size !== legs.length) throw new Error("Need a different market on every leg.");
    if (stake * legs.length > orderCap()) throw new Error(`Total $${(stake * legs.length).toFixed(2)} is above the $${orderCap()} per-order limit.`);
    return { ...common, stake, mode: data.mode, legs };
  })
  .handler(async ({ data }) => {
    if (!orderDedupe.claim(data.clientOrderId)) throw new Error("That order was already sent.");
    let bought = 0;
    const filled: { slug: string; quantity: number; limitPrice: number; orderRef: string }[] = [];
    try {
      // Quote every leg first so a dead market is found before any money moves.
      const planned: { slug: string; outcome: string; ask: number; quantity: number }[] = [];
      for (const leg of data.legs) {
        const book = await liveBook(leg.slug!);
        if (!book || !(book.ask > 0 && book.ask < 1)) throw new Error(`No live ask for ${leg.outcome}.`);
        planned.push({ slug: leg.slug!, outcome: leg.outcome, ask: book.ask, quantity: sharesFor(data.stake, book.ask) });
      }
      // These are separate single orders, not one combined parlay, and can fill partly.
      for (const leg of planned) {
        const reply = await usOrder(data.keyId, data.secret, "/v1/orders", limitOrder(leg.slug, "BUY", leg.ask, leg.quantity));
        bought += 1;
        filled.push({ slug: leg.slug, quantity: leg.quantity, limitPrice: leg.ask, orderRef: String(reply.id ?? reply.orderId ?? "") });
      }
    } catch (err) {
      const message = err instanceof Error ? err.message : "Polymarket did not take it.";
      if (bought > 0) throw new Error(`Sent ${bought} of ${data.legs.length} orders. ${message} Check My Bets before retrying.`);
      orderDedupe.release(data.clientOrderId);
      throw err instanceof Error ? err : new Error(message);
    }
    return { ok: true, legs: bought, stake: data.stake, clientOrderId: data.clientOrderId, orders: filled };
  });

function gameState(status: Raw): Game["state"] {
  const state = String((status.type as Raw | undefined)?.state ?? status.state ?? "");
  const name = String((status.type as Raw | undefined)?.name ?? "").toUpperCase();
  if (name.includes("POSTPONED")) return "postponed";
  if (name.includes("CANCEL") || name.includes("FORFEIT") || name.includes("ABANDON")) return "canceled";
  if (state === "in") return "live";
  if (state === "post") return "final";
  return "upcoming";
}

function mapGame(event: Raw, league: LeagueId): Game | null {
  const comp = ((event.competitions as Raw[] | undefined) ?? [])[0];
  if (!comp) return null;
  const sides = (comp.competitors as Raw[] | undefined) ?? [];
  const away = sides.find((side) => side.homeAway === "away") ?? sides[0];
  const home = sides.find((side) => side.homeAway === "home") ?? sides[1];
  if (!away || !home) return null;
  const team = (side: Raw) => (side.team ?? {}) as Raw;
  const score = (side: Raw) => {
    const n = Number(side.score);
    return side.score == null || side.score === "" || !Number.isFinite(n) ? null : n;
  };
  const status = ((event.status as Raw | undefined) ?? {}) as Raw;
  const type = (status.type ?? {}) as Raw;
  const state = gameState(status);
  const scorer = (side: Raw) => {
    const groups = (side.leaders as Raw[] | undefined) ?? [];
    const points = groups.find((group) => /point|goal|td|run/i.test(String(group.name ?? group.abbreviation ?? ""))) ?? groups[0];
    const row = ((points?.leaders as Raw[] | undefined) ?? [])[0];
    const athlete = (row?.athlete ?? {}) as Raw;
    const name = String(athlete.shortName ?? athlete.displayName ?? "").trim();
    const value = String(row?.displayValue ?? "").trim();
    return name ? (value ? `${name} ${value}` : name) : "";
  };
  const last = String((((comp.situation as Raw | undefined)?.lastPlay as Raw | undefined)?.text) ?? "").trim();
  const names = [scorer(away), scorer(home)].filter(Boolean);
  return {
    id: String(event.id ?? `${team(away).abbreviation}-${team(home).abbreviation}`),
    league,
    home: String(team(home).shortDisplayName ?? team(home).abbreviation ?? "Home"),
    away: String(team(away).shortDisplayName ?? team(away).abbreviation ?? "Away"),
    homeScore: score(home),
    awayScore: score(away),
    state,
    clock: String(type.shortDetail ?? (state === "live" ? "LIVE" : "")),
    // The ESPN scoreboard carries no Polymarket price. 0 means "no price", never a real 50/50.
    homeOdds: 0,
    awayOdds: 0,
    hasOdds: false,
    startsAt: typeof event.date === "string" ? event.date : undefined,
    homeLogo: String(team(home).logo ?? ""),
    awayLogo: String(team(away).logo ?? ""),
    plays: names.join(" · ") || last,
  };
}

let scoreCache: { at: number; rows: Game[] } | null = null;

export const loadScores = createServerFn({ method: "POST" })
  .validator((data: { league?: string }) => ({ league: data?.league || "all" }))
  .handler(async ({ data }) => {
    if (!scoreCache || Date.now() - scoreCache.at > 20_000) {
      const boardsToLoad = boards;
      let failed = 0;
      const rows = (
        await Promise.all(
          boardsToLoad.map(async (board) => {
            const payload = (await getJson(`${ESPN}/site/v2/sports/${board.espn}/scoreboard`).catch(() => null)) as { events?: Raw[] } | null;
            if (!payload) failed += 1;
            return (payload?.events ?? []).map((event) => mapGame(event, board.id)).filter((game): game is Game => game != null);
          }),
        )
      ).flat();
      // A dead feed must not look like "no games today".
      if (failed === boardsToLoad.length) {
        if (scoreCache) return data.league === "all" ? scoreCache.rows : scoreCache.rows.filter((game) => game.league === (data.league as BoardId));
        throw new Error("DATA UNAVAILABLE: the ESPN scores feed did not answer.");
      }
      scoreCache = { at: Date.now(), rows };
    }
    return data.league === "all" ? scoreCache.rows : scoreCache.rows.filter((game) => game.league === (data.league as BoardId));
  });

export interface WatchMatch {
  id: string;
  league: string;
  home: string;
  away: string;
  homeLogo: string;
  awayLogo: string;
  homeScore: number | null;
  awayScore: number | null;
  state: "live" | "final" | "upcoming" | "postponed" | "canceled";
  clock: string;
  tag: string;
  revenge: boolean;
  star: string;
  starPhoto: string;
  plays: string;
}

export interface Scorer {
  name: string;
  team: string;
  logo: string;
  photo: string;
  url: string;
  goals: number;
  detail: string;
  league: string;
  kind?: "goals" | "assists";
}

export interface LeagueFace {
  league: string;
  clubs: { name: string; logo: string }[];
  scorers: Scorer[];
  assists: Scorer[];
}

export interface WatchBoard {
  feature: WatchMatch | null;
  clasicos: WatchMatch[];
  revenge: WatchMatch[];
  past: WatchMatch[];
  stars: Scorer[];
  scorers: Scorer[];
  leagues: LeagueFace[];
}

const RIVALS = ["real madrid", "barcelona", "manchester city", "manchester united", "arsenal", "tottenham", "liverpool", "chelsea", "inter", "milan", "juventus", "bayern", "dortmund", "psg", "marseille"];

function isClasico(home: string, away: string) {
  const a = home.toLowerCase();
  const b = away.toLowerCase();
  return RIVALS.some((name) => a.includes(name)) && RIVALS.some((name) => b.includes(name)) && a !== b;
}

function statOf(entry: Raw, name: string) {
  const stats = (entry.stats as Raw[] | undefined) ?? [];
  const row = stats.find((stat) => stat.name === name || stat.abbreviation === name);
  return String(row?.displayValue ?? row?.value ?? "");
}

async function soccerLeaders(espn: string, short: string, kind: "goals" | "assists"): Promise<Scorer[]> {
  const payload = (await getJson(`${ESPN}/site/v2/sports/${espn}/statistics`).catch(() => null)) as { stats?: { name?: string; leaders?: Raw[] }[] } | null;
  const key = kind === "goals" ? "goalsLeaders" : "assistsLeaders";
  const rows = payload?.stats?.find((stat) => stat.name === key)?.leaders ?? [];
  return rows.slice(0, 6).map((row) => {
    const athlete = (row.athlete ?? {}) as Raw;
    const team = (athlete.team ?? {}) as Raw;
    const id = String(athlete.id ?? "");
    return {
      name: String(athlete.displayName ?? "Player"),
      team: String(team.shortDisplayName ?? team.displayName ?? ""),
      logo: String(team.logos?.[0]?.href ?? ""),
      photo: id ? `https://a.espncdn.com/i/headshots/soccer/players/full/${id}.png` : "",
      url: id ? `https://www.espn.com/soccer/player/_/id/${id}` : "",
      goals: num(row.value),
      detail: String(row.shortDisplayValue ?? ""),
      league: short,
      kind,
    };
  });
}

let watchCache: { at: number; board: WatchBoard } | null = null;

export const loadWatch = createServerFn({ method: "GET" }).handler(async (): Promise<WatchBoard> => {
  if (watchCache && Date.now() - watchCache.at < 60_000) return watchCache.board;
  const top = soccerTables.filter((table) => table.tier === "top");
  const [faces, matchBoards] = await Promise.all([
    Promise.all(
      top.map(async (table) => {
        const [scorers, assists, standings] = await Promise.all([
          soccerLeaders(table.espn, table.short, "goals"),
          soccerLeaders(table.espn, table.short, "assists"),
          getJson(`${ESPN}/v2/sports/${table.espn}/standings`).catch(() => null) as Promise<Raw | null>,
        ]);
        const groups = standings?.children?.length ? standings.children : [{ standings: standings?.standings }];
        const clubs = groups
          .flatMap((group: Raw) => ((group.standings?.entries as Raw[] | undefined) ?? []).map((entry) => {
            const team = (entry.team ?? {}) as Raw;
            return { name: String(team.shortDisplayName ?? team.displayName ?? ""), logo: String(team.logos?.[0]?.href ?? "") };
          }))
          .filter((club: { logo: string }) => club.logo)
          .slice(0, 20);
        return { league: table.short, clubs, scorers, assists } satisfies LeagueFace;
      }),
    ),
    Promise.all(
      top.map(async (table) => {
        const payload = (await getJson(`${ESPN}/site/v2/sports/${table.espn}/scoreboard`).catch(() => null)) as { events?: Raw[] } | null;
        return (payload?.events ?? []).map((event) => {
          const game = mapGame(event, "epl");
          if (!game) return null;
          const match: WatchMatch = {
            id: game.id,
            league: table.short,
            home: game.home,
            away: game.away,
            homeLogo: game.homeLogo ?? "",
            awayLogo: game.awayLogo ?? "",
            homeScore: game.homeScore,
            awayScore: game.awayScore,
            state: game.state,
            clock: game.clock,
            tag: isClasico(game.home, game.away) ? "Clásico" : "",
            revenge: false,
            star: "",
            starPhoto: "",
            plays: "",
          };
          return match;
        }).filter((match): match is WatchMatch => match != null);
      }),
    ),
  ]);
  const matches = matchBoards.flat();
  const clasicos = matches.filter((match) => match.tag).slice(0, 3);
  const past = matches.filter((match) => match.state === "final").slice(0, 3);
  const live = matches.find((match) => match.state === "live");
  const feature = live ?? clasicos[0] ?? matches.find((match) => match.state === "upcoming") ?? past[0] ?? null;
  const board: WatchBoard = {
    feature,
    clasicos,
    revenge: [],
    past,
    stars: faces.flatMap((face) => face.scorers).slice(0, 6),
    scorers: faces.flatMap((face) => face.scorers),
    leagues: faces,
  };
  watchCache = { at: Date.now(), board };
  return board;
});

export interface SoccerSnapshot {
  tables: { name: string; rows: { rank: string; team: string; logo: string; record: string; gf: string; ga: string; gd: string; pts: string }[] }[];
  matches: WatchMatch[];
}

export const loadSoccerTable = createServerFn({ method: "POST" })
  .validator((data: { id: string }) => {
    const table = soccerTables.find((row) => row.id === data.id);
    if (!table) throw new Error("Unknown league.");
    return { id: table.id as SoccerId };
  })
  .handler(async ({ data }): Promise<SoccerSnapshot> => {
    const table = soccerTables.find((row) => row.id === data.id)!;
    const [standings, scoreboard] = await Promise.all([
      getJson(`${ESPN}/v2/sports/${table.espn}/standings`).catch(() => null) as Promise<Raw | null>,
      getJson(`${ESPN}/site/v2/sports/${table.espn}/scoreboard`).catch(() => null) as Promise<{ events?: Raw[] } | null>,
    ]);
    const groups = standings?.children?.length ? standings.children : [{ name: table.name, standings: standings?.standings }];
    const tables = groups.map((group: Raw) => ({
      name: String(group.name ?? group.abbreviation ?? table.name),
      rows: ((group.standings?.entries as Raw[] | undefined) ?? []).map((entry) => {
        const team = (entry.team ?? {}) as Raw;
        return {
          rank: statOf(entry, "rank"),
          team: String(team.shortDisplayName ?? team.displayName ?? ""),
          logo: String(team.logos?.[0]?.href ?? ""),
          record: statOf(entry, "overall"),
          gf: statOf(entry, "pointsFor"),
          ga: statOf(entry, "pointsAgainst"),
          gd: statOf(entry, "pointDifferential"),
          pts: statOf(entry, "points"),
        };
      }),
    }));
    const matches = (scoreboard?.events ?? []).map((event): WatchMatch | null => {
      const game = mapGame(event, "epl");
      if (!game) return null;
      return {
        id: game.id,
        league: table.short,
        home: game.home,
        away: game.away,
        homeLogo: game.homeLogo ?? "",
        awayLogo: game.awayLogo ?? "",
        homeScore: game.homeScore,
        awayScore: game.awayScore,
        state: game.state,
        clock: game.clock,
        tag: "",
        revenge: false,
        star: "",
        starPhoto: "",
        plays: "",
      } satisfies WatchMatch;
    }).filter((match): match is WatchMatch => match != null);
    return { tables, matches };
  });

export interface PlayerCard {
  id: string;
  name: string;
  team: string;
  league: string;
  group: string;
  stat: string;
  value: string;
  photo: string;
  logo: string;
  url: string;
  line: { label: string; value: string }[];
  odds?: { price: number; url: string };
}

const LEADER_MAP: { league: "NBA" | "NFL" | "MLB"; path: string; folder: string; groups: { group: string; name: string }[] }[] = [
  { league: "NBA", path: "basketball/nba", folder: "nba", groups: [{ group: "PTS", name: "pointsPerGame" }, { group: "REB", name: "reboundsPerGame" }, { group: "AST", name: "assistsPerGame" }] },
  { league: "NFL", path: "football/nfl", folder: "nfl", groups: [{ group: "RUSH", name: "rushingYards" }, { group: "REC", name: "receivingYards" }, { group: "TD", name: "passingTouchdowns" }] },
  { league: "MLB", path: "baseball/mlb", folder: "mlb", groups: [{ group: "R", name: "runs" }, { group: "HR", name: "homeRuns" }, { group: "H", name: "avg" }] },
];

function leaderCard(row: Raw, league: string, group: string, folder: string): PlayerCard | null {
  const athlete = (row.athlete ?? {}) as Raw;
  const name = String(athlete.displayName ?? "");
  if (!name) return null;
  const team = (athlete.team ?? {}) as Raw;
  const id = String(athlete.id ?? name);
  const head = athlete.headshot as { href?: string } | undefined;
  return {
    id: `${league}-${group}-${id}`,
    name,
    team: String(team.shortDisplayName ?? team.displayName ?? ""),
    league,
    group,
    stat: group,
    value: String(row.displayValue ?? row.value ?? ""),
    photo: head?.href || `https://a.espncdn.com/i/headshots/${folder}/players/full/${id}.png`,
    logo: String(team.logos?.[0]?.href ?? team.logo ?? ""),
    url: String((athlete.links as { href?: string }[] | undefined)?.find((link) => String(link.href ?? "").startsWith("http"))?.href ?? ""),
    line: [{ label: group, value: String(row.displayValue ?? "") }],
  };
}

let playerCache: { at: number; rows: PlayerCard[] } | null = null;

export const loadPlayers = createServerFn({ method: "GET" }).handler(async () => {
  if (playerCache && Date.now() - playerCache.at < 60_000) return playerCache.rows;
  const rows = (
    await Promise.all(
      LEADER_MAP.map(async (sport) => {
        const payload = (await getJson(`${ESPN}/site/v3/sports/${sport.path}/leaders`).catch(() => null)) as { leaders?: { categories?: Raw[] } } | null;
        const categories = payload?.leaders?.categories ?? [];
        return sport.groups.flatMap((group) => {
          const category = categories.find((row) => row.name === group.name);
          return ((category?.leaders as Raw[] | undefined) ?? []).slice(0, 8).map((row) => leaderCard(row, sport.league, group.group, sport.folder)).filter((row): row is PlayerCard => row != null);
        });
      }),
    )
  ).flat();
  playerCache = { at: Date.now(), rows };
  return rows;
});

const FOLDER: Record<string, string> = { soccer: "soccer", basketball: "nba", football: "nfl", baseball: "mlb", hockey: "nhl", mma: "mma" };
const PREFER = ["G", "A", "SHOT", "SOG", "PTS", "REB", "AST", "YDS", "TD", "HR", "R"];

export const searchPlayers = createServerFn({ method: "POST" })
  .validator((data: { query: string }) => {
    const query = data.query.trim().slice(0, 60);
    if (query.length < 2) throw new Error("Type at least 2 letters.");
    return { query };
  })
  .handler(async ({ data }): Promise<PlayerCard[]> => {
    const query = encodeURIComponent(data.query);
    const hosts = ["https://site.web.api.espn.com/apis", "https://site.api.espn.com/apis"];
    let items: Raw[] = [];
    for (const host of hosts) {
      const found = (await getJson(`${host}/common/v3/search?query=${query}&limit=8&type=player`).catch(() => null)) as { items?: Raw[] } | null;
      items = found?.items ?? [];
      if (items.length) break;
    }
    const cards = await Promise.all(items.slice(0, 8).map(async (item) => {
      try {
        const sport = String(item.sport ?? "soccer");
        const leagueSlug = String(item.defaultLeagueSlug ?? item.league ?? "");
        const id = String(item.id ?? "");
        const name = String(item.displayName ?? "");
        const teamRel = ((item.teamRelationships as Raw[] | undefined) ?? [])[0] ?? {};
        const teamCore = (teamRel.core ?? {}) as Raw;
        const team = String(teamRel.displayName ?? teamCore.displayName ?? teamCore.name ?? "");
        const folder = FOLDER[sport] ?? sport;
        let line: { label: string; value: string }[] = [];
        if (id && leagueSlug) {
          const overview = (await getJson(`${ESPN}/common/v3/sports/${sport}/${leagueSlug}/athletes/${id}/overview`).catch(() => null)) as { statistics?: Raw } | null;
          const statsRoot = (overview?.statistics ?? {}) as Raw;
          const splits = Array.isArray(statsRoot.splits) ? (statsRoot.splits as Raw[]) : [];
          const labels = Array.isArray(statsRoot.labels) ? (statsRoot.labels as string[]) : [];
          const split = splits.find((row) => String(row.displayName ?? "").length) ?? splits[0];
          if (split && labels.length) {
            const stats = Array.isArray(split.stats) ? (split.stats as string[]) : [];
            const chips = labels.map((labelText, index) => ({ label: labelText, value: stats[index] ?? "" })).filter((chip) => chip.value && chip.value !== "0");
            chips.sort((a, b) => (PREFER.indexOf(b.label) === -1 ? 99 : PREFER.indexOf(b.label)) - (PREFER.indexOf(a.label) === -1 ? 99 : PREFER.indexOf(a.label)));
            line = chips.slice(0, 8);
          }
        }
        const leagueName = String(((item.leagueRelationships as Raw[] | undefined) ?? [])[0]?.displayName ?? leagueSlug);
        return {
          id: id || name,
          name,
          team,
          league: leagueName,
          group: "",
          stat: line[0]?.label ?? "",
          value: line[0]?.value ?? "",
          photo: id ? `https://a.espncdn.com/i/headshots/${folder}/players/full/${id}.png` : "",
          logo: "",
          url: id ? `https://www.espn.com/${sport}/player/_/id/${id}` : "",
          line,
        } satisfies PlayerCard;
      } catch {
        return null;
      }
    }));
    return cards.filter((card): card is PlayerCard => !!card?.name);
  });

export interface CashLeg {
  id: string;
  outcome: string;
  game: string;
  league: LeagueId;
  price: number;
  volume: number;
  url: string;
  logo: string;
  fair: number | null;
  slug: string;
  /** Best bid / ask from the live book. The price above is the last quote, not an executable price. */
  bid?: number;
  ask?: number;
  /** When this row was read from Polymarket (ms since epoch). */
  fetchedAt: number;
  source: string;
}

async function usSportsLegs(): Promise<CashLeg[]> {
  const payload = (await getJson(
    "https://gateway.polymarket.us/v1/markets?active=true&closed=false&categories=sports&limit=80",
  ).catch(() => null)) as { markets?: Raw[] } | null;
  const legs: CashLeg[] = [];
  const seen = new Set<string>();
  for (const market of payload?.markets ?? []) {
    const slug = String(market.slug ?? "");
    const question = String(market.question ?? "");
    if (!slug || !question || seen.has(slug) || market.closed === true) continue;
    const sides = (market.marketSides as Raw[] | undefined) ?? [];
    const long = sides.find((side) => side.long === true) ?? sides[0];
    if (!long) continue;
    const team = (long.team ?? {}) as Raw;
    const quote = (long.quote ?? {}) as Raw;
    const price = num(quote.value ?? long.price);
    if (!(price > 0.01 && price < 0.99)) continue;
    seen.add(slug);
    legs.push({
      id: slug,
      outcome: String(team.safeName ?? team.name ?? "Yes").trim() || "Yes",
      game: question,
      league: guessLeague(question, slug),
      price,
      volume: num(market.volumeNum ?? market.volume ?? 0),
      url: `https://polymarket.com/us/event/${slug}`,
      logo: String(team.logo ?? team.longIcon ?? market.image ?? ""),
      fair: null,
      slug,
      fetchedAt: Date.now(),
      source: "Polymarket US gateway",
    });
    if (legs.length >= 16) break;
  }
  await Promise.all(
    legs.map(async (leg) => {
      const book = await liveBook(leg.slug);
      if (book && book.bid > 0) leg.bid = book.bid;
      if (book && book.ask > 0) leg.ask = book.ask;
    }),
  );
  return legs;
}

async function usOrder(keyId: string, secret: string, path: string, body: unknown) {
  const headers = usHeaders(keyId, secret, "POST", path);
  const res = await fetch(`${US_API}${path}`, {
    method: "POST",
    headers: { ...headers, "content-type": "application/json" },
    body: JSON.stringify(body),
    signal: AbortSignal.timeout(20000),
  });
  const payload = (await res.json().catch(() => null)) as Raw | null;
  if (!res.ok) {
    const msg = String(payload?.message || payload?.error || "Polymarket did not take it.");
    throw new Error(msg.slice(0, 180));
  }
  return payload ?? {};
}

function limitOrder(slug: string, side: "BUY" | "SELL", px: number, quantity: number) {
  const price = side === "BUY"
    ? Math.min(0.99, Math.ceil(px * 100) / 100)
    : Math.max(0.01, Math.floor(px * 100) / 100);
  return {
    marketSlug: slug,
    type: "ORDER_TYPE_LIMIT",
    intent: side === "BUY" ? "ORDER_INTENT_BUY_LONG" : "ORDER_INTENT_SELL_LONG",
    price: { value: price.toFixed(2), currency: "USD" },
    quantity: Math.max(1, Math.floor(quantity)),
    tif: "TIME_IN_FORCE_IMMEDIATE_OR_CANCEL",
    manualOrderIndicator: "MANUAL_ORDER_INDICATOR_MANUAL",
  };
}

async function liveBook(slug: string): Promise<{ bid: number; ask: number } | null> {
  const payload = (await getJson(`https://gateway.polymarket.us/v1/markets/${encodeURIComponent(slug)}/bbo`).catch(() => null)) as Raw | null;
  const book = (payload?.marketData ?? null) as Raw | null;
  if (!book) return null;
  if (book.state && book.state !== "MARKET_STATE_OPEN") return null;
  return { bid: num((book.bestBid as Raw | undefined)?.value), ask: num((book.bestAsk as Raw | undefined)?.value) };
}

async function heldShares(keyId: string, secret: string, slug: string) {
  let cursor = "";
  for (let page = 0; page < 4; page += 1) {
    const path = "/v1/portfolio/positions";
    const query = `?limit=100${cursor ? `&cursor=${encodeURIComponent(cursor)}` : ""}`;
    const headers = usHeaders(keyId, secret, "GET", path);
    const res = await fetch(`${US_API}${path}${query}`, { headers, signal: AbortSignal.timeout(12000) });
    // Unknown holdings must stop the sell, not look like "you hold nothing".
    if (!res.ok) throw new Error(`Couldn't read your positions (${res.status}).`);
    const payload = ((await res.json().catch(() => null)) ?? {}) as Raw;
    const book = payload.positions ?? payload.items ?? payload;
    const entries: [string, Raw][] = Array.isArray(book)
      ? (book as Raw[]).map((row, index) => [String(index), row])
      : Object.entries((book ?? {}) as Record<string, Raw>);
    for (const [key, raw] of entries) {
      const meta = (raw.marketMetadata ?? raw.market ?? {}) as Raw;
      const ids = [meta.slug, meta.marketSlug, raw.marketSlug, raw.slug, key].map((v) => String(v ?? ""));
      if (!ids.some((id) => sameSlug(id, slug))) continue;
      return Math.abs(num(raw.netPositionDecimal ?? raw.quantity ?? raw.shares ?? raw.size));
    }
    if (payload.eof !== false || typeof payload.cursor !== "string" || !payload.cursor) break;
    cursor = payload.cursor;
  }
  return 0;
}

let cashCache: { at: number; rows: CashLeg[] } | null = null;

async function readCashLegs(): Promise<CashLeg[]> {
  if (cashCache && Date.now() - cashCache.at < 15_000) return cashCache.rows;
  const rows = await usSportsLegs();
  const seen = new Set<string>();
  const unique = rows.filter((leg) => (seen.has(leg.id) ? false : (seen.add(leg.id), true)));
  cashCache = { at: Date.now(), rows: unique.slice(0, 24) };
  return cashCache.rows;
}

export const loadCashLegs = createServerFn({ method: "GET" }).handler(async () => readCashLegs());

export interface SpecLeg {
  id: string;
  outcome: string;
  game: string;
  league: string;
  price: number;
}

export const loadSpecEight = createServerFn({ method: "GET" }).handler(async (): Promise<SpecLeg[]> => {
  const legs = await readCashLegs();
  const seen = new Set<string>();
  const picked: SpecLeg[] = [];
  for (const leg of legs) {
    if (seen.has(leg.slug)) continue;
    seen.add(leg.slug);
    picked.push({ id: leg.slug, outcome: leg.outcome, game: leg.game, league: leg.league, price: leg.price });
    if (picked.length === 8) break;
  }
  return picked;
});

export interface Gainer {
  id: string;
  name: string;
  photo: string;
  up: number;
  play: string;
  url: string;
}

export interface CopyPlay {
  id: string;
  outcome: string;
  title: string;
  price: number;
  slug: string;
  league: string;
  icon: string;
  names: string[];
}

export interface GainerBoard {
  people: Gainer[];
  plays: CopyPlay[];
  deck: CopyPlay[];
  resetsAt: number;
}

let gainerCache: { at: number; board: GainerBoard } | null = null;

async function distinctPlays(): Promise<CopyPlay[]> {
  const plays: CopyPlay[] = [];
  const seen = new Set<string>();
  for (let offset = 0; offset < 800 && plays.length < 8; offset += 100) {
    const payload = (await getJson(
      `https://gateway.polymarket.us/v1/markets?active=true&closed=false&categories=sports&limit=100&offset=${offset}`,
    ).catch(() => null)) as { markets?: Raw[] } | null;
    const markets = payload?.markets ?? [];
    if (!markets.length) break;
    for (const market of markets) {
      const question = String(market.question ?? "");
      const slug = String(market.slug ?? "");
      if (!question || !slug || seen.has(question) || market.closed === true) continue;
      const sides = (market.marketSides as Raw[] | undefined) ?? [];
      const long = sides.find((side) => side.long === true) ?? sides[0];
      if (!long) continue;
      const team = (long.team ?? {}) as Raw;
      const price = num((long.quote as Raw | undefined)?.value ?? long.price);
      if (price < 0.2 || price > 0.7) continue;
      seen.add(question);
      const name = String(team.safeName ?? team.name ?? "Yes").trim() || "Yes";
      plays.push({
        id: slug,
        outcome: name,
        title: question,
        price,
        slug,
        league: guessLeague(question, slug),
        icon: String(team.logo ?? team.longIcon ?? market.image ?? ""),
        names: [name],
      });
      if (plays.length === 8) break;
    }
  }
  return plays;
}

export const loadGainers = createServerFn({ method: "GET" }).handler(async (): Promise<GainerBoard> => {
  if (gainerCache && Date.now() - gainerCache.at < 15_000) return gainerCache.board;
  const legs = await readCashLegs();
  const plays: CopyPlay[] = legs.slice(0, 8).map((leg) => ({
    id: leg.id,
    outcome: leg.outcome,
    title: leg.game,
    price: leg.price,
    slug: leg.slug,
    league: leg.league,
    icon: leg.logo,
    names: [leg.outcome],
  }));
  const now = new Date();
  const sinceMonday = (now.getUTCDay() + 6) % 7;
  const resetsAt = Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate() - sinceMonday + 7);
  let people: Gainer[] = [];
  try {
    const payload = (await getJson("https://data-api.polymarket.com/v2/leaderboard?time_period=week&sort_by=PNL&limit=10&category=sports")) as { data?: Raw[] } | Raw[];
    const rows = Array.isArray(payload) ? payload : payload.data ?? [];
    people = rows.slice(0, 10).map((row, index) => {
      const wallet = String(row.user_id ?? row.proxyWallet ?? index);
      const name = String(row.user_name ?? row.userName ?? "").trim() || `${wallet.slice(0, 6)}…${wallet.slice(-4)}`;
      const photo = String(row.profile_image ?? row.profileImage ?? "");
      return {
        id: wallet,
        name,
        photo: photo.startsWith("http") ? photo : "",
        up: num(row.pnl),
        play: "Sports · this week",
        url: `https://polymarket.com/profile/${wallet}`,
      };
    }).filter((person) => person.up !== 0 || person.name);
  } catch {
    people = [];
  }
  const deck = (await distinctPlays().catch(() => [] as CopyPlay[])).slice(0, 8);
  const board = { people, plays, deck: deck.length >= 4 ? deck : plays, resetsAt };
  gainerCache = { at: Date.now(), board };
  return board;
});

export interface FighterSide {
  name: string;
  record: string;
  country: string;
  flag: string;
  photo: string;
}

export interface FightBout {
  id: string;
  weight: string;
  when: string;
  state: "live" | "final" | "upcoming";
  broadcast: string;
  main: boolean;
  left: FighterSide;
  right: FighterSide;
}

export interface HeatCell {
  id: string;
  league: string;
  home: string;
  away: string;
  homeLogo: string;
  awayLogo: string;
  homeScore: number | null;
  awayScore: number | null;
  state: "live" | "final" | "upcoming";
  clock: string;
  heat: number;
}

export interface DuelSide {
  name: string;
  photo: string;
  team: string;
  logo: string;
  stat: string;
}

export interface PlayerDuel {
  id: string;
  league: string;
  game: string;
  left: DuelSide;
  right: DuelSide;
}

export interface WatchFace {
  name: string;
  photo: string;
  team: string;
  logo: string;
  line: string;
  league: string;
}

export interface ArenaBoard {
  event: string;
  bouts: FightBout[];
  heat: HeatCell[];
  duels: PlayerDuel[];
  watch: WatchFace[];
}

const ARENA_BOARDS = [
  { espn: "basketball/nba", label: "NBA", folder: "nba" },
  { espn: "football/nfl", label: "NFL", folder: "nfl" },
  { espn: "soccer/eng.1", label: "EPL", folder: "soccer" },
  { espn: "soccer/esp.1", label: "La Liga", folder: "soccer" },
];

let arenaCache: { at: number; board: ArenaBoard } | null = null;

function boutState(status: Raw | undefined): FightBout["state"] {
  const type = (status?.type ?? {}) as Raw;
  if (type.state === "in") return "live";
  if (type.state === "post") return "final";
  return "upcoming";
}

function heatScore(state: HeatCell["state"], home: number | null, away: number | null) {
  if (state === "live") {
    if (home == null || away == null) return 70;
    return Math.round(55 + 35 * (1 - Math.min(Math.abs(home - away) / 12, 1)));
  }
  return state === "upcoming" ? 32 : 12;
}

function starFromSide(side: Raw, folder: string): DuelSide | null {
  const team = (side.team ?? {}) as Raw;
  const blocks = (side.leaders as Raw[] | undefined) ?? [];
  const block = blocks[0];
  const lead = ((block?.leaders as Raw[] | undefined) ?? [])[0];
  const athlete = (lead?.athlete ?? {}) as Raw;
  const name = String(athlete.displayName ?? "");
  if (!name) return null;
  const id = String(athlete.id ?? "");
  return {
    name,
    photo: id ? `https://a.espncdn.com/i/headshots/${folder}/players/full/${id}.png` : "",
    team: String(team.shortDisplayName ?? team.abbreviation ?? ""),
    logo: String(team.logo ?? ""),
    stat: String(lead?.displayValue ?? ""),
  };
}

export const loadArena = createServerFn({ method: "GET" }).handler(async (): Promise<ArenaBoard> => {
  if (arenaCache && Date.now() - arenaCache.at < 45_000) return arenaCache.board;
  const [ufc, boardsOut] = await Promise.all([
    getJson(`${ESPN}/site/v2/sports/mma/ufc/scoreboard`).catch(() => null) as Promise<{ events?: Raw[] } | null>,
    Promise.all(
      ARENA_BOARDS.map(async (board) => {
        const payload = (await getJson(`${ESPN}/site/v2/sports/${board.espn}/scoreboard`).catch(() => null)) as { events?: Raw[] } | null;
        return { board, events: payload?.events ?? [] };
      }),
    ),
  ]);
  const card = ufc?.events?.[0];
  const comps = (card?.competitions as Raw[] | undefined) ?? [];
  const bouts = comps
    .map((comp, index) => {
      const sides = (comp.competitors as Raw[] | undefined) ?? [];
      const [a, b] = sides;
      if (!a || !b) return null;
      const person = (side: Raw): FighterSide => {
        const athlete = (side.athlete ?? {}) as Raw;
        const flag = (athlete.flag ?? {}) as Raw;
        const id = String(side.id ?? "");
        const records = (side.records as Raw[] | undefined) ?? [];
        return {
          name: String(athlete.displayName ?? "Fighter"),
          record: String(records.find((row) => row.type === "total")?.summary ?? ""),
          country: String(flag.alt ?? ""),
          flag: String(flag.href ?? ""),
          photo: id ? `https://a.espncdn.com/i/headshots/mma/players/full/${id}.png` : "",
        };
      };
      const status = (comp.status ?? {}) as Raw;
      const type = (status.type ?? {}) as Raw;
      return {
        id: String(comp.id ?? index),
        weight: String((comp.type as Raw | undefined)?.abbreviation ?? ""),
        when: String(type.shortDetail ?? ""),
        state: boutState(status),
        broadcast: String((comp.broadcasts as { names?: string[] }[] | undefined)?.[0]?.names?.[0] ?? ""),
        main: index === comps.length - 1,
        left: person(a),
        right: person(b),
      } satisfies FightBout;
    })
    .filter((bout): bout is FightBout => bout != null)
    .sort((a, b) => Number(b.main) - Number(a.main));

  const heat: HeatCell[] = [];
  const duels: PlayerDuel[] = [];
  const watch: WatchFace[] = [];
  const seen = new Set<string>();
  for (const { board, events } of boardsOut) {
    for (const event of events.slice(0, 4)) {
      const comp = ((event.competitions as Raw[] | undefined) ?? [])[0];
      if (!comp) continue;
      const sides = (comp.competitors as Raw[] | undefined) ?? [];
      const away = sides.find((side) => side.homeAway === "away") ?? sides[0];
      const home = sides.find((side) => side.homeAway === "home") ?? sides[1];
      if (!away || !home) continue;
      const nameOf = (side: Raw) => String((side.team as Raw | undefined)?.shortDisplayName ?? "Team");
      const logoOf = (side: Raw) => String((side.team as Raw | undefined)?.logo ?? "");
      const scoreOf = (side: Raw) => {
        const n = Number(side.score);
        return side.score == null || side.score === "" || !Number.isFinite(n) ? null : n;
      };
      const status = ((event.status as Raw | undefined)?.type ?? {}) as Raw;
      const state = boutState({ type: status });
      const homeScore = scoreOf(home);
      const awayScore = scoreOf(away);
      heat.push({
        id: String(event.id ?? `${nameOf(away)}-${nameOf(home)}`),
        league: board.label,
        home: nameOf(home),
        away: nameOf(away),
        homeLogo: logoOf(home),
        awayLogo: logoOf(away),
        homeScore,
        awayScore,
        state,
        clock: String(status.shortDetail ?? ""),
        heat: heatScore(state, homeScore, awayScore),
      });
      const left = starFromSide(away, board.folder);
      const right = starFromSide(home, board.folder);
      if (left && right && duels.length < 3) {
        duels.push({ id: `duel-${event.id}`, league: board.label, game: `${nameOf(away)} vs ${nameOf(home)}`, left, right });
      }
      for (const side of [left, right]) {
        if (!side || seen.has(side.name) || watch.length >= 4) continue;
        seen.add(side.name);
        watch.push({ name: side.name, photo: side.photo, team: side.team, logo: side.logo, line: side.stat, league: board.label });
      }
    }
  }
  heat.sort((a, b) => b.heat - a.heat);
  const board: ArenaBoard = {
    event: String(card?.shortName ?? card?.name ?? "UFC"),
    bouts: bouts.slice(0, 6),
    heat: heat.slice(0, 6),
    duels,
    watch,
  };
  arenaCache = { at: Date.now(), board };
  return board;
});
