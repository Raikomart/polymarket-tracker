import { describe, it } from 'node:test'
import assert from 'node:assert/strict'
import { OrderDedupe, WindowLimiter, maxOrderUsd, parseStake, sameSlug, sharesFor } from './order-guard.ts'
import { guessLeague } from './league-guess.ts'
import { expectedValuePerDollar, spread } from './quant.ts'

describe('parseStake', () => {
  it('rejects bad values instead of defaulting', () => {
    for (const bad of ['', 'abc', 0, -1, NaN, null, undefined]) assert.throws(() => parseStake(bad, 25))
  })
  it('enforces the cap', () => {
    assert.throws(() => parseStake(26, 25), /limit/)
    assert.equal(parseStake('25', 25), 25)
  })
  it('rounds to cents', () => assert.equal(parseStake(1.009, 25), 1.01))
  it('maxOrderUsd falls back to the default', () => {
    assert.equal(maxOrderUsd(undefined), 25)
    assert.equal(maxOrderUsd('abc'), 25)
    assert.equal(maxOrderUsd('10'), 10)
  })
})

describe('sharesFor', () => {
  it('never spends more than the stake', () => {
    assert.equal(sharesFor(1, 0.4), 2)
    assert.equal(sharesFor(10, 0.33), 30)
  })
  it('refuses when the stake cannot buy one share', () => assert.throws(() => sharesFor(0.1, 0.5), /less than one share/))
  it('refuses a missing or invalid ask', () => {
    assert.throws(() => sharesFor(5, 0))
    assert.throws(() => sharesFor(5, 1))
  })
})

describe('sameSlug', () => {
  it('is exact', () => {
    assert.equal(sameSlug('nba-bos-nyk', 'nba-bos-nyk'), true)
    assert.equal(sameSlug('nba-bos-nyk', 'bos-nyk'), false)
    assert.equal(sameSlug('', ''), false)
  })
})

describe('OrderDedupe', () => {
  it('blocks repeats, allows after release or expiry', () => {
    const d = new OrderDedupe(1000)
    assert.equal(d.claim('a', 0), true)
    assert.equal(d.claim('a', 10), false)
    d.release('a')
    assert.equal(d.claim('a', 20), true)
    assert.equal(d.claim('a', 2000), true)
  })
})

describe('WindowLimiter', () => {
  it('caps requests per window', () => {
    const l = new WindowLimiter(2, 1000)
    assert.equal(l.allow(0), true)
    assert.equal(l.allow(1), true)
    assert.equal(l.allow(2), false)
    assert.equal(l.allow(1500), true)
  })
})

describe('guessLeague', () => {
  it('sends college football to ncaaf, not nfl', () => assert.equal(guessLeague('Alabama vs Georgia college football', ''), 'ncaaf'))
  it('keeps NFL and soccer apart', () => {
    assert.equal(guessLeague('Chiefs vs Bills NFL', ''), 'nfl')
    assert.equal(guessLeague('Arsenal vs Chelsea', 'epl-ars-che'), 'epl')
    assert.equal(guessLeague('Barcelona soccer', 'laliga-bar'), 'laliga')
  })
  it('does not match inside other words', () => {
    assert.equal(guessLeague('Instant replay review', ''), 'other')
    assert.equal(guessLeague('Williams vs Smith', ''), 'other')
  })
})

describe('expectedValuePerDollar', () => {
  it('is zero when fair prob equals price with no costs', () => {
    assert.ok(Math.abs(expectedValuePerDollar({ fairProb: 0.5, ask: 0.5 })) < 1e-12)
  })
  it('turns negative with fees and slippage on a thin edge', () => {
    assert.ok(expectedValuePerDollar({ fairProb: 0.52, ask: 0.5, feeRate: 0.05, slippage: 0.01 }) < 0)
  })
  it('is positive for a real edge', () => assert.ok(expectedValuePerDollar({ fairProb: 0.6, ask: 0.5 }) > 0))
  it('rejects invalid input', () => assert.ok(Number.isNaN(expectedValuePerDollar({ fairProb: 1.2, ask: 0.5 }))))
  it('spread is never negative', () => {
    assert.equal(spread(0.4, 0.43).toFixed(2), '0.03')
    assert.equal(spread(0.5, 0.4), 0)
  })
})
