/**
 * Pure safety checks for real-money orders. Kept free of framework imports so
 * they can be unit-tested with plain node.
 */

export const DEFAULT_MAX_ORDER_USD = 25

export function maxOrderUsd(raw: string | undefined): number {
  const n = Number(raw)
  return Number.isFinite(n) && n > 0 ? n : DEFAULT_MAX_ORDER_USD
}

/** Strict stake parse. No silent fallback: a bad stake is an error, never a default amount. */
export function parseStake(value: unknown, max: number): number {
  const n = typeof value === 'number' ? value : Number(String(value ?? '').trim())
  if (!Number.isFinite(n) || n <= 0) throw new Error('Enter a stake above $0.')
  if (n > max) throw new Error(`Stake is above the $${max} per-order limit.`)
  return Math.round(n * 100) / 100
}

/** Shares we can afford at `ask` without spending more than the stake. */
export function sharesFor(stake: number, ask: number): number {
  if (!(ask > 0 && ask < 1)) throw new Error('No live ask for that market.')
  const shares = Math.floor(stake / ask)
  if (shares < 1) throw new Error(`$${stake.toFixed(2)} is less than one share at ${Math.round(ask * 100)}¢.`)
  return shares
}

/** Exact market-slug match only. Prefix/suffix matching can hit the wrong market. */
export function sameSlug(a: string, b: string): boolean {
  return a.length > 0 && a === b
}

/** Remembers client order ids so a double tap or a retry cannot buy twice. */
export class OrderDedupe {
  private seen = new Map<string, number>()
  private ttlMs: number
  constructor(ttlMs = 10 * 60_000) {
    this.ttlMs = ttlMs
  }
  /** True the first time an id is claimed, false for repeats inside the window. */
  claim(id: string, now = Date.now()): boolean {
    for (const [key, at] of this.seen) if (now - at > this.ttlMs) this.seen.delete(key)
    if (this.seen.has(id)) return false
    this.seen.set(id, now)
    return true
  }
  /** Give an id back when the order failed before reaching Polymarket, so a retry is allowed. */
  release(id: string) {
    this.seen.delete(id)
  }
}

/** Simple fixed-window limiter for public endpoints (per server instance). */
export class WindowLimiter {
  private hits: number[] = []
  private max: number
  private windowMs: number
  constructor(max: number, windowMs: number) {
    this.max = max
    this.windowMs = windowMs
  }
  allow(now = Date.now()): boolean {
    this.hits = this.hits.filter((t) => now - t < this.windowMs)
    if (this.hits.length >= this.max) return false
    this.hits.push(now)
    return true
  }
}
