/**
 * Plain, documented market math. Nothing here invents a probability: callers
 * must supply a fair probability from a real, cited source.
 */

/** A YES share priced p (0–1) pays $1 if it wins, so p is the market's implied probability. */
export const impliedProb = (price: number) => price

export const spread = (bid: number, ask: number) => (ask > bid ? ask - bid : 0)

/**
 * Expected profit per $1 staked buying YES at `ask`, given a fair probability.
 * feeRate is charged on winnings; slippage is added to the entry price.
 */
export function expectedValuePerDollar(opts: {
  fairProb: number
  ask: number
  feeRate?: number
  slippage?: number
}): number {
  const { fairProb, ask } = opts
  const entry = Math.min(0.999, ask + (opts.slippage ?? 0))
  if (!(fairProb >= 0 && fairProb <= 1) || !(entry > 0 && entry < 1)) return NaN
  const winPerShare = (1 - entry) * (1 - (opts.feeRate ?? 0))
  return (fairProb * winPerShare - (1 - fairProb) * entry) / entry
}

/** Payout in dollars if a stake buys at `ask` and wins (shares are whole numbers). */
export function payoutIfWin(stake: number, ask: number): number {
  return Math.floor(stake / ask)
}
