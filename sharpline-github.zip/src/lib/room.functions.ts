import { createServerFn } from "@tanstack/react-start";
import { getSql } from "./db";
import { WindowLimiter } from "./order-guard";

export interface RoomNote {
  id: number;
  name: string;
  body: string;
}

const lastSent = new Map<string, number>();
// Names are typed by the visitor, so the per-name wait is easy to dodge. Cap total posts too.
const roomLimiter = new WindowLimiter(20, 60_000);
let roomReady: Promise<void> | null = null;

async function roomSql() {
  const sql = await getSql();
  roomReady ??= (async () => {
    await sql`
      create table if not exists room_message (
        id bigserial primary key,
        name text not null,
        body text not null,
        created_at timestamptz not null default now()
      )
    `;
  })().catch((err) => {
    roomReady = null;
    throw err;
  });
  await roomReady;
  return sql;
}

export const loadRoom = createServerFn({ method: "GET" }).handler(async (): Promise<RoomNote[]> => {
  const sql = await roomSql();
  const rows = await sql<{ id: number; name: string; body: string }>`
    select id, name, body from room_message order by id desc limit 30
  `;
  return rows.reverse().map((row) => ({ id: Number(row.id), name: row.name, body: row.body }));
});

export const postRoom = createServerFn({ method: "POST" })
  .validator((data: { name?: string; body?: string }) => {
    const name = String(data.name ?? "").replace(/\s+/g, " ").trim().slice(0, 12);
    const body = String(data.body ?? "").replace(/\s+/g, " ").trim().slice(0, 200);
    if (name.length < 2) throw new Error("Add a name, 2 to 12 letters.");
    if (!body) throw new Error("Write a message first.");
    return { name, body };
  })
  .handler(async ({ data }) => {
    if (!roomLimiter.allow()) throw new Error("The room is busy. Try again in a minute.");
    const key = data.name.toLowerCase();
    const now = Date.now();
    const prior = lastSent.get(key) ?? 0;
    if (now - prior < 8000) throw new Error("Wait a few seconds.");
    lastSent.set(key, now);
    const sql = await roomSql();
    await sql`insert into room_message (name, body) values (${data.name}, ${data.body})`;
    await sql`
      delete from room_message
      where id not in (select id from room_message order by id desc limit 30)
    `;
    return { ok: true };
  });
