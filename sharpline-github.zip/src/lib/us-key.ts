export const KEY_ID = 'sharpline-us-key'
export const KEY_SECRET = 'sharpline-us-secret'

/**
 * The user's own Polymarket US key, as saved in this browser by the sign-in
 * form on the Portfolio page. No key is bundled with the app: if nothing is
 * saved, the person is signed out.
 */
export function savedUsKey() {
  if (typeof window === 'undefined') return null
  const id = localStorage.getItem(KEY_ID) ?? ''
  const secret = localStorage.getItem(KEY_SECRET) ?? ''
  if (id.length < 8 || secret.length < 20) return null
  return { id, secret }
}
