import { createFileRoute } from '@tanstack/react-router'
import { Bell, CheckCircle2, Flame, Trophy, TrendingUp } from 'lucide-react'
import { useEffect, useRef, useState } from 'react'
import { useServerFn } from '@tanstack/react-start'
import { AppShell } from '../components/AppShell'
import { Crest, LeagueTag, Panel } from '../components/ui'
import { loadCashLegs, type CashLeg } from '../lib/live.functions'
import { playAlert, setSound, soundOn } from '../lib/alert-sound'
import { cents, compactUsd, type AlertEvent } from '../lib/fixtures'

const MOVE_KEY = 'sharpline-move-alert'
const MOVE_CHOICES = [1, 2, 5] as const
type MoveCents = (typeof MOVE_CHOICES)[number]

function ago(ms: number, now: number) {
  const s = Math.max(0, Math.round((now - ms) / 1000))
  return s < 60 ? `${s}s ago` : `${Math.round(s / 60)}m ago`
}

export const Route = createFileRoute('/alerts')({
  head: () => ({ meta: [{ title: 'Alerts · Sharpline' }] }),
  component: AlertsPage,
})

const kindIcon: Record<AlertEvent['kind'], typeof Bell> = {
  edge: Flame,
  move: TrendingUp,
  score: Trophy,
  settled: CheckCircle2,
}

function AlertsPage() {
  const [moveOn, setMoveOn] = useState(true)
  const [moveCents, setMoveCents] = useState<MoveCents>(1)
  const [now, setNow] = useState(() => Date.now())
  const settings = useRef({ on: true, cents: 1 as number })
  const [feed, setFeed] = useState<AlertEvent[]>([])
  const [cash, setCash] = useState<CashLeg[] | null>(null)
  const [cashError, setCashError] = useState<string | null>(null)
  const [sound, setSoundOn] = useState(true)
  const prices = useRef(new Map<string, number>())
  const loadCash = useServerFn(loadCashLegs)
  const ticket = pickCashCombo(cash ?? [])

  useEffect(() => {
    setSoundOn(soundOn())
    try {
      const saved = JSON.parse(localStorage.getItem(MOVE_KEY) ?? 'null') as { on?: boolean; cents?: number } | null
      if (saved && typeof saved.on === 'boolean') setMoveOn(saved.on)
      if (saved && (MOVE_CHOICES as readonly number[]).includes(Number(saved.cents))) setMoveCents(Number(saved.cents) as MoveCents)
    } catch {
      /* use defaults */
    }
    const tick = setInterval(() => setNow(Date.now()), 1000)
    return () => clearInterval(tick)
  }, [])

  useEffect(() => {
    settings.current = { on: moveOn, cents: moveCents }
    try {
      localStorage.setItem(MOVE_KEY, JSON.stringify({ on: moveOn, cents: moveCents }))
    } catch {
      /* private mode: setting just won't persist */
    }
  }, [moveOn, moveCents])

  useEffect(() => {
    let cancel = false
    const run = () => {
      loadCash()
        .then((legs) => {
          if (cancel) return
          setCash(legs)
          setCashError(null)
          // Only real price moves between two real reads become alerts.
          const fresh: AlertEvent[] = []
          const threshold = settings.current.cents / 100 - 1e-9
          for (const leg of legs) {
            const prior = prices.current.get(leg.id)
            if (settings.current.on && prior != null && Math.abs(prior - leg.price) >= threshold) {
              const up = leg.price > prior
              fresh.push({
                id: `${leg.id}-${leg.fetchedAt}`,
                kind: 'move',
                title: `${leg.outcome} ${up ? 'up' : 'down'} ${cents(prior)} → ${cents(leg.price)}`,
                body: leg.game,
                time: new Date(leg.fetchedAt).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit', second: '2-digit' }),
                unread: true,
              })
            }
            prices.current.set(leg.id, leg.price)
          }
          if (fresh.length) {
            playAlert()
            setFeed((old) => [...fresh, ...old].slice(0, 40))
          }
        })
        .catch((err: unknown) => {
          if (!cancel) setCashError(err instanceof Error ? err.message : 'Live board unavailable')
        })
    }
    run()
    const timer = setInterval(run, 30000)
    const onShow = () => {
      if (document.visibilityState === 'visible') run()
    }
    document.addEventListener('visibilitychange', onShow)
    return () => {
      cancel = true
      clearInterval(timer)
      document.removeEventListener('visibilitychange', onShow)
    }
  }, [loadCash])

  return (
    <AppShell
      title="Alerts & markets"
      subtitle="Real Polymarket prices, re-read every 30 seconds. Alerts fire only on moves seen while this page is open."
      actions={
        <button
          type="button"
          onClick={() => {
            const next = !sound
            setSound(next)
            setSoundOn(next)
            if (next) playAlert()
          }}
          className={`rounded-full border px-3 py-1.5 text-xs font-semibold ${sound ? 'border-signal/40 bg-signal/10 text-signal' : 'border-line text-mute'}`}
        >
          {sound ? 'Sound on' : 'Sound off'}
        </button>
      }
    >
      <CashBoard legs={cash} error={cashError} ticket={ticket} />

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="space-y-6 lg:col-span-2">
          <Panel title="Active sports markets · by volume">
            <ul className="divide-y divide-line">
              {(cash ?? []).map((leg) => (
                <li key={leg.id} className="px-5 py-4">
                  <div className="flex items-center gap-2">
                    <LeagueTag id={leg.league} />
                    <a href={leg.url} className="font-display text-lg font-bold text-white hover:text-signal">
                      {leg.outcome}
                    </a>
                    <span className="num ml-auto text-sm font-semibold text-white">{cents(leg.price)}</span>
                  </div>
                  <div className="mt-1 text-sm text-mute">{leg.game}</div>
                  <div className="num mt-2 text-xs text-mute">
                    {leg.bid != null && leg.ask != null ? `Bid ${cents(leg.bid)} · Ask ${cents(leg.ask)} · Spread ${Math.max(0, Math.round((leg.ask - leg.bid) * 100))}¢` : 'Bid/ask unavailable'}
                    {' · '}Volume {compactUsd(leg.volume)}
                    {' · '}read {ago(leg.fetchedAt, now)} · {leg.source}
                  </div>
                </li>
              ))}
              {cash && cash.length === 0 && (
                <li className="px-5 py-10 text-center text-sm text-mute">No active sports markets returned.</li>
              )}
            </ul>
          </Panel>

          <Panel
            title="Price-move tape"
            action={
              <button
                type="button"
                onClick={() => setFeed((f) => f.map((a) => ({ ...a, unread: false })))}
                className="text-xs text-signal hover:underline"
              >
                Mark all read
              </button>
            }
          >
            <ul className="divide-y divide-line">
              {feed.length === 0 && (
                <li className="px-5 py-8 text-center text-sm text-mute">
                  No price moves yet. A move shows here when a market changes by your threshold between two live reads.
                </li>
              )}
              {feed.map((a) => {
                const Icon = kindIcon[a.kind]
                return (
                  <li key={a.id} className={`flex gap-3 px-5 py-3.5 ${a.unread ? 'bg-signal/[0.04]' : ''}`}>
                    <span className="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-panel-2">
                      <Icon className="h-4 w-4 text-signal" aria-hidden />
                    </span>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2 text-sm text-white">
                        {a.title}
                        {a.unread && <span className="h-1.5 w-1.5 rounded-full bg-signal" aria-label="unread" />}
                      </div>
                      <div className="mt-0.5 text-xs text-mute">{a.body}</div>
                    </div>
                    <span className="num shrink-0 text-[11px] text-mute">{a.time}</span>
                  </li>
                )
              })}
            </ul>
          </Panel>
        </div>

        <div className="space-y-6">
          <Panel title="Price-move alert">
            <div className="space-y-4 px-5 py-4">
              <div className="flex items-center gap-3">
                <p className="min-w-0 flex-1 text-sm text-white">Beep and log a move when a market changes by at least:</p>
                <button
                  type="button"
                  role="switch"
                  aria-checked={moveOn}
                  aria-label="Toggle price-move alert"
                  onClick={() => setMoveOn((v) => !v)}
                  className={`relative h-6 w-11 shrink-0 rounded-full transition ${moveOn ? 'bg-up' : 'bg-line'}`}
                >
                  <span className={`absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-all ${moveOn ? 'left-[22px]' : 'left-0.5'}`} />
                </button>
              </div>
              <div className="flex gap-2">
                {MOVE_CHOICES.map((c) => (
                  <button
                    key={c}
                    type="button"
                    onClick={() => setMoveCents(c)}
                    className={`rounded-full border px-3 py-1.5 text-xs font-semibold ${moveCents === c ? 'border-signal bg-signal text-ink' : 'border-line text-white'}`}
                  >
                    {c}¢
                  </button>
                ))}
              </div>
              <p className="text-xs text-mute">Works only while this page is open. Push and email alerts are not built.</p>
            </div>
          </Panel>
        </div>
      </div>
    </AppShell>
  )
}

function pickCashCombo(legs: CashLeg[]): CashLeg[] {
  const picked: CashLeg[] = []
  const seen = new Set<string>()
  const ranked = [...legs].sort((a, b) => b.volume - a.volume)
  for (const leg of ranked) {
    if (seen.has(leg.game)) continue
    seen.add(leg.game)
    picked.push(leg)
    if (picked.length === 4) break
  }
  return picked
}

function CashBoard({
  legs,
  error,
  ticket,
}: {
  legs: CashLeg[] | null
  error: string | null
  ticket: CashLeg[]
}) {
  const price = ticket.reduce((acc, leg) => acc * leg.price, 1)
  const [copied, setCopied] = useState(false)
  return (
    <Panel
      className="mb-6"
      title="Most active markets"
      action={<span className="text-xs text-mute">no fair-value model yet</span>}
    >
      <p className="px-5 pt-3 text-xs text-mute">
        Sorted by volume. These are crowd prices, not recommendations: no expected value is computed because no independent fair-probability source is connected.
      </p>
      {legs == null && !error && <p className="px-5 py-6 text-sm text-mute">Checking live prices…</p>}
      {error && <p className="px-5 py-6 text-sm text-down">{error}</p>}
      {legs && legs.length === 0 && (
        <p className="px-5 py-6 text-sm text-mute">No active sports markets returned.</p>
      )}
      {!!legs?.length && (
        <ul className="divide-y divide-line">
          {legs.slice(0, 6).map((leg) => (
            <li key={leg.id} className="flex items-center gap-3 px-5 py-3">
              <Crest src={leg.logo} name={leg.outcome} className="h-9 w-9" />
              <LeagueTag id={leg.league} />
              <div className="min-w-0 flex-1">
                <a href={leg.url} className="text-sm text-white hover:text-signal">
                  {leg.outcome}
                </a>
                <div className="truncate text-xs text-mute">{leg.game}</div>
              </div>
              <div className="num text-right text-sm">
                <div className="text-white">{cents(leg.price)}</div>
                <div className="text-mute">{leg.bid != null && leg.ask != null ? `${cents(leg.bid)} / ${cents(leg.ask)}` : 'bid/ask n/a'}</div>
              </div>
            </li>
          ))}
        </ul>
      )}
      {ticket.length > 0 && (
        <div className="mx-5 mb-4 rounded-xl border border-signal/30 bg-signal/5 p-4 text-sm">
          <div className="font-display text-base font-bold text-white">Top 4 by volume</div>
          <ol className="mt-2 space-y-2">
            {ticket.map((leg, index) => (
              <li key={leg.id} className="flex items-center gap-2">
                <span className="num w-5 text-xs text-mute">{index + 1}</span>
                <Crest src={leg.logo} name={leg.outcome} className="h-7 w-7" />
                <LeagueTag id={leg.league} />
                <span className="min-w-0 flex-1 truncate text-white">{leg.outcome}</span>
                <span className="num text-fog">{cents(leg.price)}</span>
              </li>
            ))}
          </ol>
          <div className="num mt-3 flex flex-wrap items-center justify-between gap-2 border-t border-line pt-3">
            <span>{ticket.length === 4 ? '4-leg price' : `${ticket.length} of 4`} {(price * 100).toFixed(1)}¢</span>
            <button
              type="button"
              onClick={() => {
                const lines = ticket.map((leg, index) => `${index + 1}. ${leg.outcome} ${cents(leg.price)} — ${leg.game}`).join('\n')
                const slip = `Pick 4\n${lines}\nCombo ${(price * 100).toFixed(1)}¢ · $10 returns $${(10 / price).toFixed(2)}`
                navigator.clipboard.writeText(slip).then(() => {
                  setCopied(true)
                  window.setTimeout(() => setCopied(false), 1600)
                }).catch(() => {})
              }}
              className="rounded-lg border border-line bg-panel px-3 py-1.5 text-xs font-semibold text-white"
            >
              {copied ? 'Copied' : 'Copy bet'}
            </button>
            <span className="text-signal">$10 returns ${(10 / price).toFixed(2)} if all hit, before fees</span>
          </div>
          <p className="mt-2 text-xs text-mute">
            Four different games, highest volume. Crowd prices, before fees; filling at the ask can cost more.
          </p>
        </div>
      )}
    </Panel>
  )
}
