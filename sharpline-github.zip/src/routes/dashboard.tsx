import { createFileRoute } from '@tanstack/react-router'
import { useServerFn } from '@tanstack/react-start'
import { RefreshCw } from 'lucide-react'
import { useEffect, useRef, useState } from 'react'
import { AppShell } from '../components/AppShell'
import { PnlChart } from '../components/PnlChart'
import { Delta, Panel, Crest, Face } from '../components/ui'
import {
  cents,
  polymarketUrl,
  positionCost,
  positionPnl,
  summarize,
  usd,
  type Position,
} from '../lib/fixtures'
import { playLoss, playRegister, profitBump } from '../lib/alert-sound'
import { closePosition, loadUsPortfolio, type WalletBook } from '../lib/live.functions'

export const Route = createFileRoute('/dashboard')({
  head: () => ({ meta: [{ title: 'Portfolio · Sharpline' }] }),
  component: DashboardPage,
})

type LedgerStatus = 'pending' | 'win' | 'loss' | 'push'
interface LedgerBet {
  id: string
  desc: string
  odds: number
  stake: number
  status: LedgerStatus
  /** When the person typed it in (ISO). */
  createdAt?: string
}

import { KEY_ID, KEY_SECRET } from '../lib/us-key'
const BETS_KEY = 'sharpline-bets'

function ledgerProfit(bet: LedgerBet) {
  if (bet.status === 'win') {
    return bet.odds > 0 ? (bet.stake * bet.odds) / 100 : (bet.stake * 100) / Math.abs(bet.odds)
  }
  if (bet.status === 'loss') return -bet.stake
  return 0
}

function DashboardPage() {
  const fetchBook = useServerFn(loadUsPortfolio)
  const sellPos = useServerFn(closePosition)
  const [keyId, setKeyId] = useState('')
  const [secret, setSecret] = useState('')
  const [signedIn, setSignedIn] = useState(false)
  const [live, setLive] = useState<WalletBook | null>(null)
  const heardLoss = useRef(new Set<string>())
  const [syncing, setSyncing] = useState(false)
  const [syncError, setSyncError] = useState<string | null>(null)
  const [bets, setBets] = useState<LedgerBet[]>([])
  const [draft, setDraft] = useState({ desc: '', odds: '', stake: '' })
  const [made, setMade] = useState(0)
  const [tab, setTab] = useState<'open' | 'done' | 'stats'>('open')
  const [picked, setPicked] = useState<string | null>(null)
  const [sellArmed, setSellArmed] = useState<string | null>(null)
  const [sellNote, setSellNote] = useState('')

  function sell(position: Position) {
    if (sellArmed !== position.id) {
      setSellArmed(position.id)
      setSellNote('Tap again to sell.')
      window.setTimeout(() => setSellArmed((current) => (current === position.id ? null : current)), 2000)
      return
    }
    setSellArmed(null)
    if (!keyId || !secret) {
      setSellNote('Sign in first.')
      return
    }
    setSellNote('Selling…')
    sellPos({ data: { keyId, secret, slug: position.id, confirm: true, clientOrderId: crypto.randomUUID() } })
      .then(() => {
        setSellNote('Sell sent.')
        void sync()
      })
      .catch((err: unknown) => setSellNote(err instanceof Error ? err.message : 'Polymarket did not sell that.'))
  }

  useEffect(() => {
    try {
      const stored = JSON.parse(localStorage.getItem(BETS_KEY) ?? '[]') as LedgerBet[]
      if (Array.isArray(stored)) setBets(stored)
      const savedId = localStorage.getItem(KEY_ID) ?? ''
      const savedSecret = localStorage.getItem(KEY_SECRET) ?? ''
      setKeyId(savedId)
      if (savedId && savedSecret) {
        setSecret(savedSecret)
        setSignedIn(true)
        void sync(savedId, savedSecret)
      }
    } catch {
      /* keep the saved book */
    }
    // sync is stable enough for the saved address only
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  useEffect(() => {
    if (!signedIn || !keyId || !secret) return
    const pull = () => {
      fetchBook({ data: { keyId, secret } })
        .then((book) => {
          setLive(book)
          const bump = profitBump(summarize(book.positions).total)
          if (bump > 0) {
            playRegister()
            setMade(bump)
          }
          const freshLoss = book.positions.some((position) => {
            if (position.status !== 'open' || positionPnl(position) >= -0.05) return false
            if (heardLoss.current.has(position.id)) return false
            heardLoss.current.add(position.id)
            return true
          })
          if (freshLoss) playLoss()
        })
        .catch(() => {})
    }
    const timer = setInterval(pull, 20000)
    const onShow = () => {
      if (document.visibilityState === 'visible') pull()
    }
    document.addEventListener('visibilitychange', onShow)
    return () => {
      clearInterval(timer)
      document.removeEventListener('visibilitychange', onShow)
    }
  }, [signedIn, keyId, secret, fetchBook])

  function saveBets(next: LedgerBet[]) {
    setBets(next)
    localStorage.setItem(BETS_KEY, JSON.stringify(next))
  }

  useEffect(() => {
    const onAuth = () => {
      const savedId = localStorage.getItem(KEY_ID) ?? ''
      const savedSecret = localStorage.getItem(KEY_SECRET) ?? ''
      setKeyId(savedId)
      setSecret(savedId && savedSecret ? savedSecret : '')
      setSignedIn(!!savedId && !!savedSecret)
      if (!savedId || !savedSecret) setLive(null)
    }
    window.addEventListener('sharpline-auth', onAuth)
    return () => window.removeEventListener('sharpline-auth', onAuth)
  }, [])

  async function sync(id = keyId, key = secret) {
    const trimmedId = id.trim()
    const trimmedKey = key.trim()
    if (trimmedId.length < 8 || trimmedKey.length < 20) {
      setSyncError('Paste both the Key ID and the secret from Polymarket.')
      return
    }
    setSyncing(true)
    setSyncError(null)
    try {
      const book = await fetchBook({ data: { keyId: trimmedId, secret: trimmedKey } })
      setLive(book)
      const bump = profitBump(summarize(book.positions).total)
      if (bump > 0) {
        playRegister()
        setMade(bump)
      }
      setKeyId(trimmedId)
      setSecret(trimmedKey)
      setSignedIn(true)
      localStorage.setItem(KEY_ID, trimmedId)
      localStorage.setItem(KEY_SECRET, trimmedKey)
      window.dispatchEvent(new Event('sharpline-auth'))
    } catch (err) {
      setSyncError(err instanceof Error ? err.message : 'Couldn’t reach Polymarket US.')
    } finally {
      setSyncing(false)
    }
  }

  const positions: Position[] = live?.positions ?? []
  const history = live?.series ?? []
  const s = summarize(positions)

  const openBets = positions.filter((p) => p.status === 'open')
  const settled = positions.filter((p) => p.status !== 'open')
  const pending = bets.filter((bet) => bet.status === 'pending')

  return (
    <AppShell
      title="Portfolio"
      wallet={signedIn ? 'Polymarket US' : null}
      subtitle={
        live
          ? `${positions.length} positions · ${usd(live.value)} on Polymarket US`
          : signedIn
            ? 'Loading your Polymarket US book'
            : 'Sign in with the Polymarket US account on your phone'
      }
    >
      {syncError && <p className="mb-4 text-sm text-down">{syncError}</p>}

      <div className="mb-4 flex items-center justify-between gap-3 rounded-2xl border border-line bg-panel px-4 py-3">
        <div className="min-w-0">
          <p className="text-[10px] font-semibold uppercase tracking-[0.18em] text-mute">{live && !live.cashKnown ? 'Open value · cash balance unavailable' : 'Your cash'}</p>
          <button type="button" onClick={() => void sync()} className="num text-3xl font-bold text-white">
            {live ? usd(live.value) : '—'}
          </button>
          <p className="text-xs text-mute">
            <span className={s.total >= 0 ? 'text-up' : 'text-down'}>{usd(s.total, true)}</span>
            {made > 0 ? ` · you made ${usd(made, true)}` : signedIn && live ? ` · from Polymarket US, ${new Date(live.fetchedAt).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit', second: '2-digit' })}` : ''}
          </p>
        </div>
        {signedIn && (
          <button type="button" onClick={() => void sync()} disabled={syncing} className="rounded-lg bg-signal px-3 py-2 text-xs font-semibold text-ink disabled:opacity-60">
            {syncing ? '…' : 'Refresh'}
          </button>
        )}
      </div>

      <div className="mb-4 grid grid-cols-3 gap-1.5">
        {([
          ['open', `Open ${openBets.length}`],
          ['done', `Done ${settled.length}`],
          ['stats', 'Stats'],
        ] as const).map(([id, label]) => (
          <button
            key={id}
            type="button"
            onClick={() => setTab(id)}
            className={`rounded-xl py-2 text-sm font-semibold ${tab === id ? 'bg-signal text-ink' : 'border border-line text-mute'}`}
          >
            {label}
          </button>
        ))}
      </div>

      {tab === 'open' && (
        <Panel title="Active bets">
          {openBets.length === 0 && pending.length === 0 ? (
            <p className="px-5 py-10 text-center text-sm text-mute">
              {signedIn ? 'No open bets. The board on Today is where you buy.' : 'Sign in to load the bets on your phone.'}
            </p>
          ) : (
            <ul className="divide-y divide-line">
              {openBets.map((p) => {
                const pnl = positionPnl(p)
                const open = picked === p.id
                const span = Math.max(0.05, Math.min(0.95, p.currentPrice))
                const mark = p.icon || teamMark(p.outcome) || teamMark(p.market)
                return (
                  <li key={p.id}>
                    <button type="button" onClick={() => setPicked(open ? null : p.id)} className={`flex w-full items-center gap-3 px-4 py-3 text-left ${open ? 'bg-panel-2/70' : ''}`}>
                      <span className={`h-10 w-1.5 shrink-0 rounded-full ${pnl >= 0 ? 'bg-up' : 'bg-down'}`} />
                      <Crest src={mark} name={p.outcome || p.market} className="h-9 w-9" />
                      <span className="min-w-0 flex-1">
                        <span className="block truncate text-sm font-semibold text-white">{opaqueBet(p.market) ? p.outcome : p.market}</span>
                        <span className="block truncate text-xs text-mute">{p.outcome} · {cents(p.currentPrice)}</span>
                      </span>
                      <span className="num text-sm font-bold"><Delta value={pnl}>{usd(pnl, true)}</Delta></span>
                      <span className="text-mute">{open ? '˅' : '›'}</span>
                    </button>
                    {open && (
                      <div className="px-4 pb-3">
                        <div className="h-1.5 overflow-hidden rounded-full bg-line">
                          <div className="h-full bg-signal" style={{ width: `${span * 100}%` }} />
                        </div>
                        <dl className="mt-3 grid grid-cols-4 gap-2 text-[11px]">
                          <div><dt className="text-mute">Contracts</dt><dd className="num text-white">{p.shares}</dd></div>
                          <div><dt className="text-mute">Avg</dt><dd className="num text-white">{cents(p.avgPrice)}</dd></div>
                          <div><dt className="text-mute">Now</dt><dd className="num text-white">{cents(p.currentPrice)}</dd></div>
                          <div><dt className="text-mute">Cost</dt><dd className="num text-white">{usd(positionCost(p))}</dd></div>
                        </dl>
                        <p className="mt-2 text-sm text-white">If it hits, you get <span className="num font-bold text-up">${p.shares.toFixed(2)}</span></p>
                        <p className="mt-1 text-xs text-fog">
                          Marked at the last price, {cents(p.currentPrice)}. Selling fills at the live best bid, which can be lower, and fees may apply.
                        </p>
                        <a href={polymarketUrl(p)} className="mt-2 inline-block text-xs font-semibold text-signal">Open on Polymarket</a>
                        <button type="button" onClick={() => sell(p)} className={`ml-3 mt-2 rounded-full px-3 py-1.5 text-xs font-bold text-white ${sellArmed === p.id ? 'bg-down' : 'bg-down/80'}`}>
                          {sellArmed === p.id ? 'Tap again' : 'Sell'}
                        </button>
                        {sellNote && picked === p.id && <p className="mt-2 text-xs text-fog">{sellNote}</p>}
                      </div>
                    )}
                  </li>
                )
              })}
              {pending.map((bet) => (
                <li key={bet.id} className="px-4 py-3">
                  <div className="truncate text-sm font-semibold text-white">{bet.desc || 'Logged bet'}</div>
                  <div className="mt-1 text-xs text-mute">Stake {usd(bet.stake)} · {bet.odds > 0 ? `+${bet.odds}` : bet.odds}</div>
                </li>
              ))}
            </ul>
          )}
        </Panel>
      )}

      {tab === 'done' && (
        <Panel title="Settled">
          {settled.length === 0 ? (
            <p className="px-5 py-10 text-center text-sm text-mute">Nothing has settled yet.</p>
          ) : (
            <ul className="divide-y divide-line">
              {settled.map((p) => {
                const pnl = positionPnl(p)
                return (
                  <li key={p.id} className="flex items-center justify-between gap-3 px-4 py-3">
                    <div className="min-w-0">
                      <div className="truncate text-sm font-medium text-white">{p.market || p.outcome}</div>
                      <div className="truncate text-xs text-mute">{p.outcome}</div>
                    </div>
                    <span className={`text-[10px] font-bold uppercase ${p.status === 'won' ? 'text-up' : 'text-down'}`}>{p.status}</span>
                    <span className="num text-sm font-semibold"><Delta value={pnl}>{usd(pnl, true)}</Delta></span>
                  </li>
                )
              })}
            </ul>
          )}
        </Panel>
      )}

      {tab === 'stats' && (
        <Panel title="My stats">
          <dl className="divide-y divide-line">
            {(
              [
                [live && !live.cashKnown ? 'Open value (cash unavailable)' : 'Cash', live ? usd(live.value) : '—'],
                ['Open positions (Polymarket)', String(openBets.length)],
                ['Money in play (Polymarket)', usd(s.openValue)],
                ['Manual ledger at risk (unverified)', usd(pending.reduce((sum, bet) => sum + bet.stake, 0))],
                ['Unrealized', usd(s.unrealized, true)],
                ['Realized', usd(s.realized, true)],
                ['Record', s.wins + s.losses ? `${s.wins}W · ${s.losses}L` : '—'],
                ['Win rate', s.winRate === null ? '—' : `${Math.round(s.winRate * 100)}%`],
              ] as const
            ).map(([label, value]) => (
              <div key={label} className="flex items-center justify-between gap-3 px-5 py-3">
                <dt className="text-xs uppercase tracking-wider text-mute">{label}</dt>
                <dd className="num text-sm font-semibold text-white">{value}</dd>
              </div>
            ))}
          </dl>
        </Panel>
      )}

      {tab === 'stats' && history.length > 1 && (
        <Panel title="Cumulative P/L · 30 days" className="mt-6">
          <div className="px-2 pb-2 pt-4">
            <PnlChart data={history} />
          </div>
        </Panel>
      )}

      {tab === 'stats' && (
      <Panel title="Manual ledger · typed by you, not verified by Polymarket" className="mt-4">
        <form
          className="grid gap-2 border-b border-line p-4 sm:grid-cols-4"
          onSubmit={(event) => {
            event.preventDefault()
            const odds = Number(draft.odds)
            const stake = Number(draft.stake)
            if (!draft.desc.trim() || !Number.isFinite(odds) || Math.abs(odds) < 100 || !(stake > 0)) return
            saveBets([
              { id: crypto.randomUUID(), desc: draft.desc.trim(), odds, stake, status: 'pending', createdAt: new Date().toISOString() },
              ...bets,
            ])
            setDraft({ desc: '', odds: '', stake: '' })
          }}
        >
          <input
            value={draft.desc}
            onChange={(event) => setDraft({ ...draft, desc: event.target.value })}
            placeholder="Bet (Lakers -3.5)"
            className="rounded-lg border border-line bg-ink px-3 py-2 text-sm sm:col-span-2"
          />
          <input
            value={draft.odds}
            onChange={(event) => setDraft({ ...draft, odds: event.target.value })}
            placeholder="American odds (-110 or +150)"
            inputMode="numeric"
            className="rounded-lg border border-line bg-ink px-3 py-2 text-sm"
          />
          <input
            value={draft.stake}
            onChange={(event) => setDraft({ ...draft, stake: event.target.value })}
            placeholder="Stake $"
            inputMode="decimal"
            className="rounded-lg border border-line bg-ink px-3 py-2 text-sm"
          />
          <button type="submit" className="rounded-lg bg-signal px-3 py-2 text-sm font-semibold text-ink sm:col-span-4">
            Add bet
          </button>
        </form>
        <div className="flex flex-wrap gap-4 px-5 py-3 text-xs text-mute">
          <span>
            Net{' '}
            <Delta value={bets.reduce((sum, bet) => sum + ledgerProfit(bet), 0)}>
              {usd(
                bets.reduce((sum, bet) => sum + ledgerProfit(bet), 0),
                true,
              )}
            </Delta>
          </span>
          <span>
            At risk {usd(bets.filter((bet) => bet.status === 'pending').reduce((sum, bet) => sum + bet.stake, 0))}
          </span>
          {bets.length > 0 && (
            <button type="button" className="ml-auto text-signal" onClick={() => { if (window.confirm('Delete every manual bet on this device?')) saveBets([]) }}>
              Clear
            </button>
          )}
        </div>
        <ul className="divide-y divide-line">
          {bets.map((bet) => {
            const profit = ledgerProfit(bet)
            return (
              <li key={bet.id} className="flex flex-wrap items-center gap-2 px-5 py-3 text-sm">
                <div className="min-w-0 flex-1">
                  <div className="text-white">{bet.desc}</div>
                  <div className="num text-xs text-mute">
                    {bet.odds > 0 ? `+${bet.odds}` : bet.odds} · {usd(bet.stake)}
                    {bet.createdAt ? ` · added ${new Date(bet.createdAt).toLocaleString([], { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' })}` : ''} · manual
                  </div>
                </div>
                <span className="num text-sm">
                  {bet.status === 'pending' ? (
                    <span className="text-mute">Pending</span>
                  ) : (
                    <Delta value={profit}>{usd(profit, true)}</Delta>
                  )}
                </span>
                {(['win', 'loss', 'push'] as LedgerStatus[]).map((status) => (
                  <button
                    key={status}
                    type="button"
                    onClick={() => saveBets(bets.map((item) => (item.id === bet.id ? { ...item, status } : item)))}
                    className={`rounded-md border px-2 py-1 text-xs capitalize ${bet.status === status ? 'border-signal text-signal' : 'border-line text-mute'}`}
                  >
                    {status}
                  </button>
                ))}
              </li>
            )
          })}
          {bets.length === 0 && (
            <li className="px-5 py-6 text-center text-sm text-mute">
              No manual bets yet. These stay on this device.
            </li>
          )}
        </ul>
      </Panel>
      )}
    </AppShell>
  )
}

function teamMark(text: string): string {
  const key = text.toLowerCase()
  const hit = TEAM_MARKS.find(([name]) => key.includes(name))
  return hit ? `https://a.espncdn.com/i/teamlogos/${hit[1]}.png` : ''
}

const TEAM_MARKS: [string, string][] = [
  ['heat', 'nba/500/mia'], ['jazz', 'nba/500/utah'], ['magic', 'nba/500/orl'], ['kings', 'nba/500/sac'],
  ['celtics', 'nba/500/bos'], ['knicks', 'nba/500/ny'], ['lakers', 'nba/500/lal'], ['suns', 'nba/500/phx'],
  ['bucks', 'nba/500/mil'], ['nuggets', 'nba/500/den'], ['wolves', 'nba/500/min'], ['timberwolves', 'nba/500/min'],
  ['warriors', 'nba/500/gs'], ['nets', 'nba/500/bkn'], ['bulls', 'nba/500/chi'], ['cavaliers', 'nba/500/cle'],
  ['cavs', 'nba/500/cle'], ['mavericks', 'nba/500/dal'], ['mavs', 'nba/500/dal'], ['hawks', 'nba/500/atl'],
  ['pistons', 'nba/500/det'], ['rockets', 'nba/500/hou'], ['pacers', 'nba/500/ind'], ['clippers', 'nba/500/lac'],
  ['grizzlies', 'nba/500/mem'], ['pelicans', 'nba/500/no'], ['thunder', 'nba/500/okc'], ['76ers', 'nba/500/phi'],
  ['sixers', 'nba/500/phi'], ['blazers', 'nba/500/por'], ['spurs', 'nba/500/sa'], ['raptors', 'nba/500/tor'],
  ['wizards', 'nba/500/wsh'], ['hornets', 'nba/500/cha'],
  ['chiefs', 'nfl/500/kc'], ['bills', 'nfl/500/buf'], ['eagles', 'nfl/500/phi'], ['cowboys', 'nfl/500/dal'],
  ['packers', 'nfl/500/gb'], ['lions', 'nfl/500/det'], ['giants', 'nfl/500/nyg'], ['commanders', 'nfl/500/wsh'],
  ['ravens', 'nfl/500/bal'], ['bengals', 'nfl/500/cin'], ['browns', 'nfl/500/cle'], ['steelers', 'nfl/500/pit'],
  ['texans', 'nfl/500/hou'], ['colts', 'nfl/500/ind'], ['jaguars', 'nfl/500/jax'], ['titans', 'nfl/500/ten'],
  ['broncos', 'nfl/500/den'], ['raiders', 'nfl/500/lv'], ['chargers', 'nfl/500/lac'], ['dolphins', 'nfl/500/mia'],
  ['patriots', 'nfl/500/ne'], ['jets', 'nfl/500/nyj'], ['falcons', 'nfl/500/atl'], ['panthers', 'nfl/500/car'],
  ['saints', 'nfl/500/no'], ['buccaneers', 'nfl/500/tb'], ['bears', 'nfl/500/chi'], ['vikings', 'nfl/500/min'],
  ['cardinals', 'nfl/500/ari'], ['rams', 'nfl/500/lar'], ['seahawks', 'nfl/500/sea'], ['49ers', 'nfl/500/sf'],
]

function opaqueBet(value: string) {
  return !/\s/.test(value) && /[0-9a-f]{10,}/i.test(value)
}

function Kpi({
  label,
  value,
  hint,
  tone,
  big,
}: {
  label: string
  value: string
  hint?: string
  tone?: number
  big?: boolean
}) {
  const color =
    tone === undefined
      ? 'text-white'
      : tone > 0
        ? 'text-up'
        : tone < 0
          ? 'text-down'
          : 'text-white'
  return (
    <div className={`relative overflow-hidden rounded-2xl border border-line p-4 sm:p-5 ${big ? 'bg-gradient-to-br from-signal/15 via-panel to-panel' : 'bg-panel'}`}>
      {big && <span className="absolute -right-8 -top-8 h-24 w-24 rounded-full bg-signal/10" />}
      <div className="text-[11px] font-semibold uppercase tracking-[0.16em] text-mute">{label}</div>
      <div className={`num mt-2 text-xl font-bold sm:text-2xl ${color}`}>
        {value}
      </div>
      {hint && <div className="mt-1 text-xs text-mute">{hint}</div>}
    </div>
  )
}
