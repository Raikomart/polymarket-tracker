import { createFileRoute } from '@tanstack/react-router'
import { useServerFn } from '@tanstack/react-start'
import { useEffect, useState } from 'react'
import { AppShell } from '../components/AppShell'
import { Crest, Face } from '../components/ui'
import { loadArena, type ArenaBoard, type FightBout, type FighterSide } from '../lib/live.functions'

export const Route = createFileRoute('/fight')({
  head: () => ({ meta: [{ title: 'Fight · Sharpline' }] }),
  component: FightPage,
})

function FightPage() {
  const load = useServerFn(loadArena)
  const [board, setBoard] = useState<ArenaBoard | null>(null)

  useEffect(() => {
    let cancel = false
    const run = () => {
      load()
        .then((next) => {
          if (!cancel) setBoard(next)
        })
        .catch(() => {})
    }
    run()
    const timer = setInterval(run, 60000)
    const onShow = () => {
      if (document.visibilityState === 'visible') run()
    }
    document.addEventListener('visibilitychange', onShow)
    return () => {
      cancel = true
      clearInterval(timer)
      document.removeEventListener('visibilitychange', onShow)
    }
  }, [load])

  const main = board?.bouts.find((bout) => bout.main) ?? board?.bouts[0]
  const under = (board?.bouts ?? []).filter((bout) => bout.id !== main?.id).slice(0, 4)

  return (
    <AppShell title="Fight" subtitle={board?.event || 'Tonight'}>
      {!board && <p className="px-4 text-sm text-mute">Loading the card…</p>}
      {board && (
        <div className="space-y-5 px-4">
          {main && <BoutCard bout={main} />}
          {under.length > 0 && (
            <section className="divide-y divide-line overflow-hidden rounded-2xl border border-line bg-panel">
              {under.map((bout) => (
                <div key={bout.id} className="flex items-center gap-2 px-3 py-2.5">
                  <Face src={bout.left.photo} fallback={bout.left.flag} name={bout.left.name} className="h-8 w-8" />
                  <span className="min-w-0 flex-1 truncate text-sm text-white">
                    {bout.left.name} <span className="text-mute">vs</span> {bout.right.name}
                  </span>
                  <span className="shrink-0 text-[10px] text-mute">{bout.weight}</span>
                </div>
              ))}
            </section>
          )}
          {board.duels.length > 0 && (
            <section className="rounded-2xl border border-line bg-panel p-3">
              <p className="mb-2 text-[11px] font-bold tracking-[0.16em] text-mute">HEAD TO HEAD</p>
              {board.duels.slice(0, 2).map((duel) => (
                <div key={duel.id} className="grid grid-cols-[1fr_auto_1fr] items-center gap-2 border-t border-line py-2 first:border-t-0">
                  <Mini side={duel.left} />
                  <span className="text-[11px] font-bold text-mute">{duel.league}</span>
                  <Mini side={duel.right} right />
                </div>
              ))}
            </section>
          )}
          {board.heat.length > 0 && (
            <section>
              <p className="mb-2 text-[11px] font-bold tracking-[0.16em] text-mute">HEAT</p>
              <div className="grid grid-cols-2 gap-2">
                {board.heat.slice(0, 4).map((cell) => (
                  <div key={cell.id} className="rounded-xl border border-line bg-panel p-2">
                    <div className="mb-1 flex justify-between text-[10px] text-mute">
                      <span>{cell.league}</span>
                      <span className={cell.state === 'live' ? 'text-up' : ''}>{cell.state === 'live' ? 'Live' : cell.state === 'final' ? 'FT' : 'Soon'}</span>
                    </div>
                    <Row logo={cell.awayLogo} name={cell.away} score={cell.awayScore} />
                    <Row logo={cell.homeLogo} name={cell.home} score={cell.homeScore} />
                    <div className="mt-2 h-1 overflow-hidden rounded-full bg-line">
                      <div className="h-full rounded-full bg-signal/80" style={{ width: `${cell.heat}%` }} />
                    </div>
                  </div>
                ))}
              </div>
            </section>
          )}
          {board.watch.length > 0 && (
            <ul className="divide-y divide-line overflow-hidden rounded-2xl border border-line bg-panel">
              {board.watch.slice(0, 4).map((player) => (
                <li key={player.name} className="flex items-center gap-2 px-3 py-2">
                  <Face src={player.photo} fallback={player.logo} name={player.name} className="h-8 w-8" />
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-sm text-white">{player.name}</span>
                    <span className="block truncate text-[11px] text-mute">{player.team}</span>
                  </span>
                  <span className="num text-sm text-signal">{player.line}</span>
                </li>
              ))}
            </ul>
          )}
        </div>
      )}
    </AppShell>
  )
}

function BoutCard({ bout }: { bout: FightBout }) {
  return (
    <article className="rounded-2xl border border-line bg-panel p-4">
      <p className="mb-3 text-center text-[11px] text-mute">{bout.weight}{bout.broadcast ? ` · ${bout.broadcast}` : ''}</p>
      <div className="grid grid-cols-[1fr_auto_1fr] items-center gap-3">
        <Fighter side={bout.left} corner="red" />
        <span className="font-display text-lg font-black text-signal">VS</span>
        <Fighter side={bout.right} corner="blue" align="right" />
      </div>
    </article>
  )
}

function Fighter({ side, corner, align = 'left' }: { side: FighterSide; corner: 'red' | 'blue'; align?: 'left' | 'right' }) {
  return (
    <div className={align === 'right' ? 'text-right' : ''}>
      <Face src={side.photo} fallback={side.flag} name={side.name} className={`h-16 w-16 ring-2 ${corner === 'red' ? 'ring-down' : 'ring-signal'} ${align === 'right' ? 'ml-auto' : ''}`} />
      <p className="mt-2 truncate text-sm font-semibold text-white">{side.name}</p>
      <p className="truncate text-[11px] text-mute">{side.record || side.country}</p>
    </div>
  )
}

function Mini({ side, right = false }: { side: { name: string; photo: string; team: string; stat: string; logo: string }; right?: boolean }) {
  return (
    <div className={`min-w-0 ${right ? 'text-right' : ''}`}>
      <p className="truncate text-sm text-white">{side.name}</p>
      <p className="truncate text-[11px] text-mute">{side.stat}</p>
    </div>
  )
}

function Row({ logo, name, score }: { logo: string; name: string; score: number | null }) {
  return (
    <div className="mt-1 flex items-center gap-1.5">
      <Crest src={logo} name={name} className="h-4 w-4" />
      <span className="min-w-0 flex-1 truncate text-[11px] text-white">{name}</span>
      <span className="num text-[11px] text-white">{score ?? '–'}</span>
    </div>
  )
}
