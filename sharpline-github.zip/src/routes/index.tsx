import { Link, createFileRoute } from '@tanstack/react-router'
import { useServerFn } from '@tanstack/react-start'
import { useEffect, useRef, useState } from 'react'
import { AppShell } from '../components/AppShell'
import { Crest, Face } from '../components/ui'
import { armSound, playFollow, playRegister } from '../lib/alert-sound'
import { cents, type Game } from '../lib/fixtures'
import {
  closePosition,
  loadCashLegs,
  loadGainers,
  loadScores,
  loadSpecEight,
  loadWatch,
  placeTicket,
  type CashLeg,
  type CopyPlay,
  type Gainer,
  type SpecLeg,
  type WatchMatch,
} from '../lib/live.functions'

export const Route = createFileRoute('/')({ component: Home })

function pick4(legs: CashLeg[]): CashLeg[] {
  const picked: CashLeg[] = []
  const seen = new Set<string>()
  for (const leg of [...legs].sort((a, b) => b.volume - a.volume)) {
    if (seen.has(leg.game)) continue
    seen.add(leg.game)
    picked.push(leg)
    if (picked.length === 4) break
  }
  return picked
}

function cashUp(n: number) {
  const v = Math.abs(n)
  const sign = n < 0 ? '-' : '+'
  if (v >= 1_000_000) return `${sign}$${(v / 1_000_000).toFixed(1)}M`
  if (v >= 1000) return `${sign}$${(v / 1000).toFixed(v >= 10_000 ? 0 : 1)}k`
  return `${sign}$${Math.round(v)}`
}

function weekLeft(end: number, now: number) {
  const ms = Math.max(0, end - now)
  const days = Math.floor(ms / 86400000)
  const hours = Math.floor((ms % 86400000) / 3600000)
  const mins = Math.floor((ms % 3600000) / 60000)
  const secs = Math.floor((ms % 60000) / 1000)
  if (days > 0) return `${days}d ${hours}h ${mins}m`
  return `${hours}h ${mins}m ${secs}s`
}

function TopPeople() {
  const load = useServerFn(loadGainers)
  const sendTicket = useServerFn(placeTicket)
  const sellPos = useServerFn(closePosition)
  const [people, setPeople] = useState<Gainer[]>([])
  const [plays, setPlays] = useState<CopyPlay[]>([])
  const [deck, setDeck] = useState<CopyPlay[]>([])
  const [resetsAt, setResetsAt] = useState(0)
  const [now, setNow] = useState(() => Date.now())
  const [follows, setFollows] = useState<string[]>([])
  const [armed, setArmed] = useState<string | null>(null)
  const [note, setNote] = useState('')
  const [stake, setStake] = useState(1)
  const armedRef = useRef<string | null>(null)
  useEffect(() => {
    try {
      const saved = JSON.parse(localStorage.getItem('sharpline-follows') ?? '[]') as string[]
      if (Array.isArray(saved)) setFollows(saved)
    } catch { /* empty */ }
  }, [])
  useEffect(() => {
    let cancel = false
    const run = () => {
      load().then((board) => {
        if (cancel) return
        setPeople(board.people)
        setPlays(board.plays)
        setDeck(board.deck ?? [])
        setResetsAt(board.resetsAt)
      }).catch(() => { /* keep the last board */ })
    }
    run()
    const clock = setInterval(() => {
      setNow(Date.now())
      if (resetsAt && Date.now() >= resetsAt) run()
    }, 1000)
    return () => { cancel = true; clearInterval(clock) }
  }, [load, resetsAt])
  function toggle(id: string) {
    setFollows((current) => {
      const has = current.includes(id)
      const next = has ? current.filter((item) => item !== id) : [...current, id]
      localStorage.setItem('sharpline-follows', JSON.stringify(next))
      if (!has) playFollow()
      return next
    })
  }
  function copyPlay(play: CopyPlay) {
    if (armedRef.current !== play.id) {
      armedRef.current = play.id
      setArmed(play.id)
      setNote('Tap again to buy.')
      window.setTimeout(() => {
        if (armedRef.current !== play.id) return
        armedRef.current = null
        setArmed(null)
      }, 2000)
      return
    }
    armedRef.current = null
    setArmed(null)
    const keyId = localStorage.getItem('sharpline-us-key') ?? ''
    const secret = localStorage.getItem('sharpline-us-secret') ?? ''
    if (!keyId || !secret) {
      setNote('Sign in on My Bets first.')
      return
    }
    setNote('Sending…')
    sendTicket({
      data: {
        keyId,
        secret,
        stake,
        mode: 'each',
        confirm: true,
        clientOrderId: crypto.randomUUID(),
        legs: [{ outcome: play.outcome, game: play.title, league: play.league, price: play.price, slug: play.slug }],
      },
    })
      .then(() => setNote('Order sent to Polymarket. Check My Bets to confirm it filled.'))
      .catch((err: unknown) => setNote(err instanceof Error ? err.message : 'Polymarket did not take it.'))
  }
  function sellPlay(play: CopyPlay) {
    const id = `sell-${play.id}`
    if (armedRef.current !== id) {
      armedRef.current = id
      setArmed(id)
      setNote('Tap again to sell.')
      window.setTimeout(() => {
        if (armedRef.current !== id) return
        armedRef.current = null
        setArmed(null)
      }, 2000)
      return
    }
    armedRef.current = null
    setArmed(null)
    const keyId = localStorage.getItem('sharpline-us-key') ?? ''
    const secret = localStorage.getItem('sharpline-us-secret') ?? ''
    if (!keyId || !secret || !play.slug) {
      setNote('No position to sell.')
      return
    }
    setNote('Selling…')
    sellPos({ data: { keyId, secret, slug: play.slug, confirm: true, clientOrderId: crypto.randomUUID() } })
      .then(() => setNote('Sell order sent to Polymarket. Check My Bets to confirm it filled.'))
      .catch((err: unknown) => setNote(err instanceof Error ? err.message : 'Polymarket did not sell that.'))
  }
  function copyCombo(size: 4 | 8 | 12) {
    const id = `c${size}`
    if (armedRef.current !== id) {
      armedRef.current = id
      setArmed(id)
      setNote('Tap again to buy.')
      window.setTimeout(() => {
        if (armedRef.current !== id) return
        armedRef.current = null
        setArmed(null)
      }, 2000)
      return
    }
    armedRef.current = null
    setArmed(null)
    const legs = deck.slice(0, size)
    const slug = legs[0]?.slug
    setNote('Finish this combo in the Polymarket app.')
    window.location.assign(slug ? `https://polymarket.com/us/event/${slug}` : 'https://polymarket.com/us')
  }
  return (
    <>
      <section className="mx-4 mb-4 rounded-2xl border border-line bg-panel px-3 py-2.5">
        <div className="flex items-center justify-between px-1 pb-1">
          <p className="text-[11px] font-bold tracking-[0.16em] text-signal">TOP GAINERS</p>
          <p className="num text-[11px] text-mute">{resetsAt ? weekLeft(resetsAt, now) : '—'}</p>
        </div>
        {people.length >= 3 && (
          <div className="mt-2 grid grid-cols-3 items-end gap-2 px-1">
            {[people[1], people[0], people[2]].map((person, place) => {
              const rank = place === 0 ? 2 : place === 1 ? 1 : 3
              const on = follows.includes(person.id)
              const tall = rank === 1 ? 'h-16' : rank === 2 ? 'h-11' : 'h-8'
              return (
                <div key={person.id} className="flex min-w-0 flex-col items-center">
                  {person.photo ? (
                    <img src={person.photo} alt="" className="h-10 w-10 rounded-full object-cover" />
                  ) : (
                    <Face name={person.name} className="h-10 w-10" />
                  )}
                  <p className="mt-1 w-full truncate text-center text-[11px] text-white">{person.name}</p>
                  <p className="num text-[10px] font-semibold text-up">{cashUp(person.up)}</p>
                  <button type="button" onClick={() => toggle(person.id)} className={`mt-1 rounded-md border px-2 py-0.5 text-[10px] font-semibold ${on ? 'border-signal bg-signal text-ink' : 'border-signal text-signal'}`}>
                    {on ? 'Following' : 'Follow'}
                  </button>
                  <div className={`mt-2 w-full rounded-t-md ${rank === 1 ? 'bg-signal' : 'bg-signal/40'} ${tall}`} />
                </div>
              )
            })}
          </div>
        )}
        <ul>
          {people.slice(people.length >= 3 ? 3 : 0, 10).map((person, index) => {
            const on = follows.includes(person.id)
            const rank = people.length >= 3 ? index + 4 : index + 1
            return (
              <li key={person.id} className="flex items-center gap-2 border-t border-line py-2.5 first:border-t-0">
                <span className="num w-6 shrink-0 text-sm text-fog">{rank}.</span>
                {person.photo ? (
                  <img src={person.photo} alt="" className="h-9 w-9 shrink-0 rounded-full object-cover" />
                ) : (
                  <Face name={person.name} className="h-9 w-9" />
                )}
                <a href={person.url} className="min-w-0 flex-1">
                  <span className="block truncate text-sm text-white">{person.name}</span>
                  <span className="block truncate text-[11px] text-mute">{person.play}</span>
                </a>
                <span className="num shrink-0 text-sm font-semibold text-up">{cashUp(person.up)}</span>
                <button type="button" onClick={() => toggle(person.id)} className={`shrink-0 rounded-lg border px-2.5 py-1 text-[11px] font-semibold ${on ? 'border-signal bg-signal text-ink' : 'border-signal text-signal'}`}>
                  {on ? 'Following' : 'Follow'}
                </button>
              </li>
            )
          })}
        </ul>
      </section>
      {plays.length > 0 && (
        <section className="mx-4 mb-4 rounded-2xl border border-line bg-panel px-3 py-2.5">
          <p className="px-1 pb-1 text-[11px] font-bold tracking-[0.16em] text-signal">ESPECULACIÓN</p>
          <div className="flex gap-1 px-1 pb-2">
            {[1, 5, 10, 25].map((amount) => (
              <button
                key={amount}
                type="button"
                onClick={() => setStake(amount)}
                className={`rounded-full border px-3 py-1 text-xs font-bold ${stake === amount ? 'border-signal bg-signal text-ink' : 'border-line text-white'}`}
              >
                ${amount}
              </button>
            ))}
          </div>
          <ul>
            {plays.map((play) => (
              <li key={play.id} className="flex items-center gap-2 border-t border-line py-2.5 first:border-t-0">
                <Crest src={play.icon} name={play.outcome} className="h-9 w-9" />
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-sm text-white">{play.outcome} · {cents(play.price)}</span>
                  <span className="block truncate text-[11px] text-mute">{play.title} · {play.names.slice(0, 2).join(', ')}</span>
                </span>
                <div className="flex shrink-0 gap-1">
                  <button
                    type="button"
                    onClick={() => copyPlay(play)}
                    className={`rounded-full px-3 py-2 text-sm font-bold text-ink ${armed === play.id ? 'bg-up' : 'bg-up/80'}`}
                  >
                    {armed === play.id ? 'Tap again' : 'Buy'}
                  </button>
                  <button
                    type="button"
                    onClick={() => sellPlay(play)}
                    className={`rounded-full px-3 py-2 text-sm font-bold text-white ${armed === `sell-${play.id}` ? 'bg-down' : 'bg-down/80'}`}
                  >
                    {armed === `sell-${play.id}` ? 'Tap again' : 'Sell'}
                  </button>
                </div>
              </li>
            ))}
          </ul>
          {([4, 8, 12] as const).map((size) => {
            const legs = deck.slice(0, size)
            if (legs.length < size) return null
            const chance = legs.reduce((acc, leg) => acc * leg.price, 1)
            const back = chance > 0 ? stake / chance : 0
            return (
              <div key={size} className="mt-3 border-t border-line pt-3">
                <p className="px-1 text-[11px] font-bold tracking-[0.16em] text-signal">{size}-LEG · ${stake}</p>
                <p className="px-1 text-xs text-fog">If all hit ${back.toLocaleString('en-US', { maximumFractionDigits: 0 })}</p>
                <ul className="mt-1">
                  {legs.map((leg) => (
                    <li key={leg.id} className="truncate px-1 text-xs text-white">{leg.outcome} {cents(leg.price)} · {leg.title}</li>
                  ))}
                </ul>
                <button
                  type="button"
                  onClick={() => copyCombo(size)}
                  className={`mt-2 w-full rounded-full px-4 py-2 text-sm font-bold text-ink ${armed === `c${size}` ? 'bg-up' : 'bg-up/80'}`}
                >
                  {armed === `c${size}` ? 'Tap again' : `Open ${size}-leg in Polymarket`}
                </button>
              </div>
            )
          })}
          {note && <p className={`px-1 pt-2 text-sm ${/sent|sending|tap again|bought|finish/i.test(note) ? 'text-up' : 'text-down'}`}>{note}</p>}
        </section>
      )}
    </>
  )
}

function GameStrip({ games }: { games: Game[] }) {
  const live = games.filter((game) => game.state === 'live')
  const rows = (live.length ? live : games.filter((game) => game.state === 'upcoming')).slice(0, 8)
  const [dot, setDot] = useState(0)
  if (!rows.length) return <p className="mb-4 px-4 text-sm text-mute">No games on the board.</p>
  return (
    <div className="mb-4">
      <p className="mb-2 px-4 text-[11px] font-bold tracking-[0.16em] text-mute">
        {live.length ? `LIVE · ${live.length}` : 'NEXT UP'}
      </p>
      <div
        onScroll={(event) => {
          const node = event.currentTarget
          setDot(Math.round(node.scrollLeft / Math.max(node.clientWidth * 0.8, 1)))
        }}
        className="flex snap-x gap-3 overflow-x-auto px-4 pb-2"
      >
        {rows.map((game) => (
          <Link key={game.id} to="/scores" className={`w-[78%] shrink-0 snap-start rounded-2xl border bg-panel p-3 ${game.state === 'live' ? 'border-up' : 'border-line'}`}>
            <div className="mb-2 flex items-center justify-between text-[10px] font-bold">
              <span className="uppercase text-mute">{game.league}</span>
              <span className={game.state === 'live' ? 'text-up' : 'text-mute'}>{game.state === 'live' ? game.clock || 'LIVE' : game.clock || 'Soon'}</span>
            </div>
            <div className="grid grid-cols-[1fr_auto_1fr] items-center gap-2">
              <Side logo={game.awayLogo} name={game.away} score={game.state === 'upcoming' ? null : game.awayScore} />
              <span className="text-xs text-mute">vs</span>
              <Side logo={game.homeLogo} name={game.home} score={game.state === 'upcoming' ? null : game.homeScore} />
            </div>
            {game.plays ? <p className="mt-2 truncate text-[11px] text-fog">{game.plays}</p> : null}
            <div className="mt-3 h-1 overflow-hidden rounded-full bg-line">
              <div className={`h-full rounded-full ${game.state === 'live' ? 'w-2/3 bg-up' : 'w-1/4 bg-signal'}`} />
            </div>
          </Link>
        ))}
      </div>
      <div className="mt-1 flex justify-center gap-1.5">
        {rows.slice(0, 6).map((game, index) => (
          <span key={game.id} className={`h-1.5 w-1.5 rounded-full ${index === dot ? 'bg-signal' : 'bg-line'}`} />
        ))}
      </div>
    </div>
  )
}

function Side({ logo, name, score }: { logo?: string; name: string; score: number | null }) {
  return (
    <div className="flex min-w-0 flex-col items-center gap-1">
      <Crest src={logo} name={name} className="h-14 w-14" />
      <span className="truncate text-sm font-extrabold uppercase text-white">{name}</span>
      <span className="num text-sm text-fog">{score ?? '–'}</span>
    </div>
  )
}

function RivalList({ title, rows }: { title: string; rows: WatchMatch[] }) {
  return (
    <section className="rounded-2xl border border-line bg-panel">
      <h2 className="px-4 pt-3 text-[11px] font-bold tracking-[0.16em] text-signal">{title}</h2>
      {rows.length === 0 && <p className="px-4 py-4 text-sm text-mute">None on the board.</p>}
      <ul>
        {rows.slice(0, 3).map((match) => (
          <li key={match.id} className="border-t border-line px-4 py-2.5">
            <div className="flex items-center justify-between text-[10px]">
              <span className="text-mute">{match.tag || match.league}</span>
              <span className={match.state === 'live' ? 'font-bold text-up' : 'text-mute'}>{match.state === 'live' ? `LIVE ${match.clock}` : match.clock}</span>
            </div>
            <p className="mt-1 flex items-center gap-2 text-sm text-white">
              <Crest src={match.awayLogo} name={match.away} className="h-6 w-6" />
              <span className="min-w-0 flex-1 truncate">{match.away}</span>
              <span className="num">{match.awayScore ?? '–'}</span>
              <span className="text-mute">–</span>
              <span className="num">{match.homeScore ?? '–'}</span>
              <span className="min-w-0 flex-1 truncate text-right">{match.home}</span>
              <Crest src={match.homeLogo} name={match.home} className="h-6 w-6" />
            </p>
            {match.star && (
              <p className="mt-1 flex items-center gap-2 text-xs text-fog">
                <Face src={match.starPhoto} name={match.star} className="h-6 w-6" />
                <span className="truncate text-white">{match.star}</span>
              </p>
            )}
            {match.plays ? <p className="mt-1 truncate text-[11px] text-fog">{match.plays}</p> : null}
          </li>
        ))}
      </ul>
    </section>
  )
}

function Home() {
  const fetchScores = useServerFn(loadScores)
  const fetchCash = useServerFn(loadCashLegs)
  const fetchWatch = useServerFn(loadWatch)
  const fetchSpec = useServerFn(loadSpecEight)
  const [board, setBoard] = useState<Game[]>([])
  const [cash, setCash] = useState<CashLeg[] | null>(null)
  const [past, setPast] = useState<WatchMatch[]>([])
  const [revenge, setRevenge] = useState<WatchMatch[]>([])
  const [clasicos, setClasicos] = useState<WatchMatch[]>([])
  const [spec, setSpec] = useState<SpecLeg[] | null>(null)
  const [stake, setStake] = useState('0.10')
  const [mode, setMode] = useState<'each' | 'double' | 'parlay' | 'eight'>('parlay')
  const [placing, setPlacing] = useState(false)
  const [note, setNote] = useState('')

  useEffect(() => {
    let cancel = false
    const run = () => {
      fetchScores({ data: { league: 'all' } }).then((rows) => { if (!cancel) setBoard(rows) }).catch(() => {})
      fetchCash().then((rows) => { if (!cancel) setCash(rows) }).catch(() => {})
      fetchWatch().then((watch) => {
        if (cancel) return
        setPast(watch.past ?? [])
        setClasicos(watch.clasicos)
        setRevenge(watch.revenge)
      }).catch(() => {})
      fetchSpec().then((rows) => { if (!cancel) setSpec(rows) }).catch(() => {})
    }
    run()
    const timer = setInterval(run, 15000)
    const onShow = () => {
      if (document.visibilityState === 'visible') run()
    }
    document.addEventListener('visibilitychange', onShow)
    return () => {
      cancel = true
      clearInterval(timer)
      document.removeEventListener('visibilitychange', onShow)
    }
  }, [fetchScores, fetchCash, fetchWatch, fetchSpec])

  const ticket = pick4(cash ?? [])
  const combo = ticket.reduce((acc, leg) => acc * leg.price, 1)
  const each = Number(stake)
  const stakeEach = Number.isFinite(each) && each > 0 ? each : 0
  const back = combo > 0 ? stakeEach / combo : 0
  const hello = new Date().getHours() < 12 ? 'Good morning' : new Date().getHours() < 17 ? 'Good afternoon' : 'Good evening'
  const live = board.filter((game) => game.state === 'live')

  const [armed, setArmed] = useState<'parlay' | 'eight' | null>(null)
  const armedRef = useRef<'parlay' | 'eight' | null>(null)

  function buy(nextMode: 'parlay' | 'eight', legs: { outcome: string; game: string; league: string; price: number; slug?: string }[]) {
    if (armedRef.current !== nextMode) {
      armedRef.current = nextMode
      setArmed(nextMode)
      setMode(nextMode)
      setNote('Tap again to buy.')
      window.setTimeout(() => {
        if (armedRef.current !== nextMode) return
        armedRef.current = null
        setArmed(null)
      }, 2000)
      return
    }
    armedRef.current = null
    setArmed(null)
    setNote('Finish this combo in the Polymarket app.')
    const slug = legs.find((leg) => leg.slug)?.slug
    window.location.assign(slug ? `https://polymarket.com/us/event/${slug}` : 'https://polymarket.com/us')
  }

  return (
    <AppShell title="Today" subtitle={hello}>
      <TopPeople />
      <GameStrip games={live.length ? live : board} />
      <section className="bg-panel">
        {ticket.length === 0 && <p className="px-4 py-6 text-sm text-mute">{cash == null ? 'Loading prices…' : 'No prices in the band right now.'}</p>}
        {ticket.length > 0 && (
          <>
            <div className="m-3 flex items-center gap-3 rounded-2xl border border-up/30 bg-[#102116] px-3 py-3">
              <span className="grid h-10 w-10 shrink-0 place-items-center rounded-full border-2 border-up text-up">✓</span>
              <div className="min-w-0 flex-1">
                <div className="text-sm font-extrabold uppercase tracking-wide text-up">If all four win ${back.toFixed(2)} · before fees</div>
                <div className="text-xs uppercase tracking-wide text-fog">{(combo * 100).toFixed(1)}¢ together</div>
              </div>
              <button type="button" onClick={() => setMode('parlay')} className="shrink-0 rounded-lg bg-signal px-2.5 py-1.5 text-[11px] font-extrabold text-ink">4-LEG</button>
            </div>
            <div className="flex items-center gap-2 px-3 pb-3">
              <label className="flex items-center gap-1 rounded-xl border border-line px-2 py-2 text-xs text-mute">
                $
                <input value={stake} onChange={(event) => setStake(event.target.value)} inputMode="decimal" className="num w-14 bg-transparent text-base font-bold text-white outline-none" aria-label="Stake" />
              </label>
              {[1, 5, 10, 25].map((amount) => (
                <button key={amount} type="button" onClick={() => setStake(String(amount))} className={`rounded-full border px-2.5 py-2 text-xs font-bold ${stake === String(amount) ? 'border-signal bg-signal text-ink' : 'border-line text-white'}`}>
                  ${amount}
                </button>
              ))}
              <button
                type="button"
                disabled={placing}
                onClick={() => buy('parlay', ticket.map((leg) => ({ outcome: leg.outcome, game: leg.game, league: leg.league, price: leg.price, slug: leg.slug })))}
                className={`shrink-0 rounded-full px-4 py-2 text-sm font-bold text-ink disabled:opacity-60 ${armed === 'parlay' ? 'bg-up' : 'bg-up/80'}`}
              >
                {placing && mode === 'parlay' ? 'Sending' : armed === 'parlay' ? 'Tap again' : 'Open 4-leg in Polymarket'}
              </button>
            </div>
            {note && <p className={`px-4 pb-3 text-sm ${/sent|sending|tap again|finish/i.test(note) ? 'text-up' : 'text-down'}`}>{note}</p>}
            <p className="px-4 pb-2 text-[11px] font-bold tracking-[0.16em] text-mute">MOST ACTIVE MARKETS · LAST PRICE, NOT A GUARANTEED FILL</p>
            <ul className="mx-3 mb-3 overflow-hidden rounded-2xl border border-line">
              {ticket.map((leg) => (
                <li key={leg.id} className="border-t border-line first:border-t-0">
                  <a href={leg.url} className="flex items-center gap-3 px-4 py-3">
                    <Crest src={leg.logo} name={leg.outcome} className="h-9 w-9" />
                    <span className="min-w-0 flex-1 truncate text-base font-semibold text-white">{leg.outcome}</span>
                    <span className="num text-lg font-bold text-signal">{cents(leg.price)}</span>
                    <span className="text-mute">›</span>
                  </a>
                </li>
              ))}
            </ul>
          </>
        )}
      </section>

      <div className="mt-6 space-y-3 px-0">
        <RivalList title="MATCH" rows={past} />
        <RivalList title="REMATCH" rows={clasicos} />
        <RivalList title="REVENGE" rows={revenge} />
      </div>
    </AppShell>
  )
}
