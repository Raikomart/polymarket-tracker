import { createFileRoute } from '@tanstack/react-router'
import { useServerFn } from '@tanstack/react-start'
import { Search } from 'lucide-react'
import { useEffect, useState, type FormEvent } from 'react'
import { AppShell } from '../components/AppShell'
import { Face, Crest } from '../components/ui'
import { cents } from '../lib/fixtures'
import { loadPlayers, loadWatch, searchPlayers, type PlayerCard } from '../lib/live.functions'

export const Route = createFileRoute('/players')({ component: PlayersPage })

const groups: Record<'NBA' | 'NFL' | 'MLB', string[]> = {
  NBA: ['PTS', 'REB', 'AST'],
  NFL: ['RUSH', 'REC', 'TD'],
  MLB: ['R', 'HR', 'H'],
}

function PlayersPage() {
  const load = useServerFn(loadPlayers)
  const find = useServerFn(searchPlayers)
  const [players, setPlayers] = useState<PlayerCard[]>([])
  const [sport, setSport] = useState<'NBA' | 'NFL' | 'MLB'>('NBA')
  const [group, setGroup] = useState('PTS')
  const [query, setQuery] = useState('')
  const [hits, setHits] = useState<PlayerCard[] | null>(null)
  const [searching, setSearching] = useState(false)
  const [note, setNote] = useState<string | null>(null)

  useEffect(() => {
    let cancel = false
    const run = () => {
      load()
        .then((rows) => {
          if (!cancel) setPlayers(rows)
        })
        .catch(() => {
          if (!cancel) setNote('Couldn’t load player stats.')
        })
    }
    run()
    const timer = setInterval(run, 60000)
    const onShow = () => {
      if (document.visibilityState === 'visible') run()
    }
    document.addEventListener('visibilitychange', onShow)
    return () => {
      cancel = true
      clearInterval(timer)
      document.removeEventListener('visibilitychange', onShow)
    }
  }, [load])

  const shown = players.filter((player) => player.league === sport && player.group === group)

  async function onSearch(event: FormEvent) {
    event.preventDefault()
    const name = query.trim()
    if (name.length < 2) {
      setNote('Type at least 2 letters.')
      return
    }
    setSearching(true)
    setNote(null)
    try {
      const rows = await find({ data: { query: name } })
      const list = Array.isArray(rows) ? rows : []
      setHits(list)
      setNote(list.length ? null : 'No player by that name.')
    } catch (err) {
      setHits(null)
      setNote(err instanceof Error ? err.message : 'Search failed.')
    } finally {
      setSearching(false)
    }
  }

  return (
    <AppShell title="Players" subtitle="Live ESPN lines. Search any name for the full stat page.">
      <form onSubmit={onSearch} className="mb-3 flex gap-2">
        <input
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          placeholder="Search a player"
          className="min-w-0 flex-1 rounded-lg border border-line bg-ink px-3 py-2 text-sm text-fog outline-none focus:border-signal"
        />
        <button type="submit" disabled={searching} className="flex items-center gap-1 rounded-lg bg-signal px-3 py-2 text-sm font-semibold text-ink disabled:opacity-60">
          <Search className="h-4 w-4" aria-hidden />
          {searching ? '…' : 'Search'}
        </button>
      </form>
      {note && !hits?.length && <p className="mb-3 text-sm text-down">{note}</p>}
      {hits && (
        <div className="mb-4 space-y-3">
          {hits.map((player) => (
            <article key={player.id} className="rounded-2xl border border-signal/30 bg-panel p-3">
              <PlayerHead player={player} />
              <dl className="mt-3 grid grid-cols-4 gap-1.5 sm:grid-cols-6">
                {(player.line ?? []).map((chip) => (
                  <div key={chip.label} className="rounded-md bg-ink px-1.5 py-1">
                    <dt className="truncate text-[9px] uppercase text-mute">{chip.label}</dt>
                    <dd className="num text-xs font-semibold text-white">{chip.value}</dd>
                  </div>
                ))}
              </dl>
            </article>
          ))}
          <button type="button" onClick={() => setHits(null)} className="text-xs text-mute underline">
            Back to leaders
          </button>
        </div>
      )}

      <div className="mb-2 flex rounded-lg bg-panel p-1" role="tablist">
        {(['NBA', 'NFL', 'MLB'] as const).map((id) => (
          <button
            key={id}
            type="button"
            role="tab"
            aria-selected={sport === id}
            onClick={() => {
              setSport(id)
              setGroup(groups[id][0])
            }}
            className={`flex-1 rounded-md py-1.5 text-sm font-semibold ${sport === id ? 'bg-signal text-ink' : 'text-mute'}`}
          >
            {id}
          </button>
        ))}
      </div>
      <div className="mb-3 flex gap-1">
        {groups[sport].map((id) => (
          <button
            key={id}
            type="button"
            aria-pressed={group === id}
            onClick={() => setGroup(id)}
            className={`rounded-full px-3 py-1 text-xs font-semibold ${group === id ? 'bg-panel-2 text-white' : 'text-mute'}`}
          >
            {id}
          </button>
        ))}
      </div>
      {!players.length && !note && !hits && <p className="text-sm text-mute">Loading live leaders…</p>}
      <ol className="divide-y divide-line overflow-hidden rounded-2xl border border-line bg-panel">
        {shown.map((player, index) => (
          <li key={player.id}>
            <a href={player.url} target="_blank" rel="noreferrer" className="flex items-center gap-2 px-3 py-2 hover:bg-panel-2/60">
              <span className="num w-4 text-[10px] text-mute">{index + 1}</span>
              <Face src={player.photo} fallback={player.logo} name={player.name} className="h-8 w-8" />
              <span className="min-w-0 flex-1">
                <span className="block truncate text-sm text-white">{player.name}</span>
                <span className="block truncate text-[10px] text-mute">{player.team}</span>
              </span>
              {player.odds && <span className="num text-[10px] text-signal">{cents(player.odds.price)}</span>}
              <span className="num w-14 text-right text-sm font-bold text-white">{player.value}</span>
            </a>
          </li>
        ))}
      </ol>
      <LeagueScorers />
    </AppShell>
  )
}

function LeagueScorers() {
  const load = useServerFn(loadWatch)
  const [rows, setRows] = useState<Awaited<ReturnType<typeof load>>['leagues']>([])
  useEffect(() => {
    let cancel = false
    const run = () => {
      load()
        .then((board) => {
          if (!cancel) setRows(board.leagues ?? [])
        })
        .catch(() => {})
    }
    run()
    const timer = setInterval(run, 60000)
    const onShow = () => {
      if (document.visibilityState === 'visible') run()
    }
    document.addEventListener('visibilitychange', onShow)
    return () => {
      cancel = true
      clearInterval(timer)
      document.removeEventListener('visibilitychange', onShow)
    }
  }, [load])
  if (!rows.length) return null
  return (
    <section className="mt-4 space-y-3">
      {rows.map((league) => (
        <div key={league.league} className="overflow-hidden rounded-2xl border border-line bg-panel">
          <p className="px-3 pt-2 text-[11px] font-bold tracking-[0.14em] text-mute">{league.league}</p>
          {league.clubs.length > 0 && (
            <div className="flex gap-1.5 overflow-x-auto px-3 py-2">
              {league.clubs.map((club) => (
                <Crest key={club.name} src={club.logo} name={club.name} className="h-7 w-7" />
              ))}
            </div>
          )}
          <div className="grid grid-cols-2 divide-x divide-line border-t border-line">
            {([['Scorers', league.scorers], ['Assists', league.assists]] as const).map(([title, people]) => (
              <div key={title} className="min-w-0">
                <p className="px-2 pt-2 text-[10px] font-bold tracking-[0.14em] text-mute">{title}</p>
                <ul>
                  {people.map((player) => (
                    <li key={`${title}-${player.name}`}>
                      <a href={player.url || undefined} target="_blank" rel="noreferrer" className="flex items-center gap-1.5 px-2 py-1">
                        <Face src={player.photo} fallback={player.logo} name={player.name} className="h-6 w-6" />
                        <span className="min-w-0 flex-1 truncate text-[11px] text-white">{player.name}</span>
                        <span className="num text-[11px] font-bold text-signal">{player.goals}</span>
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      ))}
    </section>
  )
}

function PlayerHead({ player }: { player: PlayerCard }) {
  return (
    <div className="flex items-center gap-3">
      <Face src={player.photo} fallback={player.logo} name={player.name} className="h-11 w-11" />
      <div className="min-w-0 flex-1">
        <a href={player.url} target="_blank" rel="noreferrer" className="block truncate font-semibold text-white">
          {player.name}
        </a>
        <div className="text-xs text-mute">{player.team} · {player.league}</div>
      </div>
      {player.odds && (
        <a href={player.odds.url} className="num text-sm font-bold text-signal">
          {cents(player.odds.price)}
        </a>
      )}
    </div>
  )
}
