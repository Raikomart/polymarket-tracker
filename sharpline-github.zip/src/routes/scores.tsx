import { createFileRoute } from '@tanstack/react-router'
import { useServerFn } from '@tanstack/react-start'
import { useEffect, useState } from 'react'
import { AppShell } from '../components/AppShell'
import { LeagueTag, Panel, Crest } from '../components/ui'
import { boards, soccerTables, type BoardId, type SoccerId } from '../lib/boards'
import { cents, type Game } from '../lib/fixtures'
import { loadScores, loadSoccerTable, loadWatch, type SoccerSnapshot, type WatchBoard } from '../lib/live.functions'

export const Route = createFileRoute('/scores')({
  head: () => ({ meta: [{ title: 'Scores · Sharpline' }] }),
  component: ScoresPage,
})

type Filter = 'all' | 'live' | 'upcoming' | 'final'

function ScoresPage() {
  const [league, setLeague] = useState<BoardId | 'all'>('all')
  const [filter, setFilter] = useState<Filter>('all')
  const [liveGames, setLiveGames] = useState<Game[] | null>(null)
  const [liveError, setLiveError] = useState<string | null>(null)
  const [updated, setUpdated] = useState<string>('')
  const fetchScores = useServerFn(loadScores)

  useEffect(() => {
    let cancel = false
    const run = () => {
      fetchScores({ data: { league } })
        .then((rows) => {
          if (cancel) return
          setLiveGames(rows)
          setLiveError(null)
          setUpdated(new Date().toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' }))
        })
        .catch((err: unknown) => {
          if (!cancel) setLiveError(err instanceof Error ? err.message : 'Scores unavailable')
        })
    }
    run()
    const timer = setInterval(run, 15000)
    const onShow = () => {
      if (document.visibilityState === 'visible') run()
    }
    document.addEventListener('visibilitychange', onShow)
    return () => {
      cancel = true
      clearInterval(timer)
      document.removeEventListener('visibilitychange', onShow)
    }
  }, [league, fetchScores])

  const pool = liveGames ?? []
  const shown = boards.filter((l) => league === 'all' || l.id === league)
  const liveCount = pool.filter((g) => g.state === 'live').length

  return (
    <AppShell
      title="Scores"
      subtitle={
        liveGames == null
          ? 'Loading the live scoreboard…'
          : liveCount
            ? `${liveCount} live now · ESPN${updated ? ` · ${updated}` : ''}`
            : ''
      }
    >
      <WatchStrip />
      <SoccerTables />
      {liveError && <p className="mb-3 text-sm text-down">{liveError}</p>}
      <div className="relative -mx-4 mb-4 sm:mx-0">
        <div className="overflow-x-auto px-4 sm:px-0">
          <div className="flex w-max gap-2 pr-8">
            {[{ id: 'all' as const, name: 'All leagues' }, ...boards].map(
              (l) => (
                <button
                  key={l.id}
                  type="button"
                  onClick={() => setLeague(l.id)}
                  aria-pressed={league === l.id}
                  className={`rounded-full border px-4 py-1.5 text-sm transition ${league === l.id ? 'border-signal bg-signal text-ink font-semibold' : 'border-line text-fog hover:border-mute'}`}
                >
                  {l.name}
                </button>
              ),
            )}
          </div>
        </div>
        <div
          aria-hidden
          className="pointer-events-none absolute inset-y-0 right-0 w-10 bg-gradient-to-l from-ink to-transparent"
        />
      </div>

      <div className="mb-6 flex flex-wrap items-center gap-3">
        <div
          className="flex rounded-lg bg-panel p-1"
          role="group"
          aria-label="Game state"
        >
          {(['all', 'live', 'upcoming', 'final'] as Filter[]).map((f) => (
            <button
              key={f}
              type="button"
              aria-pressed={filter === f}
              onClick={() => setFilter(f)}
              className={`rounded-md px-3 py-1 text-sm capitalize ${filter === f ? 'bg-panel-2 text-white' : 'text-mute hover:text-fog'}`}
            >
              {f}
            </button>
          ))}
        </div>
      </div>

      <div className="space-y-8">
        {shown.map((l) => {
          const list = pool.filter(
            (g) =>
              g.league === l.id &&
              (filter === 'all' || g.state === filter),
          )
          if (!list.length) return null
          return (
            <section key={l.id} aria-label={l.name}>
              <div className="mb-3 flex items-center gap-2">
                <LeagueTag id={l.id} />
                <h2 className="font-display text-lg font-bold text-white">{l.name}</h2>
              </div>
              <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
                {list.map((g) => (
                  <GameCard key={g.id} g={g} />
                ))}
              </div>
            </section>
          )
        })}
        {shown.every(
          (l) =>
            !pool.some(
              (g) =>
                g.league === l.id && (filter === 'all' || g.state === filter),
            ),
        ) && (
          <p className="rounded-2xl border border-dashed border-line py-12 text-center text-mute">
            No games match these filters.
          </p>
        )}
      </div>
    </AppShell>
  )
}

function WatchStrip() {
  const load = useServerFn(loadWatch)
  const [board, setBoard] = useState<WatchBoard | null>(null)
  useEffect(() => {
    let cancel = false
    const run = () => {
      load()
        .then((next) => {
          if (!cancel) setBoard(next)
        })
        .catch(() => {})
    }
    run()
    const timer = setInterval(run, 30000)
    return () => {
      cancel = true
      clearInterval(timer)
    }
  }, [load])
  if (!board) return <p className="mb-4 text-sm text-mute">Loading the games to watch…</p>
  return (
    <div className="mb-6 space-y-4">
      {board.feature && (
        <Panel title="The one to watch" action={<span className="text-xs text-signal">{board.feature.tag || board.feature.league}</span>}>
          <MatchRow match={board.feature} />
        </Panel>
      )}
      {(board.clasicos.length > 0 || board.revenge.length > 0) && (
        <div className="grid gap-4 lg:grid-cols-2">
          {board.clasicos.length > 0 && <MatchList title="Clásicos" matches={board.clasicos} />}
          {board.revenge.length > 0 && <MatchList title="Revenge games" matches={board.revenge} />}
        </div>
      )}
    </div>
  )
}

function MatchList({ title, matches }: { title: string; matches: WatchBoard['clasicos'] }) {
  return (
    <Panel title={title}>
      {matches.length > 0 && (
        <ul className="divide-y divide-line">
          {matches.map((match) => (
            <li key={match.id}>
              <MatchRow match={match} />
            </li>
          ))}
        </ul>
      )}
    </Panel>
  )
}

function MatchRow({ match }: { match: WatchBoard['clasicos'][number] }) {
  return (
    <div className="px-4 py-3">
      <div className="flex items-center gap-3">
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2">
            <Crest src={match.awayLogo} name={match.away} className="h-7 w-7" />
            <span className="truncate text-sm text-white">{match.away}</span>
          </div>
          <div className="mt-1 flex items-center gap-2">
            <Crest src={match.homeLogo} name={match.home} className="h-7 w-7" />
            <span className="truncate text-sm text-white">{match.home}</span>
          </div>
        </div>
        <div className="num text-right">
          <div className="text-base font-bold text-white">
            {match.awayScore ?? '–'}–{match.homeScore ?? '–'}
          </div>
          <div className={`text-[10px] ${match.state === 'live' ? 'font-semibold text-up' : 'text-mute'}`}>
            {match.tag || match.league} · {match.state === 'final' ? 'FT' : match.clock}
          </div>
        </div>
      </div>
      {match.plays ? <p className="mt-1 truncate text-[11px] text-fog">{match.plays}</p> : null}
    </div>
  )
}

function SoccerTables() {
  const [tier, setTier] = useState<'top' | 'more'>('top')
  const [id, setId] = useState<SoccerId>('epl')
  const [board, setBoard] = useState<SoccerSnapshot | null>(null)
  const [error, setError] = useState<string | null>(null)
  const load = useServerFn(loadSoccerTable)
  const choices = soccerTables.filter((table) => table.tier === tier)
  const selected = soccerTables.find((table) => table.id === id)
  const zone = ['epl', 'laliga', 'seriea', 'bundesliga', 'ligue1'].includes(id)

  useEffect(() => {
    let cancel = false
    const run = () => {
      load({ data: { id } })
        .then((next) => {
          if (cancel) return
          setBoard(next)
          setError(null)
        })
        .catch((err: unknown) => {
          if (!cancel) setError(err instanceof Error ? err.message : 'Table unavailable')
        })
    }
    setBoard(null)
    setError(null)
    run()
    const timer = setInterval(run, 30000)
    return () => {
      cancel = true
      clearInterval(timer)
    }
  }, [id, load])

  const tables = board?.tables ?? []

  return (
    <Panel
      className="mb-6"
      title={selected?.name ?? 'Football'}
      action={<span className="text-xs text-mute">Live table · goals</span>}
    >
      <div className="flex gap-2 px-4 pt-3">
        {(
          [
            ['top', 'Big leagues'],
            ['more', 'More leagues'],
          ] as const
        ).map(([key, label]) => (
          <button
            key={key}
            type="button"
            onClick={() => {
              setTier(key)
              const next = soccerTables.find((table) => table.tier === key)
              if (next) setId(next.id)
            }}
            className={`rounded-full border px-3 py-1 text-xs ${tier === key ? 'border-signal bg-signal font-semibold text-ink' : 'border-line text-fog'}`}
          >
            {label}
          </button>
        ))}
      </div>
      <div className="touch-pan-x overflow-x-auto overscroll-x-contain px-4 py-3">
        <div className="flex w-max gap-2">
          {choices.map((table) => (
            <button
              key={table.id}
              type="button"
              aria-pressed={id === table.id}
              onClick={() => setId(table.id)}
              className={`rounded-full border px-3 py-1 text-xs ${id === table.id ? 'border-signal bg-signal/10 font-semibold text-signal' : 'border-line text-mute'}`}
            >
              {table.short}
            </button>
          ))}
        </div>
      </div>
      {!!board?.matches.length && (
        <div className="touch-pan-x overflow-x-auto overscroll-x-contain border-t border-line px-4 py-3">
          <div className="flex w-max gap-3">
            {board.matches.map((match) => (
              <article
                key={match.id}
                className="flex w-[240px] items-center gap-2 rounded-xl border border-line bg-ink/50 px-3 py-2.5"
              >
                <TeamSide name={match.away} logo={match.awayLogo} />
                <div className="num w-16 shrink-0 text-center">
                  <div className="text-base font-bold text-white">
                    {match.awayScore ?? '–'}
                    <span className="px-0.5 text-mute">–</span>
                    {match.homeScore ?? '–'}
                  </div>
                  <div className={`text-[10px] ${match.state === 'live' ? 'font-semibold text-up' : 'text-mute'}`}>
                    {match.state === 'live' ? match.clock : match.state === 'final' ? 'FT' : match.clock}
                  </div>
                </div>
                <TeamSide name={match.home} logo={match.homeLogo} />
              </article>
            ))}
          </div>
        </div>
      )}
      {error && <p className="px-5 pb-4 text-sm text-down">{error}</p>}
      {board == null && !error && <p className="px-5 pb-4 text-sm text-mute">Loading live table…</p>}
      {tables.map((group) => (
        <div key={group.name} className="border-t border-line">
          {tables.length > 1 && <div className="px-4 pt-3 text-xs text-mute">{group.name}</div>}
          <div className="touch-pan-x overflow-x-auto overscroll-x-contain">
          <div className="min-w-[34rem]">
          <div className="grid grid-cols-[1.25rem_2rem_1fr_1.7rem_1.7rem_2.1rem_1.7rem] gap-x-2 px-4 py-2 text-[10px] uppercase tracking-wider text-mute">
            <span>#</span>
            <span />
            <span>Club</span>
            <span className="text-right">GF</span>
            <span className="text-right">GA</span>
            <span className="text-right">GD</span>
            <span className="text-right">Pts</span>
          </div>
          <ul>
            {group.rows.map((row) => {
              const place = Number(row.rank)
              const top = zone && place > 0 && place <= 4
              return (
                <li key={`${group.name}-${row.rank}-${row.team}`}>
                  <div
                    className={`grid grid-cols-[1.25rem_2rem_1fr_1.7rem_1.7rem_2.1rem_1.7rem] items-center gap-x-2 border-l-2 px-4 py-1.5 text-sm ${place === 1 ? 'border-signal bg-signal/10' : top ? 'border-signal/40' : 'border-transparent'}`}
                  >
                    <span className={`num ${place === 1 ? 'font-bold text-signal' : 'text-mute'}`}>{row.rank}</span>
                    <Crest src={row.logo} name={row.team} className="h-7 w-7" />
                    <span className="min-w-0">
                      <span className="block truncate text-white">{row.team}</span>
                      <span className="num text-[10px] text-mute">{row.record}</span>
                    </span>
                    <span className="num text-right font-semibold text-white">{row.gf}</span>
                    <span className="num text-right text-fog">{row.ga}</span>
                    <span className={`num text-right ${row.gd.startsWith('-') ? 'text-down' : 'text-up'}`}>{row.gd}</span>
                    <span className="num text-right font-bold text-white">{row.pts}</span>
                  </div>
                  {zone && place === 4 && (
                    <div className="mx-4 border-b border-dashed border-signal/40 pb-1 text-[10px] uppercase tracking-wider text-signal/80">
                      European places
                    </div>
                  )}
                </li>
              )
            })}
          </ul>
          </div>
          </div>
        </div>
      ))}
    </Panel>
  )
}

function TeamSide({ name, logo }: { name: string; logo?: string }) {
  return (
    <div className="flex min-w-0 flex-1 flex-col items-center gap-1">
      <Crest src={logo} name={name} />
      <span className="w-full truncate text-center text-[11px] text-fog">{name}</span>
    </div>
  )
}

/** Kick-off in the viewer's own time zone. Rendered after mount so server and browser agree. */
function LocalStart({ iso, fallback }: { iso: string; fallback: string }) {
  const [text, setText] = useState(fallback)
  useEffect(() => {
    const d = new Date(iso)
    if (Number.isNaN(d.getTime())) return
    setText(d.toLocaleString([], { weekday: 'short', month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit', timeZoneName: 'short' }))
  }, [iso])
  return <>{text}</>
}

function GameCard({ g }: { g: Game }) {
  const hasScore = g.homeScore !== null && g.awayScore !== null
  const homeLead = hasScore && g.homeScore! > g.awayScore!
  const awayLead = hasScore && g.awayScore! > g.homeScore!
  const sides = [
    { label: g.away, price: g.awayOdds, score: g.awayScore, lead: awayLead, logo: g.awayLogo },
    { label: g.home, price: g.homeOdds, score: g.homeScore, lead: homeLead, logo: g.homeLogo },
  ]
  return (
    <article
      className={`rounded-2xl border bg-panel p-4 shadow-[inset_0_1px_0_rgb(255_255_255/0.04)] ${g.state === 'live' ? 'border-up/40' : 'border-line'}`}
    >
      <div className="mb-3 flex items-center justify-between text-xs">
        {g.state === 'live' ? (
          <span className="flex items-center gap-1.5 font-semibold text-up">
            <span className="live-dot h-1.5 w-1.5 rounded-full bg-up" /> LIVE ·{' '}
            {g.clock}
          </span>
        ) : (
          <span className={g.state === 'final' ? 'text-mute' : g.state === 'postponed' || g.state === 'canceled' ? 'font-semibold text-down' : 'text-fog'}>
            {g.state === 'postponed' ? 'POSTPONED' : g.state === 'canceled' ? 'CANCELED' : g.state === 'upcoming' && g.startsAt ? <LocalStart iso={g.startsAt} fallback={g.clock} /> : g.clock}
          </span>
        )}
      </div>
      {g.line && <div className="mb-3 text-xs text-mute">{g.line}</div>}

      <div className="space-y-2">
        {sides.map((s) => (
          <div key={s.label} className="flex items-center gap-3">
            <Crest src={s.logo} name={s.label} className="h-7 w-7" />
            <span
              className={`flex-1 truncate text-[15px] ${s.lead || (g.state === 'final' && s.price === 1) ? 'font-semibold text-white' : 'text-fog'}`}
            >
              {s.label}
            </span>
            {g.state !== 'final' && g.hasOdds === true && (
              <span className="num w-10 text-right text-xs text-volt">
                {cents(s.price)}
              </span>
            )}
            <span className="num grid h-9 min-w-9 place-items-center rounded-lg bg-ink px-1.5 text-lg font-bold text-white">
              {s.score ?? '–'}
            </span>
          </div>
        ))}
      </div>

      {g.state !== 'final' && g.hasOdds === true && (
        <div className="mt-4">
          <div className="flex h-1.5 overflow-hidden rounded-full bg-line">
            <div
              className="bg-[#7aa8ff]"
              style={{ width: `${g.awayOdds * 100}%` }}
            />
            {g.drawOdds !== undefined && (
              <div
                className="bg-mute/60"
                style={{ width: `${g.drawOdds * 100}%` }}
              />
            )}
            <div
              className="bg-volt"
              style={{ width: `${g.homeOdds * 100}%` }}
            />
          </div>
          <div className="num mt-1.5 flex justify-between text-[10px] text-mute">
            <span>
              {g.away} {cents(g.awayOdds)}
            </span>
            {g.drawOdds !== undefined && <span>Draw {cents(g.drawOdds)}</span>}
            <span>
              {g.home} {cents(g.homeOdds)}
            </span>
          </div>
        </div>
      )}
      {g.plays ? <p className="mt-2 truncate text-[11px] text-fog">{g.plays}</p> : null}
    </article>
  )
}
